"""Central configuration for Jarvis. Edit this file to tune behaviour."""
from pathlib import Path

HOME = Path.home() / ".jarvis"
HOME.mkdir(exist_ok=True)

# --- LLM (served locally by Ollama) -----------------------------------------
# qwen3:8b has native tool calling and handles Tamil far better than most 7-8B models.
# On 6 GB VRAM it runs partly on GPU, partly on RAM. For more speed use "qwen3:4b".
LLM_MODEL = "qwen3:8b"
VISION_MODEL = "qwen2.5vl:3b"          # screen reading / image questions (also good at OCR)
EMBED_MODEL = "nomic-embed-text"
OLLAMA_HOST = "http://127.0.0.1:11434"
LLM_OPTIONS = {"temperature": 0.5, "num_ctx": 6144}
KEEP_ALIVE = "30m"                     # keep the model loaded between turns

# --- Persona -----------------------------------------------------------------
USER_NAME = "Lingesh"
SYSTEM_PROMPT = f"""You are J.A.R.V.I.S., a calm, dry-witted, extremely capable AI assistant running
entirely offline on {USER_NAME}'s Linux computer. Address him as "sir" (in Tamil: "ஐயா") occasionally.

LANGUAGE: Reply in the same language the user spoke. If they speak Tamil, answer in natural Tamil
script (தமிழ்). If English, answer in English. Do not mix scripts unless quoting commands or tool names.
In Tamil, write numbers as Tamil words so they can be spoken.

STYLE: You are speaking aloud. Keep answers to 1-3 short sentences unless asked for detail.
No markdown, no bullet points, no emojis, no URLs read out letter by letter.

TOOLS: Use tools to act on the computer, look at the screen, search notes, run authorised scans and write
pentest reports. Only call a tool when needed. Never invent tool results; if a tool fails, say so.
SECURITY: You assist with authorised testing, CTFs and the user's own lab only."""

# --- Language ----------------------------------------------------------------
LANGUAGES = {"en": "English", "ta": "தமிழ்"}
LANGUAGE_MODE = "auto"                 # "auto" (detect per utterance), "en" or "ta"

# --- Speech in ----------------------------------------------------------------
WAKE_WORD = "hey_jarvis"               # English wake word. Tamil users can click the core or press Space.
WHISPER_MODEL = "large-v3-turbo"       # best Tamil accuracy. Faster: "medium" or "small"
WHISPER_DEVICE = "cpu"                 # keep the GPU free for the LLM
WHISPER_COMPUTE = "int8"
SAMPLE_RATE = 16000
SILENCE_SECONDS = 1.1
SILENCE_RMS = 0.012
MAX_RECORD_SECONDS = 25

# --- Speech out ---------------------------------------------------------------
PIPER_VOICE = HOME / "voices" / "en_GB-alan-medium.onnx"     # English (British, very Jarvis)
TAMIL_TTS = "mms"                      # "mms" = fully offline (facebook/mms-tts-tam); "edge" = online, nicer voice
EDGE_TAMIL_VOICE = "ta-IN-ValluvarNeural"                    # male. Female: ta-IN-PallaviNeural

# --- Interface ------------------------------------------------------------------
UI_HOST = "127.0.0.1"
UI_PORT = 8765
# 3D holographic core. "high" = 3D with glow, "medium" = 3D without glow, "low" = flat 2D (lightest).
# The 3D scene asks the browser to use your integrated GPU when there is one, so the NVIDIA card keeps its
# VRAM for the language model.
HUD_QUALITY = "high"

# --- Safety ------------------------------------------------------------------
SAFE_COMMANDS = {"ls", "pwd", "whoami", "date", "uptime", "df", "free", "uname",
                 "ip", "ifconfig", "ping", "cat", "head", "tail", "echo", "which"}
# Scans only run against these (plus any scope you confirm for an engagement).
AUTHORISED_TARGETS = ["127.0.0.1", "localhost", "192.168.56.0/24"]
BLOCKED_PATTERNS = ["rm -rf /", "mkfs", ":(){", "dd if=", "> /dev/sd", "chmod -R 777 /"]

# --- Paths -------------------------------------------------------------------
MEMORY_DB = HOME / "memory.db"
NOTES_DIR = Path.home() / "jarvis_notes"
NOTES_DIR.mkdir(exist_ok=True)
REPORTS_DIR = Path.home() / "jarvis_reports"
REPORTS_DIR.mkdir(exist_ok=True)
