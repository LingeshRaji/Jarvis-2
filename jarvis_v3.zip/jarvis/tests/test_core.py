"""Offline tests for Jarvis core logic (no Ollama, mic or speakers needed).  Run: python tests/test_core.py"""
import os
import stat
import sys
import tempfile
import time
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.modules.setdefault("sounddevice", types.SimpleNamespace(stop=lambda: None))   # no PortAudio needed here
sys.modules.setdefault("soundfile", types.SimpleNamespace())

import config  # noqa: E402

TMP = Path(tempfile.mkdtemp())
config.REPORTS_DIR = TMP / "reports"; config.REPORTS_DIR.mkdir()
config.NOTES_DIR = TMP / "notes"; config.NOTES_DIR.mkdir()
config.HOME = TMP / "home"; config.HOME.mkdir()

import assistant as A  # noqa: E402
import pentest  # noqa: E402
import tools  # noqa: E402
import voice  # noqa: E402

pentest._ACTIVE = TMP / "active"
passed = 0


def ok(cond, name):
    global passed
    assert cond, f"FAILED: {name}"
    passed += 1
    print(f"  ok  {name}")


# ------------------------------------------------------------------ sentence streaming
print("streaming / speech helpers")
s, rest = A.pop_sentences("Hello there, sir. The time is ten. Almost")
ok(s == ["Hello there, sir.", "The time is ten."] and rest == "Almost", "splits English sentences, keeps remainder")
s, rest = A.pop_sentences("வணக்கம் ஐயா, இப்போது மணி பத்து. நன்றி ", final=True)
ok(len(s) == 2 and rest == "", "splits Tamil on full stop and flushes at end")
s, _ = A.pop_sentences("Pi is 3.14 roughly. Next", final=False)
ok(s == ["Pi is 3.14 roughly."], "does not split decimals")
ok(voice.clean_for_speech("**Done** ✅ see https://x.io `ls`") == "Done see link ls", "strips markdown, emoji, urls")
runs = voice.script_runs("Open Firefox ஐயா, திறந்துவிட்டேன் now")
ok([r[0] for r in runs] == ["en", "ta", "en"], f"routes scripts to the right voice {runs}")

# ------------------------------------------------------------------ assistant with fake LLM
print("assistant tool-calling loop")


class FakeClient:
    def __init__(self):
        self.round = 0

    def chat(self, **kw):
        self.round += 1
        if not kw.get("stream"):
            return {"message": {"content": "hi"}}
        if self.round == 1:
            return iter([{"message": {"content": "", "tool_calls": [{"function": {"name": "get_time", "arguments": {}}}]}}])
        assert any(m.get("role") == "tool" for m in kw["messages"]), "tool result must be fed back"
        return iter([{"message": {"content": "It is "}}, {"message": {"content": "late evening, sir. "}},
                     {"message": {"content": "Anything else I can do?"}}])


class FakeSpeaker:
    def __init__(self): self.said = []
    def say(self, t): self.said.append(t)
    def wait(self, t=None): pass
    def stop(self): pass


events = []
a = A.Assistant(lambda t, **d: events.append((t, d)), voice_enabled=False)
a.client = FakeClient(); a.speaker = FakeSpeaker()
a._run_turn("what time is it", "en")
types_ = [e[0] for e in events]
ok("tool" in types_ and "tool_result" in types_ and types_[-1] == "reply_end", "emits tool, tool_result, reply_end")
ok(a.speaker.said == ["It is late evening, sir.", "Anything else I can do?"], f"speaks sentence by sentence {a.speaker.said}")
ok(a.history[-1] == {"role": "assistant", "content": "It is late evening, sir. Anything else I can do?"}, "stores reply in history")
ok(any(e[0] == "state" and e[1]["state"] == "tool" for e in events), "enters tool state")

# Tamil input sets Tamil reply hint
captured = {}
class TamilClient(FakeClient):
    def chat(self, **kw):
        if kw.get("stream"):
            captured["sys"] = kw["messages"][0]["content"]
            return iter([{"message": {"content": "வணக்கம் ஐயா, நான் தயார்."}}])
        return {}
a2 = A.Assistant(lambda t, **d: None, voice_enabled=False); a2.client = TamilClient(); a2.speaker = FakeSpeaker()
a2._run_turn("வணக்கம்", "ta")
ok("தமிழ்" in captured["sys"], "tells the model to answer in Tamil")
ok(a2.speaker.said == ["வணக்கம் ஐயா, நான் தயார்."], "speaks the Tamil reply")

# confirm flow
a3 = A.Assistant(lambda t, **d: events.append((t, d)), voice_enabled=False)
import threading
threading.Timer(0.2, lambda: a3.resolve_confirm(next(i for t, d in reversed(events) if t == "confirm" for i in [d["id"]]), True)).start()
ok(a3.ask_confirm("Proceed?") is True, "confirm resolved from the UI")

# ------------------------------------------------------------------ tools
print("tools")
ok(tools.calculate("12*(3+4)") == "84", "calculator")
ok(tools.calculate("__import__('os')") == "I could not evaluate that expression.", "calculator rejects code")
ok("never-run" in tools.run_shell("rm -rf /"), "blocks destructive shell")
tools.confirm = lambda p: False
ok(tools.run_shell("touch /tmp/should_not_exist_jarvis") == "Cancelled by user.", "risky shell needs confirmation")
ok(tools.call("nope", {}) == "Unknown tool nope.", "unknown tool handled")
ok(len(tools.SCHEMAS) == len(tools.TOOLS) >= 25, f"{len(tools.SCHEMAS)} tools registered")

# ------------------------------------------------------------------ pentest
print("pentest helper")
sc = ["192.168.56.0/24", "lab.local"]
ok(pentest.in_scope("192.168.56.101", sc) and pentest.in_scope("http://lab.local:8080/x", sc), "in-scope hosts")
ok(not pentest.in_scope("8.8.8.8", sc) and not pentest.in_scope("192.168.57.1", sc), "out-of-scope hosts refused")
ok(pentest.in_scope("192.168.56.0/25", sc) and not pentest.in_scope("192.168.0.0/16", sc), "CIDR must be a subset of scope")
ok("outside the authorised scope" in pentest.run_scan("nmap_quick", "1.1.1.1", lambda t: None), "scan outside scope refused")
ok("does not look valid" in pentest.run_scan("nmap_quick", "-oN /etc/x", lambda t: None), "option injection refused")
ok("Scope not confirmed" in pentest.start("Lab", "10.0.0.5", lambda p: False), "engagement needs confirmation")
ok("is active" in pentest.start("Home Lab", "192.168.56.101, 192.168.56.102", lambda p: True), "engagement created")

fake_bin = TMP / "bin"; fake_bin.mkdir()
nm = fake_bin / "nmap"
nm.write_text("#!/bin/sh\necho 'Nmap scan report for 192.168.56.101'\necho '22/tcp open ssh OpenSSH 8.9'\necho '80/tcp open http Apache 2.4.49'\n")
nm.chmod(nm.stat().st_mode | stat.S_IEXEC)
os.environ["PATH"] = f"{fake_bin}:{os.environ['PATH']}"
notes = []
msg = pentest.run_scan("nmap_service", "192.168.56.101", notes.append)
ok("Started scan s1" in msg, "scan starts in background")
for _ in range(40):
    if notes: break
    time.sleep(0.1)
ok(notes and "complete" in notes[0], "notifies when scan completes")
out = pentest.scan_output()
ok("Open ports (2)" in out and "80/tcp open http Apache 2.4.49" in out, "scan output summarised")
ok("Recorded F-001" in pentest.add_finding("Outdated Apache", "high", "192.168.56.101:80", "Apache 2.4.49 is vulnerable to path traversal.", "80/tcp open http Apache 2.4.49", "Upgrade Apache."), "finding recorded")
pentest.add_finding("SSH exposed", "low", "192.168.56.101:22", "SSH reachable from the lab network.")
ok(pentest.list_findings().splitlines()[0].startswith("F-001 [high]"), "findings sorted by severity")
rep = pentest.generate_report()
path = Path(rep.split("Report written: ")[1].split(" ")[0])
text = path.read_text()
ok(path.exists() and "## 4. Detailed Findings" in text and "### F-001: Outdated Apache" in text and "nmap_service" in text, "report generated with findings and scan log")

print(f"\nAll {passed} checks passed.")
