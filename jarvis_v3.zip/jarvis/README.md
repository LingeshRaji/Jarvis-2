# J.A.R.V.I.S. v3: local Tamil + English voice assistant with a 3D holographic core

A desktop app, not a terminal program. Speak to it in Tamil or English, it answers out loud in the same language, and it runs entirely on your machine.

```
mic -> wake word -> Whisper large-v3-turbo (CPU) -> qwen3:8b via Ollama (GPU) -> tools -> speech out
                                                          |                            |-- English: Piper (British male)
        HUD window <-- WebSocket <-- assistant core ------+                            '-- Tamil: MMS-TTS (offline) or Edge (online, nicer)
                                                          '-- screen vision: qwen2.5vl:3b
```

## Install (Linux, about 11 GB of downloads)

```bash
unzip jarvis_v3.zip && cd jarvis
./setup.sh
```

Setup installs Ollama, the models, a Python environment, fonts, the voices, and adds **J.A.R.V.I.S.** to your application menu.

## Run

- Open **J.A.R.V.I.S.** from your application menu, or `.venv/bin/python jarvis.py`
- Preview the interface with no models or microphone: `python jarvis.py --demo`
- Typing only, no audio: `python jarvis.py --no-voice`
- Old-style terminal mode: `python jarvis.py --cli`

## Talking to it

| Do this | To get this |
|---|---|
| Say "Hey Jarvis" | starts listening (English wake word) |
| Press **Space** or click the microphone button | starts listening, any language, also interrupts Jarvis |
| Press **Esc** or the stop button | stops speaking or thinking |
| Auto / English / தமிழ் switch (left panel) | Auto detects Tamil vs English per sentence |
| Type in the box | works too, and Jarvis still answers aloud |

Risky actions (shell commands, locking the screen, setting an engagement scope) open an **Authorise / Deny** dialog. You can also say "yes" / "ஆம்" or "no" / "வேண்டாம்".

## The 3D core

The centre of the window is a real 3D scene (Three.js, bundled locally, so it works offline): a glowing core inside wireframe shells, gyroscope rings with orbiting nodes, a particle field, and a ring of bars that follows your voice and Jarvis's voice.

- **Move the mouse** to tilt the whole scene, or **click and drag** the empty space around it to spin it.
- **Colour shows state:** cyan standing by, green listening, amber thinking (a scan beam sweeps through the core), pale white speaking.
- `HUD_QUALITY` in `config.py`: `"high"` 3D with glow (default), `"medium"` 3D without glow, `"low"` flat 2D. If WebGL is not available it falls back to the flat version automatically.
- The 3D scene asks the browser for your integrated GPU, so the NVIDIA card keeps its VRAM for the language model. On a machine with only the NVIDIA GPU, use `"medium"` or `"low"` if replies slow down.

## What it can do

- **Computer:** open apps, files and sites, volume, brightness, media keys, lock screen, run shell commands, find files, timers.
- **Information:** web search and weather (when online), calculator, notes search, long-term memory.
- **Screen vision:** "What's on my screen?", "Explain this error", "Read the text in this window." Keep the Jarvis window beside what you want it to look at.
- **Pentest helper** (authorised targets only):
  1. "Start an engagement called Home Lab, scope 192.168.56.0/24." You confirm the scope.
  2. "Run a service scan on 192.168.56.101." It runs in the background and Jarvis tells you when it finishes. Available: nmap quick/service/full, nikto, whatweb, gobuster.
  3. "Summarise the last scan." "Add a finding: outdated Apache, high severity."
  4. "Generate the report." You get Markdown (plus HTML if `pandoc` is installed) in `~/jarvis_reports/<name>/`, with executive summary, scope, findings table, details, evidence and scan log.

## Tamil: what to expect

- **Understanding:** Whisper large-v3-turbo handles Tamil reasonably well, but accents and noise matter. Speak clearly, near the mic. If a sentence is misheard, switch the language to தமிழ் instead of Auto.
- **Replying:** qwen3:8b writes decent Tamil. Short, simple requests work best.
- **Voice:** the offline Tamil voice (Meta MMS) is understandable but robotic. For a much more natural voice set `TAMIL_TTS = "edge"` in `config.py` (needs internet for speech only).
- **Wake word:** "Hey Jarvis" works only in English. In Tamil, press Space or click the button.
- Numbers inside Tamil replies are written as Tamil words so they can be spoken.

## Tuning (`config.py`)

| Problem | Change |
|---|---|
| Replies feel slow | `LLM_MODEL = "qwen3:4b"` (fits entirely in 6 GB VRAM), or `WHISPER_MODEL = "medium"` |
| Tamil heard poorly | keep `large-v3-turbo`, set the language switch to தமிழ் |
| Cuts you off mid-sentence | raise `SILENCE_SECONDS` |
| Never stops recording | raise `SILENCE_RMS` |
| Different English voice | download another Piper voice and set `PIPER_VOICE` |
| More authorised lab ranges | `AUTHORISED_TARGETS` |

## Troubleshooting

- **HUD shows "Reconnecting":** the backend stopped. Start it from a terminal to see the error.
- **"Cannot reach Ollama":** run `ollama serve`.
- **Wake word unavailable:** it needs a one-time model download (setup does this). Space and the button still work.
- **Tamil letters show as boxes:** install a Tamil font (`noto-fonts` on Arch, `fonts-noto-core` on Debian/Ubuntu).
- **Screen vision fails:** install `grim` (Wayland) or `scrot` (X11) and run `ollama pull qwen2.5vl:3b`.
- **pip fails on a very new Python:** use Python 3.11 to 3.13.
- **Screen vision is slow the first time:** with 6 GB VRAM, Ollama unloads the language model to load the vision model, then swaps back.

## Safety

- Everything listens on `127.0.0.1` only. Nothing leaves your machine except optional web search, weather and Edge Tamil voice.
- Scans are refused outside `AUTHORISED_TARGETS` plus the scope you confirm for the current engagement. Only add systems you own or have written permission to test.
- Dangerous shell patterns are never run, and everything outside a small safe list needs your confirmation. Small local models can misread a command, so read it before approving.

## Files

`jarvis.py` launcher, `assistant.py` brain, `voice.py` speech, `tools.py` abilities, `pentest.py` scans and reports, `vision.py` screen reading, `server.py` + `ui/` the HUD (`core3d.js` 3D scene, `core2d.js` flat fallback, `vendor/` Three.js), `demo.py` preview mode, `tests/test_core.py` offline tests.
