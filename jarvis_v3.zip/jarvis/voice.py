"""Voice I/O for Jarvis: wake word, multilingual speech-to-text (Tamil + English), and a streaming
text-to-speech engine (Piper for English, MMS or Edge for Tamil) that reports audio levels to the HUD."""
import asyncio
import queue
import re
import subprocess
import sys
import tempfile
import threading
import time

import numpy as np
import sounddevice as sd
import soundfile as sf

import config

# ----------------------------------------------------------------------------------------------
# Text helpers
# ----------------------------------------------------------------------------------------------
_EMOJI = re.compile("[\U00010000-\U0010ffff☀-➿️]")
_URL = re.compile(r"https?://\S+")


def is_tamil(ch: str) -> bool:
    return "஀" <= ch <= "௿"


def has_tamil(text: str) -> bool:
    return any(is_tamil(c) for c in text)


def clean_for_speech(text: str) -> str:
    text = re.sub(r"```.*?```", " ", text, flags=re.S)
    text = _URL.sub(" link ", text)
    text = _EMOJI.sub("", text)
    text = re.sub(r"[`*_#>|~]", "", text)
    text = re.sub(r"^\s*[-•]\s+", "", text, flags=re.M)
    return re.sub(r"\s+", " ", text).strip()


def script_runs(text: str) -> list[tuple[str, str]]:
    """Split text into consecutive ('ta'|'en', chunk) runs so each goes to the right voice."""
    runs, cur, cur_lang = [], "", None
    for ch in text:
        lang = "ta" if is_tamil(ch) else ("en" if ch.isalpha() else None)
        if lang and cur_lang and lang != cur_lang:
            if cur.strip():
                runs.append((cur_lang, cur))
            cur = ""
        if lang:
            cur_lang = lang
        cur += ch
    if cur.strip():
        runs.append((cur_lang or "en", cur))
    return runs


# ----------------------------------------------------------------------------------------------
# Speech in
# ----------------------------------------------------------------------------------------------
_whisper = None
_oww = None
_oww_failed = False


def _get_whisper():
    global _whisper
    if _whisper is None:
        from faster_whisper import WhisperModel
        _whisper = WhisperModel(config.WHISPER_MODEL, device=config.WHISPER_DEVICE,
                                compute_type=config.WHISPER_COMPUTE)
    return _whisper


def _get_oww():
    global _oww, _oww_failed
    if _oww is None and not _oww_failed:
        try:
            import openwakeword
            from openwakeword.model import Model
            try:
                _oww = Model(wakeword_models=[config.WAKE_WORD], inference_framework="onnx")
            except Exception:
                openwakeword.utils.download_models([config.WAKE_WORD])
                _oww = Model(wakeword_models=[config.WAKE_WORD], inference_framework="onnx")
        except Exception as e:
            print(f"[voice] wake word unavailable ({e}); use the core / Space key instead.")
            _oww_failed = True
    return _oww


def wake_word_available() -> bool:
    return _get_oww() is not None


def wait_for_trigger(trigger: threading.Event, level_cb=None, stop: threading.Event | None = None) -> str | None:
    """Block until the wake word is heard ('wake'), `trigger` is set ('manual'), or `stop` is set (None)."""
    oww = _get_oww()
    if oww:
        oww.reset()
    with sd.InputStream(samplerate=config.SAMPLE_RATE, channels=1, dtype="int16", blocksize=1280) as stream:
        while True:
            if stop is not None and stop.is_set():
                return None
            frame, _ = stream.read(1280)
            mono = frame[:, 0]
            if level_cb:
                level_cb(min(1.0, float(np.sqrt(np.mean((mono / 32768.0) ** 2))) * 8))
            if trigger.is_set():
                trigger.clear()
                return "manual"
            if oww is not None:
                scores = oww.predict(mono)
                if scores and max(scores.values()) > 0.5:
                    return "wake"


def record_until_silence(level_cb=None, first_word_timeout: float = 7.0) -> np.ndarray:
    """Record one utterance; stops after a pause. Returns float32 mono audio at 16 kHz."""
    chunks, silent_for, started = [], 0.0, False
    t0 = time.time()
    block = int(config.SAMPLE_RATE * 0.1)
    with sd.InputStream(samplerate=config.SAMPLE_RATE, channels=1, dtype="float32", blocksize=block) as stream:
        while time.time() - t0 < config.MAX_RECORD_SECONDS:
            data, _ = stream.read(block)
            mono = data[:, 0]
            rms = float(np.sqrt(np.mean(mono ** 2)))
            if level_cb:
                level_cb(min(1.0, rms * 8))
            chunks.append(mono)
            if rms > config.SILENCE_RMS:
                started, silent_for = True, 0.0
            elif started:
                silent_for += 0.1
                if silent_for >= config.SILENCE_SECONDS:
                    break
            elif time.time() - t0 > first_word_timeout:
                break
    audio = np.concatenate(chunks) if chunks else np.zeros(1, dtype="float32")
    return audio if started else np.zeros(1, dtype="float32")


def transcribe(audio: np.ndarray, mode: str | None = None) -> tuple[str, str]:
    """Return (text, language). Language is restricted to English/Tamil in auto mode."""
    if len(audio) < config.SAMPLE_RATE * 0.4:
        return "", "en"
    mode = mode or config.LANGUAGE_MODE
    model = _get_whisper()
    if mode in config.LANGUAGES:
        lang = mode
    else:
        try:
            _, _, probs = model.detect_language(audio)
            p = dict(probs)
            lang = "ta" if p.get("ta", 0.0) > p.get("en", 0.0) else "en"
        except Exception:
            lang = "en"
    segs, _ = model.transcribe(audio, language=lang, vad_filter=True, beam_size=1,
                               condition_on_previous_text=False)
    return " ".join(s.text.strip() for s in segs).strip(), lang


def listen(level_cb=None, mode: str | None = None) -> tuple[str, str]:
    return transcribe(record_until_silence(level_cb), mode)


# ----------------------------------------------------------------------------------------------
# Speech out
# ----------------------------------------------------------------------------------------------
_mms = None


def _synth_piper(text: str):
    if not config.PIPER_VOICE.exists():
        return None
    with tempfile.NamedTemporaryFile(suffix=".wav") as f:
        subprocess.run([sys.executable, "-m", "piper", "-m", str(config.PIPER_VOICE), "-f", f.name],
                       input=text.encode(), capture_output=True)
        try:
            data, sr = sf.read(f.name, dtype="float32")
        except Exception:
            return None
    return data, sr


def _synth_mms(text: str):
    global _mms
    import torch
    from transformers import AutoTokenizer, VitsModel
    if _mms is None:
        _mms = (AutoTokenizer.from_pretrained("facebook/mms-tts-tam"),
                VitsModel.from_pretrained("facebook/mms-tts-tam").eval())
    tok, model = _mms
    inputs = tok(text, return_tensors="pt")
    if inputs["input_ids"].shape[-1] == 0:
        return None
    with torch.no_grad():
        wav = model(**inputs).waveform[0].cpu().numpy().astype("float32")
    return wav, int(model.config.sampling_rate)


def _decode_audio(path: str):
    try:
        return sf.read(path, dtype="float32")
    except Exception:
        wav = path + ".wav"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", path, wav], check=True)
        return sf.read(wav, dtype="float32")


def _synth_edge(text: str):
    import edge_tts

    async def run(path):
        await edge_tts.Communicate(text, config.EDGE_TAMIL_VOICE).save(path)

    with tempfile.NamedTemporaryFile(suffix=".mp3") as f:
        asyncio.run(run(f.name))
        return _decode_audio(f.name)


def synthesize(text: str, lang: str):
    """Return (float32 audio, sample_rate) or None."""
    try:
        if lang == "ta":
            if config.TAMIL_TTS == "edge":
                try:
                    return _synth_edge(text)
                except Exception as e:
                    print(f"[tts] edge unavailable ({e}); using offline Tamil voice")
            return _synth_mms(text)
        return _synth_piper(text)
    except Exception as e:
        print(f"[tts] {lang} synthesis failed: {e}")
        return None


class Speaker:
    """Queue-based speaker: say() returns immediately, audio is synthesised and played in the background.
    level_cb(0..1) is called ~20x/second during playback so the HUD can animate."""

    def __init__(self, level_cb=None):
        self.level_cb = level_cb
        self._synth_q: queue.Queue = queue.Queue()
        self._play_q: queue.Queue = queue.Queue()
        self._cv = threading.Condition()
        self._pending = 0
        self._gen = 0
        threading.Thread(target=self._synth_loop, daemon=True).start()
        threading.Thread(target=self._play_loop, daemon=True).start()

    # -- public ---------------------------------------------------------------------------
    def say(self, text: str) -> None:
        text = clean_for_speech(text)
        if not text:
            return
        with self._cv:
            self._pending += 1
        self._synth_q.put((self._gen, text))

    def wait(self, timeout: float | None = None) -> None:
        with self._cv:
            self._cv.wait_for(lambda: self._pending == 0, timeout)

    def stop(self) -> None:
        with self._cv:
            self._gen += 1
        try:
            sd.stop()
        except Exception:
            pass

    @property
    def busy(self) -> bool:
        return self._pending > 0

    # -- internals ------------------------------------------------------------------------
    def _finish(self) -> None:
        with self._cv:
            self._pending = max(0, self._pending - 1)
            if self._pending == 0:
                self._cv.notify_all()

    def _synth_loop(self) -> None:
        while True:
            gen, text = self._synth_q.get()
            if gen != self._gen:
                self._finish()
                continue
            parts = []
            for lang, chunk in script_runs(text):
                if gen != self._gen:
                    break
                if not any(c.isalnum() for c in chunk):
                    continue
                audio = synthesize(chunk.strip(), lang)
                if audio is not None:
                    parts.append(audio)
            if parts and gen == self._gen:
                self._play_q.put((gen, parts))
            else:
                self._finish()

    def _play_loop(self) -> None:
        while True:
            gen, parts = self._play_q.get()
            try:
                for data, sr in parts:
                    if gen != self._gen:
                        break
                    if data.ndim > 1:
                        data = data.mean(axis=1)
                    with sd.OutputStream(samplerate=sr, channels=1, dtype="float32") as out:
                        step = max(512, sr // 20)
                        for i in range(0, len(data), step):
                            if gen != self._gen:
                                break
                            seg = data[i:i + step]
                            out.write(seg.reshape(-1, 1))
                            if self.level_cb:
                                self.level_cb(min(1.0, float(np.sqrt(np.mean(seg ** 2))) * 5))
            except Exception as e:
                print(f"[audio] playback error: {e}")
            finally:
                if self.level_cb:
                    self.level_cb(0.0)
                self._finish()
