#!/usr/bin/env python3
"""J.A.R.V.I.S. launcher.

  python jarvis.py            # desktop app: HUD window + voice (Tamil / English)
  python jarvis.py --cli      # terminal text mode
  python jarvis.py --demo     # preview the HUD without models, mic or speakers
  python jarvis.py --no-voice # HUD + typing only (no microphone / speakers)
"""
import argparse
import shutil
import socket
import subprocess
import threading
import time
import webbrowser

import config

BROWSERS = ["chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "brave-browser", "brave",
            "microsoft-edge"]


def port_open(host: str, port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex((host, port)) == 0


def open_window(url: str) -> None:
    """Show the HUD in its own window. Returns when the window is closed."""
    try:
        import webview  # optional: pip install pywebview (needs GTK or Qt WebEngine)
        webview.create_window("J.A.R.V.I.S.", url, width=1360, height=840, background_color="#02070b")
        webview.start()
        return
    except Exception:
        pass
    for b in BROWSERS:
        exe = shutil.which(b)
        if exe:
            profile = config.HOME / "browser-profile"
            subprocess.run([exe, f"--app={url}", f"--user-data-dir={profile}", "--window-size=1360,840",
                            "--no-first-run", "--disable-features=Translate", "--class=Jarvis"])
            return
    print(f"No app-capable browser found; opening {url} in your default browser. Press Ctrl+C to quit.")
    webbrowser.open(url)
    while True:
        time.sleep(3600)


def run_gui(args) -> None:
    import uvicorn
    import server

    url = f"http://{config.UI_HOST}:{config.UI_PORT}"
    srv = None
    if port_open(config.UI_HOST, config.UI_PORT):
        print("Jarvis is already running; opening a new window.")
    else:
        app = server.create_app(demo=args.demo, voice=not args.no_voice and not args.demo)
        srv = uvicorn.Server(uvicorn.Config(app, host=config.UI_HOST, port=config.UI_PORT, log_level="warning"))
        threading.Thread(target=srv.run, daemon=True).start()
        while not srv.started:
            time.sleep(0.1)
    try:
        if args.no_window:
            print(f"HUD at {url}  (Ctrl+C to quit)")
            while True:
                time.sleep(3600)
        open_window(url)
    except KeyboardInterrupt:
        pass
    finally:
        if srv:
            srv.should_exit = True
            time.sleep(0.5)


def run_cli() -> None:
    import assistant as A
    import tools

    def emit(t, **d):
        if t == "token":
            print(d["text"], end="", flush=True)
        elif t == "reply_end":
            print()
        elif t == "tool":
            print(f"\n  [tool] {d['name']}({d['args']})")
        elif t in ("status", "notice"):
            print(f"  [{t}] {d['text']}")

    a = A.Assistant(emit, voice_enabled=False)
    tools.confirm = lambda p: input(f"{p} [y/N] ").strip().lower() == "y"
    a.start()
    print("JARVIS terminal mode. Type 'exit' to quit.")
    while True:
        try:
            text = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if text.lower() in {"exit", "quit"}:
            break
        if text:
            a.submit_text(text)
            time.sleep(0.2)
            a.idle.wait()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cli", action="store_true")
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--no-voice", action="store_true")
    ap.add_argument("--no-window", action="store_true", help="serve the HUD without opening a window")
    args = ap.parse_args()
    run_cli() if args.cli else run_gui(args)


if __name__ == "__main__":
    main()
