import { createCore2D } from './core2d.js';

(() => {
  const $ = (s) => document.querySelector(s);
  let cv = $('#core');
  const stage = $('#stage'), label = $('#statelabel'), logEl = $('#log');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ------------------------------------------------------------------ state + renderer
  const COL = {
    offline: [110, 135, 148], idle: [95, 227, 255], listening: [141, 255, 217],
    thinking: [255, 179, 71], tool: [255, 179, 71], speaking: [200, 246, 255],
  };
  const TEXT = {
    offline: 'Reconnecting', idle: 'Standing by', listening: 'Listening',
    thinking: 'Thinking', tool: 'Working', speaking: 'Speaking',
  };
  let state = 'offline';
  let core = null, coreStarting = false, lastLayout = null;

  function setState(s) {
    if (!COL[s]) return;
    state = s;
    document.body.dataset.state = s;
    label.textContent = TEXT[s];
    const c = COL[s];
    document.documentElement.style.setProperty('--accent', `rgb(${c[0]},${c[1]},${c[2]})`);
    if (core) core.setState(s);
    if (s === 'idle' || s === 'offline') setLevel(0);
  }
  function setLevel(v) { if (core) core.setLevel(v); }

  function layout() {
    const r = stage.getBoundingClientRect();
    const W = innerWidth, H = innerHeight;
    const area = Math.max(200, r.height - 110);           // leave room for the input row
    const cy = r.top + area * 0.5;
    const R = Math.max(70, Math.min(r.width * 0.3, area * 0.3));
    label.style.top = (cy + R * 1.62 - r.top - 10) + 'px';
    lastLayout = { W, H, cx: r.left + r.width / 2, cy, R };
    if (core) core.layout(lastLayout);
  }

  // Try the 3D renderer first; fall back to the flat 2D one (no WebGL, or HUD_QUALITY = "low").
  async function initCore(quality) {
    if (core || coreStarting) return;
    coreStarting = true;
    let c = null;
    if (quality !== 'low') {
      try {
        const m = await import('./core3d.js');
        c = await m.createCore3D(cv, { quality, reduce });
      } catch (e) {
        console.warn('3D renderer unavailable, using flat HUD:', e);
        const fresh = cv.cloneNode(false);                // a canvas that tried WebGL cannot give a 2D context
        cv.replaceWith(fresh); cv = fresh;
      }
    }
    if (!c) c = createCore2D(cv, { reduce });
    core = c;
    document.body.dataset.renderer = c.kind;
    core.setState(state);
    core.layout(lastLayout || (layout(), lastLayout));
    core.start();
    coreStarting = false;
  }

  // ------------------------------------------------------------------ log
  let cur = null;
  const stickToBottom = () => logEl.scrollHeight - logEl.scrollTop - logEl.clientHeight < 80;
  function push(el) {
    const stick = stickToBottom();
    logEl.appendChild(el);
    if (stick) logEl.scrollTop = logEl.scrollHeight;
    return el;
  }
  function line(cls, text, lang) {
    const d = document.createElement('div');
    d.className = 'line ' + cls;
    if (lang === 'ta') d.lang = 'ta';
    d.textContent = text;
    return d;
  }
  function jarvisLine() {
    if (!cur) { cur = push(line('jarvis', '')); }
    return cur;
  }
  const compact = (o) => { try { return JSON.stringify(o); } catch { return ''; } };

  // ------------------------------------------------------------------ websocket
  let ws, retry;
  function send(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }
  const setStatus = (text, kind) => { $('#status').textContent = text; $('#dot').className = kind || ''; };

  function connect() {
    ws = new WebSocket(`ws://${location.host}/ws`);
    ws.onopen = () => { clearTimeout(retry); setStatus('Connected', 'wait'); };
    ws.onclose = () => { setState('offline'); setStatus('Reconnecting', 'bad'); retry = setTimeout(connect, 1500); };
    ws.onmessage = (e) => handle(JSON.parse(e.data));
  }

  function handle(m) {
    switch (m.type) {
      case 'hello':
        initCore(m.quality || 'high');
        logEl.innerHTML = ''; cur = null;
        setState(m.state || 'idle');
        setMode(m.mode);
        setStatus(`${m.model}`, 'wait');
        if (!m.voice) { $('#mic').disabled = true; $('#tts').disabled = true; $('#talk').hidden = true; }
        (m.recent || []).forEach(handle);
        if (!logEl.children.length) push(line('empty', 'Say “Hey Jarvis”, press Space, or type below. தமிழிலும் பேசலாம்.'));
        break;
      case 'state': setState(m.state); break;
      case 'level': {
        const want = (m.src === 'mic' && state === 'listening') || (m.src === 'voice' && state === 'speaking') ||
                     (m.src === 'mic' && state === 'idle');
        if (want) setLevel(Math.min(1, m.value));
        break;
      }
      case 'user':
        if (!m.text) break;
        cur = null;
        { const d = line('user', ''); const s = document.createElement('small'); s.textContent = m.lang === 'ta' ? 'தமிழ்' : 'English';
          const p = document.createElement('span'); p.textContent = m.text; if (m.lang === 'ta') p.lang = 'ta';
          d.append(s, p); push(d); }
        break;
      case 'token': {
        const stick = stickToBottom();
        const el = jarvisLine(); el.textContent += m.text;
        if (/[஀-௿]/.test(el.textContent)) el.lang = 'ta';
        if (stick) logEl.scrollTop = logEl.scrollHeight;
        break;
      }
      case 'reply_end':
        if (!cur && m.text) push(line('jarvis', m.text, /[஀-௿]/.test(m.text) ? 'ta' : 'en'));
        if (cur && !cur.textContent.trim() && m.text) cur.textContent = m.text;
        cur = null;
        break;
      case 'tool': cur = null; push(line('tool', `${m.name}(${compact(m.args)})`)); break;
      case 'tool_result': push(line('tool res', m.result)); break;
      case 'notice': push(line('notice', m.text)); break;
      case 'status':
        setStatus(m.text, m.ok === true ? 'ok' : m.ok === false ? 'bad' : 'wait');
        if (m.ok === false) push(line('err', m.text));
        break;
      case 'mode': setMode(m.mode); break;
      case 'stats': stats(m); break;
      case 'confirm': showConfirm(m); break;
      case 'confirm_done': hideConfirm(); break;
    }
  }

  // ------------------------------------------------------------------ telemetry
  function row(id, pct, text) {
    const r = $('#r-' + id);
    if (pct == null) { r.hidden = true; return; }
    r.hidden = false;
    r.querySelector('b').textContent = text;
    r.querySelector('.bar i').style.width = Math.max(0, Math.min(100, pct)) + '%';
    r.querySelector('.bar').classList.toggle('hot', pct > 85);
  }
  function stats(s) {
    row('cpu', s.cpu, `${Math.round(s.cpu)}%`);
    row('ram', s.ram, `${s.ram_used} / ${s.ram_total} GB`);
    row('gpu', s.gpu, s.gpu != null ? `${Math.round(s.gpu)}%` : '');
    row('vram', s.vram_total ? (s.vram_used / s.vram_total) * 100 : null,
        s.vram_total ? `${(s.vram_used / 1024).toFixed(1)} / ${(s.vram_total / 1024).toFixed(1)} GB` : '');
    row('temp', s.gpu_temp != null ? Math.min(100, s.gpu_temp) : null, s.gpu_temp != null ? `${Math.round(s.gpu_temp)}°C` : '');
    row('disk', s.disk, `${Math.round(s.disk)}%`);
  }

  function tick() {
    const d = new Date();
    $('#time').textContent = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    $('#date').textContent = d.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' });
  }

  // ------------------------------------------------------------------ controls
  function setMode(mode) {
    document.querySelectorAll('.seg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === mode));
  }
  document.querySelectorAll('.seg button').forEach((b) => b.addEventListener('click', () => send({ type: 'mode', mode: b.dataset.mode })));
  $('#mic').addEventListener('change', (e) => send({ type: 'mic', value: e.target.checked }));
  $('#tts').addEventListener('change', (e) => send({ type: 'tts', value: e.target.checked }));
  $('#talk').addEventListener('click', () => send({ type: 'listen' }));
  $('#halt').addEventListener('click', () => send({ type: 'stop' }));
  $('#composer').addEventListener('submit', (e) => {
    e.preventDefault();
    const v = $('#text').value.trim();
    if (v) { send({ type: 'text', text: v }); $('#text').value = ''; }
  });

  let confirmId = null;
  function showConfirm(m) { confirmId = m.id; $('#c-text').textContent = m.prompt; $('#confirm').hidden = false; $('#c-yes').focus(); }
  function hideConfirm() { $('#confirm').hidden = true; confirmId = null; }
  function answer(ok) { if (confirmId) { send({ type: 'confirm_reply', id: confirmId, ok }); hideConfirm(); } }
  $('#c-yes').addEventListener('click', () => answer(true));
  $('#c-no').addEventListener('click', () => answer(false));

  document.addEventListener('keydown', (e) => {
    if (confirmId) {
      if (e.key.toLowerCase() === 'y') answer(true);
      if (e.key === 'Escape' || e.key.toLowerCase() === 'n') answer(false);
      return;
    }
    const typing = document.activeElement === $('#text');
    if (e.key === 'Escape') { send({ type: 'stop' }); $('#text').blur(); }
    else if (e.code === 'Space' && !typing && !e.repeat) { e.preventDefault(); send({ type: 'listen' }); }
  });

  // ------------------------------------------------------------------ boot
  addEventListener('resize', layout);
  addEventListener('scroll', layout, { passive: true });
  layout(); setState('offline'); tick(); setInterval(tick, 1000);
  connect();
})();
