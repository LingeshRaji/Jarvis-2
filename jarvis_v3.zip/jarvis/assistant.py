"""The Jarvis brain: streaming LLM + tool calling + speech-to-speech loop.

The Assistant knows nothing about the UI. It reports everything through `emit(type, **data)`, which the
web server forwards to the HUD (and the CLI prints). Events:
  state(state)            idle | listening | thinking | tool | speaking
  level(value, src)       0..1 audio level for the visualiser (src = mic | voice)
  user(text, lang)        what the user said / typed
  token(text)             streamed reply text
  reply_end(text)         full reply
  tool(name, args)        a tool is being run;  tool_result(name, result)
  confirm(id, prompt)     the user must approve something
  notice(text)            background job messages
  status(text, ok)        model loading / errors
"""
import json
import queue
import re
import threading
import time
import uuid
from datetime import datetime

import ollama

import config
import memory
import tools

YES = {"yes", "yeah", "yep", "confirm", "proceed", "go ahead", "do it", "sure", "ok", "okay",
       "ஆம்", "ஆமா", "ஆமாம்", "சரி", "செய்", "ம்ம்"}
NO = {"no", "nope", "cancel", "stop", "don't", "deny", "வேண்டாம்", "இல்லை", "நிறுத்து"}


def _g(obj, key, default=None):
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def pop_sentences(buf: str, final: bool = False) -> tuple[list[str], str]:
    """Split streamed text into speakable sentences. Returns (sentences, remainder)."""
    out, start = [], 0
    for m in re.finditer(r"[.!?।…]+[\"”')\]]*\s+|\n+", buf):
        piece = buf[start:m.end()]
        if len(piece.strip()) >= 12:
            out.append(piece.strip())
            start = m.end()
    rest = buf[start:]
    if final and rest.strip():
        out.append(rest.strip())
        rest = ""
    return out, rest


class _NotIdle:
    """Adapter so voice.wait_for_trigger can poll 'a turn has started'."""
    def __init__(self, idle: threading.Event):
        self.idle = idle

    def is_set(self) -> bool:
        return not self.idle.is_set()


class Assistant:
    def __init__(self, emit, voice_enabled: bool = True):
        self.emit = emit
        self.voice_enabled = voice_enabled
        self.client = ollama.Client(host=config.OLLAMA_HOST)
        self.history: list[dict] = []
        self.mode = config.LANGUAGE_MODE
        self.state = "idle"
        self.tts_enabled = True
        self.mic_enabled = True
        self.idle = threading.Event()
        self.idle.set()
        self.trigger = threading.Event()
        self._cancel = threading.Event()
        self._quit = threading.Event()
        self._turns: queue.Queue = queue.Queue()
        self._confirms: dict[str, dict] = {}
        self.speaker = None
        self._voice = None
        if voice_enabled:
            import voice as _voice
            self._voice = _voice
            self.speaker = _voice.Speaker(level_cb=lambda v: self.emit("level", value=v, src="voice"))
        tools.confirm = self.ask_confirm
        tools.notify = self.notify

    # ------------------------------------------------------------------ lifecycle
    def start(self) -> None:
        threading.Thread(target=self._worker, daemon=True).start()
        threading.Thread(target=self._warmup, daemon=True).start()
        if self.voice_enabled:
            threading.Thread(target=self._voice_loop, daemon=True).start()

    def shutdown(self) -> None:
        self._quit.set()
        self.stop()

    def _warmup(self) -> None:
        self.emit("status", text=f"Loading {config.LLM_MODEL}…", ok=None)
        try:
            self.client.chat(model=config.LLM_MODEL, messages=[{"role": "user", "content": "hi"}],
                             options={"num_predict": 1}, keep_alive=config.KEEP_ALIVE)
            self.emit("status", text=f"{config.LLM_MODEL} online", ok=True)
        except Exception as e:
            self.emit("status", text=f"Cannot reach Ollama / {config.LLM_MODEL}: {e}", ok=False)
            return
        h = datetime.now().hour
        part = "morning" if h < 12 else "afternoon" if h < 18 else "evening"
        if self.mode == "ta":
            self.say_verbatim(f"வணக்கம் {config.USER_NAME}. அனைத்து அமைப்புகளும் தயார்.")
        else:
            self.say_verbatim(f"Good {part}, {config.USER_NAME}. All systems online.")

    # ------------------------------------------------------------------ state helpers
    def set_state(self, state: str) -> None:
        if state != self.state:
            self.state = state
            self.emit("state", state=state)

    def set_mode(self, mode: str) -> None:
        if mode in ("auto", *config.LANGUAGES):
            self.mode = mode
            self.emit("mode", mode=mode)

    def stop(self) -> None:
        """Interrupt thinking/speaking."""
        self._cancel.set()
        if self.speaker:
            self.speaker.stop()

    # ------------------------------------------------------------------ input
    def submit_text(self, text: str, lang: str | None = None) -> None:
        text = text.strip()
        if not text:
            return
        lang = lang or ("ta" if any("஀" <= c <= "௿" for c in text) else "en")
        self.idle.clear()
        self._turns.put(("turn", text, lang))

    def say_verbatim(self, text: str) -> None:
        self.idle.clear()
        self._turns.put(("say", text, "ta" if self.mode == "ta" else "en"))

    def notify(self, text: str) -> None:
        self.emit("notice", text=text)
        self.say_verbatim(text)

    def request_listen(self) -> None:
        """Orb click / Space: interrupt whatever is happening and listen now."""
        if not self.voice_enabled:
            return
        if not self.idle.is_set():
            self.stop()
            self.idle.wait(4)
        self.trigger.set()

    # ------------------------------------------------------------------ voice loop
    def _voice_loop(self) -> None:
        v = self._voice
        while not self._quit.is_set():
            self.idle.wait()
            if not self.mic_enabled and not self.trigger.is_set():
                time.sleep(0.2)
                continue
            self.set_state("idle")
            try:
                src = v.wait_for_trigger(self.trigger, lambda x: self.emit("level", value=x, src="mic"),
                                         stop=_NotIdle(self.idle))
                if src is None:
                    continue
                self.set_state("listening")
                audio = v.record_until_silence(lambda x: self.emit("level", value=x, src="mic"))
                self.emit("level", value=0.0, src="mic")
                self.set_state("thinking")
                text, lang = v.transcribe(audio, self.mode)
            except Exception as e:
                self.emit("status", text=f"Microphone/speech error: {e}", ok=False)
                self.set_state("idle")
                time.sleep(2)
                continue
            if text:
                self.submit_text(text, lang)
            else:
                self.set_state("idle")

    # ------------------------------------------------------------------ confirm
    def ask_confirm(self, prompt: str) -> bool:
        cid = uuid.uuid4().hex[:8]
        ev = threading.Event()
        self._confirms[cid] = {"ev": ev, "ok": None}
        self.emit("confirm", id=cid, prompt=prompt)
        if self.speaker and self.tts_enabled:
            self.speaker.say(prompt + (" ஆம் என்றால் சொல்லுங்கள்." if self.mode == "ta" else " Say yes to confirm."))
            threading.Thread(target=self._voice_confirm, args=(cid,), daemon=True).start()
        ev.wait(45)
        ok = bool(self._confirms.pop(cid, {}).get("ok"))
        self.emit("confirm_done", id=cid, ok=ok)
        return ok

    def resolve_confirm(self, cid: str, ok: bool) -> None:
        c = self._confirms.get(cid)
        if c and c["ok"] is None:
            c["ok"] = ok
            c["ev"].set()

    def _voice_confirm(self, cid: str) -> None:
        try:
            self.speaker.wait(20)
            c = self._confirms.get(cid)
            if not c or c["ok"] is not None:
                return
            text, _ = self._voice.listen(lambda x: self.emit("level", value=x, src="mic"), self.mode)
            words = set(re.findall(r"[\w']+", text.lower()))
            if words & YES:
                self.resolve_confirm(cid, True)
            elif words & NO:
                self.resolve_confirm(cid, False)
        except Exception:
            pass

    # ------------------------------------------------------------------ worker
    def _worker(self) -> None:
        while not self._quit.is_set():
            kind, text, lang = self._turns.get()
            self._cancel.clear()
            try:
                if kind == "say":
                    self._say_turn(text, lang)
                else:
                    self._run_turn(text, lang)
            except Exception as e:
                self.emit("status", text=f"Error: {e}", ok=False)
                self.emit("reply_end", text="")
                if self.speaker and self.tts_enabled and kind == "turn":
                    self.speaker.say("மன்னிக்கவும், ஏதோ தவறு நடந்தது." if lang == "ta"
                                     else "Apologies, something went wrong.")
            finally:
                if self.speaker and self.tts_enabled:
                    self.speaker.wait(120)
                self.set_state("idle")
                if self._turns.empty():
                    self.idle.set()

    def _speak(self, sentence: str) -> None:
        if self.speaker and self.tts_enabled and not self._cancel.is_set():
            self.set_state("speaking")
            self.speaker.say(sentence)

    def _say_turn(self, text: str, lang: str) -> None:
        self.emit("user", text="", lang=lang)
        self.emit("token", text=text)
        self.emit("reply_end", text=text)
        self._speak(text)

    def _run_turn(self, text: str, lang: str) -> None:
        self.emit("user", text=text, lang=lang)
        self.set_state("thinking")
        reply_lang = self.mode if self.mode in config.LANGUAGES else lang

        try:
            facts = memory.recall(text)
        except Exception:
            facts = []
        sys_msg = config.SYSTEM_PROMPT
        sys_msg += f"\n\nThe user is speaking {config.LANGUAGES[reply_lang]} right now: reply in {config.LANGUAGES[reply_lang]}."
        if facts:
            sys_msg += "\n\nKnown facts about the user:\n- " + "\n- ".join(facts)

        self.history.append({"role": "user", "content": text})
        messages = [{"role": "system", "content": sys_msg}] + self.history[-12:]
        final_text = ""

        for _ in range(5):
            buf, round_text, calls = "", "", []
            try:
                stream = self.client.chat(model=config.LLM_MODEL, messages=messages, tools=tools.SCHEMAS,
                                          stream=True, think=False, options=config.LLM_OPTIONS,
                                          keep_alive=config.KEEP_ALIVE)
            except TypeError:  # older ollama client without `think`
                stream = self.client.chat(model=config.LLM_MODEL, messages=messages, tools=tools.SCHEMAS,
                                          stream=True, options=config.LLM_OPTIONS, keep_alive=config.KEEP_ALIVE)
            for chunk in stream:
                if self._cancel.is_set():
                    break
                msg = _g(chunk, "message")
                piece = _g(msg, "content") or ""
                if piece:
                    round_text += piece
                    buf += piece
                    self.emit("token", text=piece)
                    sentences, buf = pop_sentences(buf)
                    for s in sentences:
                        self._speak(s)
                for tc in _g(msg, "tool_calls") or []:
                    fn = _g(tc, "function")
                    args = _g(fn, "arguments") or {}
                    if isinstance(args, str):
                        args = json.loads(args or "{}")
                    calls.append({"function": {"name": _g(fn, "name"), "arguments": dict(args)}})
            if self._cancel.is_set():
                break
            for s in pop_sentences(buf, final=True)[0]:
                self._speak(s)
            final_text += round_text

            if not calls:
                break
            messages.append({"role": "assistant", "content": round_text, "tool_calls": calls})
            for c in calls:
                name, args = c["function"]["name"], c["function"]["arguments"]
                self.set_state("tool")
                self.emit("tool", name=name, args=args)
                result = tools.call(name, args)
                self.emit("tool_result", name=name, result=result[:300])
                messages.append({"role": "tool", "name": name, "content": result})
            self.set_state("thinking")
        else:
            msg = "I seem to be going in circles, sir."
            final_text += " " + msg
            self.emit("token", text=" " + msg)
            self._speak(msg)

        final_text = final_text.strip() or ("Done." if reply_lang == "en" else "முடிந்தது.")
        self.history.append({"role": "assistant", "content": final_text})
        self.emit("reply_end", text=final_text)
