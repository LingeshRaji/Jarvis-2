"""Screen vision: take a screenshot and ask a local vision model about it."""
import os
import shutil
import subprocess
from pathlib import Path

import ollama

import config

SHOT = config.HOME / "screen.png"


def screenshot(path: Path = SHOT) -> Path:
    path = Path(path)
    path.unlink(missing_ok=True)
    wayland = os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland" or bool(os.environ.get("WAYLAND_DISPLAY"))
    cmds = []
    if wayland:
        cmds += [["grim", str(path)], ["spectacle", "-b", "-n", "-f", "-o", str(path)],
                 ["gnome-screenshot", "-f", str(path)]]
    cmds += [["scrot", "-o", str(path)], ["maim", str(path)], ["import", "-window", "root", str(path)],
             ["gnome-screenshot", "-f", str(path)], ["spectacle", "-b", "-n", "-f", "-o", str(path)]]
    for c in cmds:
        if shutil.which(c[0]):
            subprocess.run(c, capture_output=True, timeout=15)
            if path.exists() and path.stat().st_size > 0:
                return path
    try:
        import mss
        import mss.tools
        with mss.mss() as s:
            shot = s.grab(s.monitors[0])
            mss.tools.to_png(shot.rgb, shot.size, output=str(path))
        return path
    except Exception as e:
        raise RuntimeError("No screenshot tool worked. Install grim (Wayland) or scrot (X11).") from e


def _shrink(path: Path, max_w: int = 1600) -> Path:
    try:
        from PIL import Image
        im = Image.open(path)
        if im.width > max_w:
            im = im.resize((max_w, int(im.height * max_w / im.width)))
        small = path.with_name(path.stem + "_small.png")
        im.convert("RGB").save(small)
        return small
    except Exception:
        return path


def ask_image(path: str | Path, question: str) -> str:
    img = _shrink(Path(path))
    r = ollama.Client(host=config.OLLAMA_HOST).chat(
        model=config.VISION_MODEL, keep_alive="2m", options={"temperature": 0.2, "num_ctx": 4096},
        messages=[{"role": "user", "content": question, "images": [str(img)]}])
    return (r["message"]["content"] or "").strip() or "I could not make anything out."


def look_at_screen(question: str = "Describe what is on the screen.") -> str:
    return ask_image(screenshot(), question + " Ignore the JARVIS window itself if it is visible.")
