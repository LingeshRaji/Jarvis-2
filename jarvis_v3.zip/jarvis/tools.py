"""Tools Jarvis can call. Each tool is a plain function plus a JSON schema for the LLM."""
import ast
import operator
import os
import shlex
import shutil
import subprocess
import threading
import urllib.parse
import urllib.request
from datetime import datetime

import psutil

import config
import memory
import pentest
import vision

# Replaced by the Assistant at start-up (GUI confirm dialog / spoken confirm / spoken notification).
confirm = lambda prompt: input(f"{prompt} [y/N] ").strip().lower() == "y"
notify = lambda text: print(f"JARVIS: {text}")


# =============================================================== system
def get_time() -> str:
    return datetime.now().strftime("%A, %d %B %Y, %I:%M %p")


def system_status() -> str:
    vm = psutil.virtual_memory()
    bat = psutil.sensors_battery()
    out = f"CPU {psutil.cpu_percent(interval=0.4)}%, RAM {vm.percent}% of {vm.total // 2**30}GB, disk {psutil.disk_usage('/').percent}% used"
    if bat:
        out += f", battery {bat.percent:.0f}%{' (charging)' if bat.power_plugged else ''}"
    if shutil.which("nvidia-smi"):
        g = subprocess.run(["nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu",
                            "--format=csv,noheader"], capture_output=True, text=True).stdout.strip()
        out += f", GPU {g}"
    return out


def open_app(name: str) -> str:
    exe = shutil.which(name.lower().replace(" ", "-")) or shutil.which(name.lower())
    if not exe:
        return f"I can't find an app called {name}."
    subprocess.Popen([exe], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return f"Opened {name}."


def open_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return f"Opening {url}."


def open_path(path: str) -> str:
    p = os.path.expanduser(path)
    if not os.path.exists(p):
        return "That path does not exist."
    subprocess.Popen(["xdg-open", p], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return f"Opening {p}."


def set_volume(percent: int) -> str:
    percent = max(0, min(100, int(percent)))
    if shutil.which("wpctl"):
        cmd = ["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{percent}%"]
    elif shutil.which("amixer"):
        cmd = ["amixer", "sset", "Master", f"{percent}%"]
    else:
        return "No volume control found (install pipewire or alsa-utils)."
    subprocess.run(cmd, capture_output=True)
    return f"Volume set to {percent}%."


def set_brightness(percent: int) -> str:
    if not shutil.which("brightnessctl"):
        return "brightnessctl is not installed."
    subprocess.run(["brightnessctl", "set", f"{max(5, min(100, int(percent)))}%"], capture_output=True)
    return f"Brightness set to {percent}%."


def media_control(action: str) -> str:
    acts = {"play": "play", "pause": "pause", "toggle": "play-pause", "next": "next", "previous": "previous", "stop": "stop"}
    if action not in acts:
        return f"Action must be one of {', '.join(acts)}."
    if not shutil.which("playerctl"):
        return "playerctl is not installed."
    r = subprocess.run(["playerctl", acts[action]], capture_output=True, text=True)
    return "Done." if r.returncode == 0 else (r.stderr.strip() or "No media player is running.")


def lock_screen() -> str:
    if not confirm("Lock the screen?"):
        return "Cancelled."
    subprocess.run(["loginctl", "lock-session"])
    return "Locked."


def run_shell(command: str) -> str:
    low = command.lower()
    if any(p in low for p in config.BLOCKED_PATTERNS):
        return "Blocked: that command is on the never-run list."
    try:
        first = shlex.split(command)[0]
    except (ValueError, IndexError):
        return "Could not parse that command."
    chained = any(c in command for c in [";", "&&", "||", "|", ">", "`", "$("])
    if first not in config.SAFE_COMMANDS or chained:
        if not confirm(f"Run shell command: {command}?"):
            return "Cancelled by user."
    try:
        r = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=60)
        return ((r.stdout or "") + (r.stderr or "")).strip()[-3000:] or "(no output)"
    except subprocess.TimeoutExpired:
        return "Command timed out after 60s."


# =============================================================== files / notes / memory
def read_file(path: str) -> str:
    p = os.path.expanduser(path)
    if not os.path.isfile(p):
        return "File not found."
    with open(p, errors="ignore") as f:
        return f.read(6000)


def find_files(pattern: str, directory: str = "~") -> str:
    import fnmatch
    import time
    root, hits, t0 = os.path.expanduser(directory), [], time.time()
    pat = f"*{pattern}*" if not any(c in pattern for c in "*?[") else pattern
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if not d.startswith(".") and d not in ("node_modules", "__pycache__")]
        for fn in fns:
            if fnmatch.fnmatch(fn.lower(), pat.lower()):
                hits.append(os.path.join(dp, fn))
        if len(hits) >= 10 or time.time() - t0 > 6:
            break
    return "\n".join(hits) or "No matching files."


def take_note(text: str) -> str:
    f = config.NOTES_DIR / f"{datetime.now():%Y-%m-%d}.md"
    with open(f, "a") as fh:
        fh.write(f"- {datetime.now():%H:%M} {text}\n")
    return "Note saved."


def remember_fact(fact: str) -> str:
    return memory.remember(fact)


def search_notes(query: str) -> str:
    memory.index_notes()
    return memory.search_notes(query)


# =============================================================== information
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv, ast.USub: operator.neg}


def calculate(expression: str) -> str:
    def ev(n):
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.operand))
        raise ValueError("unsupported")
    try:
        return str(ev(ast.parse(expression.replace("^", "**"), mode="eval").body))
    except Exception:
        return "I could not evaluate that expression."


def web_search(query: str) -> str:
    try:
        from ddgs import DDGS
        res = DDGS().text(query, max_results=5)
        return "\n".join(f"- {r['title']}: {r['body'][:220]}" for r in res) or "No results."
    except Exception as e:
        return f"Web search is unavailable (offline?): {e}"


def get_weather(city: str) -> str:
    try:
        url = f"https://wttr.in/{urllib.parse.quote(city)}?format=3"
        with urllib.request.urlopen(url, timeout=8) as r:
            return r.read().decode().strip()
    except Exception as e:
        return f"Could not fetch the weather (offline?): {e}"


def set_timer(seconds: int, label: str = "Timer") -> str:
    seconds = int(seconds)
    threading.Timer(seconds, lambda: notify(f"{label} is done, sir.")).start()
    m, s = divmod(seconds, 60)
    return f"Timer set for {m} minutes {s} seconds." if m else f"Timer set for {s} seconds."


# =============================================================== vision
def look_at_screen(question: str = "Describe what is on the screen.") -> str:
    try:
        return vision.look_at_screen(question)
    except Exception as e:
        return f"Screen vision failed: {e}. Is '{config.VISION_MODEL}' pulled?"


def describe_image(path: str, question: str = "Describe this image.") -> str:
    p = os.path.expanduser(path)
    if not os.path.isfile(p):
        return "Image not found."
    try:
        return vision.ask_image(p, question)
    except Exception as e:
        return f"Image analysis failed: {e}"


# =============================================================== pentest
def pentest_start(name: str, scope: str) -> str:
    return pentest.start(name, scope, confirm)


def pentest_status() -> str:
    return pentest.status()


def pentest_scan(tool: str, target: str) -> str:
    return pentest.run_scan(tool, target, notify)


def pentest_scan_output(scan_id: str = "") -> str:
    return pentest.scan_output(scan_id)


def pentest_add_finding(title: str, severity: str, target: str, description: str,
                        evidence: str = "", remediation: str = "") -> str:
    return pentest.add_finding(title, severity, target, description, evidence, remediation)


def pentest_list_findings() -> str:
    return pentest.list_findings()


def pentest_report() -> str:
    return pentest.generate_report()


# =============================================================== registry
def _fn(name, desc, props=None, required=None):
    return {"type": "function", "function": {
        "name": name, "description": desc,
        "parameters": {"type": "object", "properties": props or {}, "required": required or []}}}


_S = lambda d: {"type": "string", "description": d}
_I = lambda d: {"type": "integer", "description": d}

_TOOL_LIST = [
    (get_time, _fn("get_time", "Current date and time.")),
    (system_status, _fn("system_status", "CPU, RAM, disk, battery and GPU status.")),
    (open_app, _fn("open_app", "Launch a desktop app by name.", {"name": _S("app name, e.g. firefox")}, ["name"])),
    (open_url, _fn("open_url", "Open a website in the browser.", {"url": _S("URL")}, ["url"])),
    (open_path, _fn("open_path", "Open a file or folder with its default app.", {"path": _S("path")}, ["path"])),
    (set_volume, _fn("set_volume", "Set system volume 0-100.", {"percent": _I("0-100")}, ["percent"])),
    (set_brightness, _fn("set_brightness", "Set screen brightness 5-100.", {"percent": _I("5-100")}, ["percent"])),
    (media_control, _fn("media_control", "Control music/video playback.",
                        {"action": {"type": "string", "enum": ["play", "pause", "toggle", "next", "previous", "stop"]}}, ["action"])),
    (lock_screen, _fn("lock_screen", "Lock the screen (asks for confirmation).")),
    (run_shell, _fn("run_shell", "Run a shell command on this Linux machine. Risky ones ask the user first.", {"command": _S("the command")}, ["command"])),
    (read_file, _fn("read_file", "Read the start of a text file.", {"path": _S("file path")}, ["path"])),
    (find_files, _fn("find_files", "Find files by name under a folder.", {"pattern": _S("name or glob"), "directory": _S("folder, default home")}, ["pattern"])),
    (take_note, _fn("take_note", "Append a note to today's notes file.", {"text": _S("note")}, ["text"])),
    (remember_fact, _fn("remember_fact", "Store a durable fact about the user in long-term memory.", {"fact": _S("the fact")}, ["fact"])),
    (search_notes, _fn("search_notes", "Semantic search over the user's notes folder.", {"query": _S("what to look for")}, ["query"])),
    (calculate, _fn("calculate", "Evaluate an arithmetic expression exactly.", {"expression": _S("e.g. 12*(3+4)")}, ["expression"])),
    (web_search, _fn("web_search", "Search the web (needs internet).", {"query": _S("search query")}, ["query"])),
    (get_weather, _fn("get_weather", "Current weather for a city (needs internet).", {"city": _S("city name")}, ["city"])),
    (set_timer, _fn("set_timer", "Set a countdown timer; Jarvis speaks when it ends.", {"seconds": _I("duration in seconds"), "label": _S("what it is for")}, ["seconds"])),
    (look_at_screen, _fn("look_at_screen", "Take a screenshot and answer a question about what is on screen (read text, explain an error, describe a window).", {"question": _S("what to look for")})),
    (describe_image, _fn("describe_image", "Answer a question about an image file.", {"path": _S("image path"), "question": _S("question")}, ["path"])),
    (pentest_start, _fn("pentest_start", "Start or resume a pentest engagement with an authorised scope (asks the user to confirm).", {"name": _S("engagement name"), "scope": _S("comma-separated IPs, CIDR ranges or hostnames")}, ["name", "scope"])),
    (pentest_status, _fn("pentest_status", "Show the active pentest engagement, scans and findings count.")),
    (pentest_scan, _fn("pentest_scan", "Run a scan in the background against an in-scope target.", {"tool": {"type": "string", "enum": pentest.SCAN_TOOLS}, "target": _S("in-scope IP or host")}, ["tool", "target"])),
    (pentest_scan_output, _fn("pentest_scan_output", "Read a finished scan's output so it can be summarised. Empty scan_id means the latest.", {"scan_id": _S("e.g. s1")})),
    (pentest_add_finding, _fn("pentest_add_finding", "Record a vulnerability finding for the report.", {"title": _S("short title"), "severity": {"type": "string", "enum": pentest.SEVERITIES}, "target": _S("affected host/port"), "description": _S("what it is and impact"), "evidence": _S("proof, e.g. scan line"), "remediation": _S("how to fix")}, ["title", "severity", "target", "description"])),
    (pentest_list_findings, _fn("pentest_list_findings", "List recorded findings.")),
    (pentest_report, _fn("pentest_report", "Generate the pentest report (Markdown, plus HTML if pandoc is installed).")),
]

TOOLS = {f.__name__: (f, schema) for f, schema in _TOOL_LIST}
SCHEMAS = [s for _, s in _TOOL_LIST]


def call(name: str, args: dict) -> str:
    if name not in TOOLS:
        return f"Unknown tool {name}."
    try:
        return str(TOOLS[name][0](**args))
    except Exception as e:  # keep the assistant alive on tool errors
        return f"Tool {name} failed: {e}"
