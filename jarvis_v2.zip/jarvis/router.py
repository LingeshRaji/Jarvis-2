"""Instant command router: handles everyday commands in English and Tamil *without* the language model.

Why: these requests are deterministic. Running them directly is instant (no LLM wait), and the reply is built from
what the tool really returned, so Jarvis can never say "opening Firefox" unless it actually opened.
Anything the router does not recognise falls through to the LLM.
"""
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

import apps
from results import is_error, reason

Say = Callable[[list, str], str]


@dataclass
class Plan:
    name: str
    calls: list            # [(tool_name, args)]
    say: Say               # (results, lang) -> text to speak


# ----------------------------------------------------------------------------------- helpers
def failed(res: str) -> bool:
    """A tool failed when its result starts with "ERROR: " (the convention in results.py)."""
    return is_error(res)


def speakable(text: str, limit: int = 260) -> str:
    """What is actually said aloud: no ERROR marker, and not an essay."""
    text = reason(text).strip()
    if len(text) <= limit:
        return text
    cut = text[:limit]
    end = max(cut.rfind(". "), cut.rfind("; "), cut.rfind(": "))
    return (cut[:end + 1] if end > 80 else cut.rsplit(" ", 1)[0] + "…")


_TA_UNITS = ["பூஜ்யம்", "ஒன்று", "இரண்டு", "மூன்று", "நான்கு", "ஐந்து", "ஆறு", "ஏழு", "எட்டு", "ஒன்பது", "பத்து",
             "பதினொன்று", "பன்னிரண்டு", "பதிமூன்று", "பதினான்கு", "பதினைந்து", "பதினாறு", "பதினேழு", "பதினெட்டு",
             "பத்தொன்பது"]
_TA_TENS = {2: "இருபது", 3: "முப்பது", 4: "நாற்பது", 5: "ஐம்பது", 6: "அறுபது", 7: "எழுபது", 8: "எண்பது", 9: "தொண்ணூறு"}
_TA_TENS_PREFIX = {2: "இருபத்து", 3: "முப்பத்து", 4: "நாற்பத்து", 5: "ஐம்பத்து", 6: "அறுபத்து", 7: "எழுபத்து",
                   8: "எண்பத்து", 9: "தொண்ணூற்று"}


def ta_num(n: int) -> str:
    """Number in Tamil words (the Tamil voice cannot read digits)."""
    n = int(n)
    if n < 20:
        return _TA_UNITS[n]
    if n < 100:
        t, u = divmod(n, 10)
        return _TA_TENS[t] if u == 0 else f"{_TA_TENS_PREFIX[t]} {_TA_UNITS[u]}"
    if n == 100:
        return "நூறு"
    return str(n)


_TA_DAYS = ["திங்கள்", "செவ்வாய்", "புதன்", "வியாழன்", "வெள்ளி", "சனி", "ஞாயிறு"]
_TA_MONTHS = ["ஜனவரி", "பிப்ரவரி", "மார்ச்", "ஏப்ரல்", "மே", "ஜூன்", "ஜூலை", "ஆகஸ்ட்", "செப்டம்பர்", "அக்டோபர்",
              "நவம்பர்", "டிசம்பர்"]


def ta_period(h: int) -> str:
    return "அதிகாலை" if h < 5 else "காலை" if h < 12 else "மதியம்" if h < 16 else "மாலை" if h < 19 else "இரவு"


def _ok(res: str) -> str:
    return res.rstrip(".") + ", sir."


SITES = {
    "youtube": "https://www.youtube.com", "google": "https://www.google.com", "gmail": "https://mail.google.com",
    "github": "https://github.com", "whatsapp": "https://web.whatsapp.com", "linkedin": "https://www.linkedin.com",
    "reddit": "https://www.reddit.com", "twitter": "https://x.com", "facebook": "https://www.facebook.com",
    "instagram": "https://www.instagram.com", "netflix": "https://www.netflix.com", "amazon": "https://www.amazon.in",
    "wikipedia": "https://www.wikipedia.org", "maps": "https://maps.google.com", "googlemaps": "https://maps.google.com",
    "drive": "https://drive.google.com", "googledrive": "https://drive.google.com", "claude": "https://claude.ai",
    "tryhackme": "https://tryhackme.com", "hackthebox": "https://www.hackthebox.com",
    "portswigger": "https://portswigger.net/web-security", "exploitdb": "https://www.exploit-db.com",
    "stackoverflow": "https://stackoverflow.com",
}
_TA_SITES = {"யூடியூப்": "youtube", "கூகுள்": "google", "ஜிமெயில்": "gmail", "கிட்ஹப்": "github", "வாட்ஸ்அப்": "whatsapp"}
FOLDERS = {"downloads": "~/Downloads", "download": "~/Downloads", "documents": "~/Documents", "pictures": "~/Pictures",
           "photos": "~/Pictures", "music": "~/Music", "videos": "~/Videos", "desktop": "~/Desktop", "home": "~",
           "notes": "~/jarvis_notes", "reports": "~/jarvis_reports"}

_POLITE = re.compile(
    r"^(?:(?:hey|hi|hello|ok|okay)[,\s]+)?(?:jarvis[,\s]+)?(?:(?:please|kindly)[,\s]+)?"
    r"(?:(?:can|could|would|will)\s+you\s+(?:please\s+)?|i\s+(?:want|need|would\s+like)\s+you\s+to\s+|"
    r"go\s+ahead\s+and\s+|let'?s\s+)?(?:please\s+)?", re.I)
_TAIL = re.compile(r"(?:[\s,.!?]+(?:please|sir|for\s+me|right\s+now|now|thanks|thank\s+you))*[\s,.!?]*$", re.I)


def clean(text: str) -> str:
    t = re.sub(r"[“”\"]", "", text.strip())
    t = _POLITE.sub("", t, count=1)
    t = _TAIL.sub("", t)
    return t.strip().lower()


_NUMWORDS = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
             "nine": 9, "ten": 10, "fifteen": 15, "twenty": 20, "thirty": 30, "forty": 40, "fortyfive": 45, "sixty": 60}
_DUR = r"(?:\d+(?:\.\d+)?|an?|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty[\s-]?five|forty|sixty)\s*(?:seconds?|secs?|minutes?|mins?|hours?|hrs?)"
_DUR_ITEM = re.compile(r"(\d+(?:\.\d+)?|an?|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty[\s-]?five|forty|sixty)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)")


def parse_seconds(s: str) -> int:
    s = s.lower()
    if re.search(r"half\s+an?\s+hour", s):
        return 1800
    total = 0.0
    for num, unit in _DUR_ITEM.findall(s):
        n = float(num) if re.fullmatch(r"\d+(?:\.\d+)?", num) else _NUMWORDS.get(re.sub(r"[\s-]", "", num), 1)
        total += n * (3600 if unit.startswith(("h")) else 60 if unit.startswith("m") else 1)
    return int(total)


def _fmt_dur(sec: int) -> str:
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    parts = [f"{h} hour{'s' if h != 1 else ''}" if h else "", f"{m} minute{'s' if m != 1 else ''}" if m else "",
             f"{s} second{'s' if s != 1 else ''}" if s else ""]
    return " ".join(p for p in parts if p)


def _fmt_dur_ta(sec: int) -> str:
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return " ".join(p for p in [f"{ta_num(h)} மணி நேரம்" if h else "", f"{ta_num(m)} நிமிடம்" if m else "",
                                f"{ta_num(s)} வினாடி" if s else ""] if p)


# ----------------------------------------------------------------------------------- plan builders
def _simple(name, calls, en=None, ta=None) -> Plan:
    def say(res, lang):
        r = res[0] if res else ""
        if lang == "ta":
            return ta(res) if (ta and not (res and failed(r))) else ("மன்னிக்கவும் ஐயா, முடியவில்லை." if res and failed(r) else "முடிந்தது ஐயா.")
        return (en(res) if en else _ok(r)) if not (res and failed(r)) else r
    return Plan(name, calls, say)


def _open_app_plan(target: str) -> Plan:
    def say(res, lang):
        r = res[0]
        if failed(r):
            return r if lang != "ta" else f"மன்னிக்கவும் ஐயா, {target} ஐ திறக்க முடியவில்லை."
        label = re.match(r"Opened (.+?)\.?$", r)
        label = label.group(1) if label else target
        return f"{label} திறக்கப்பட்டது ஐயா." if lang == "ta" else _ok(r)
    return Plan("open_app", [("open_app", {"name": target})], say)


def _open_url_plan(url: str, label: str) -> Plan:
    def say(res, lang):
        if failed(res[0]):
            return res[0] if lang != "ta" else "மன்னிக்கவும் ஐயா, திறக்க முடியவில்லை."
        return f"{label} திறக்கப்பட்டது ஐயா." if lang == "ta" else f"Opening {label}, sir."
    return Plan("open_url", [("open_url", {"url": url})], say)


def _time_plan() -> Plan:
    def say(res, lang):
        n = datetime.now()
        if lang == "ta":
            h12 = n.hour % 12 or 12
            return f"இப்போது {ta_period(n.hour)} {ta_num(h12)} மணி {ta_num(n.minute)} நிமிடம்." if n.minute else \
                   f"இப்போது {ta_period(n.hour)} {ta_num(h12)} மணி."
        return f"It's {n.strftime('%-I:%M %p')}, sir."
    return Plan("time", [("get_time", {})], say)


def _date_plan() -> Plan:
    def say(res, lang):
        n = datetime.now()
        if lang == "ta":
            return f"இன்று {_TA_DAYS[n.weekday()]}, {_TA_MONTHS[n.month - 1]} {ta_num(n.day)}."
        return f"Today is {n.strftime('%A, %-d %B %Y')}."
    return Plan("date", [("get_time", {})], say)


def _status_plan() -> Plan:
    def say(res, lang):
        r = res[0]
        cpu = re.search(r"CPU ([\d.]+)%", r)
        ram = re.search(r"RAM ([\d.]+)%", r)
        bat = re.search(r"battery (\d+)%(?: \(charging\))?", r)
        gpu = re.search(r"GPU ([\d.]+), ([\d.]+), ([\d.]+), ([\d.]+)", r)
        if lang == "ta":
            parts = []
            if cpu:
                parts.append(f"செயலி {ta_num(round(float(cpu.group(1))))} சதவீதம்")
            if ram:
                parts.append(f"நினைவகம் {ta_num(round(float(ram.group(1))))} சதவீதம்")
            if bat:
                parts.append(f"மின்கலம் {ta_num(int(bat.group(1)))} சதவீதம்")
            return ("; ".join(parts) + ".") if parts else "நிலை தெரியவில்லை."
        parts = []
        if cpu:
            parts.append(f"CPU at {round(float(cpu.group(1)))} percent")
        if ram:
            parts.append(f"memory at {round(float(ram.group(1)))} percent")
        if gpu:
            parts.append(f"GPU at {round(float(gpu.group(1)))} percent, {round(float(gpu.group(4)))} degrees")
        if bat:
            parts.append(f"battery at {bat.group(1)} percent{', charging' if 'charging' in r else ''}")
        return (", ".join(parts) + ", sir.") if parts else r
    return Plan("status", [("system_status", {})], say)


# ----------------------------------------------------------------------------------- the router
def _route(text: str, lang: str = "en") -> Plan | None:
    raw = text.strip().lower()
    t = clean(text)

    # ---- small talk (needs the raw text because clean() strips greetings)
    if re.fullmatch(r"(?:hello|hi|hey|hey\s+jarvis|hello\s+jarvis|hi\s+jarvis|good\s+(?:morning|afternoon|evening))[,.!\s]*(?:jarvis)?[.!]*", raw):
        def hi(res, lg):
            h = datetime.now().hour
            if lg == "ta":
                return "வணக்கம் ஐயா, எப்படி உதவலாம்?"
            return f"Good {'morning' if h < 12 else 'afternoon' if h < 18 else 'evening'}, sir. How can I help?"
        return Plan("greeting", [], hi)
    if re.fullmatch(r"(?:thanks|thank\s+you|thanks\s+jarvis|thank\s+you\s+jarvis|cheers)[.!\s]*", raw):
        return Plan("thanks", [], lambda r, lg: "வரவேற்கிறேன் ஐயா." if lg == "ta" else "You're welcome, sir.")
    if re.fullmatch(r"(?:வணக்கம்|ஹலோ)(?:\s*ஜார்விஸ்)?[.!\s]*", raw):
        return Plan("greeting", [], lambda r, lg: "வணக்கம் ஐயா, எப்படி உதவலாம்?")
    if re.match(r"^நன்றி", raw):
        return Plan("thanks", [], lambda r, lg: "வரவேற்கிறேன் ஐயா.")
    if not t:
        return None

    # ---- volume / mute
    if re.fullmatch(r"(?:turn\s+(?:the\s+)?(?:volume|sound|audio)\s+up|(?:volume|sound)\s+up|(?:increase|raise|boost|up)\s+(?:the\s+)?(?:volume|sound)|"
                    r"make\s+(?:it|the\s+(?:volume|sound))\s+(?:louder|higher)|louder|volume\s+higher)", t) or \
            re.search(r"(?:சத்தம்|ஒலி|வால்யூம்|சவுண்ட்)(?:\s*அளவை)?\s*(?:கூட்டு|கூட்டவும்|அதிகப்படுத்து|அதிகமாக்கு|ஏற்று)", t):
        return _simple("volume_up", [("change_volume", {"delta": 10})],
                       en=lambda r: _ok(r[0]), ta=lambda r: "ஒலி அளவு கூட்டப்பட்டது ஐயா.")
    if re.fullmatch(r"(?:turn\s+(?:the\s+)?(?:volume|sound|audio)\s+down|(?:volume|sound)\s+down|(?:decrease|lower|reduce|drop|down)\s+(?:the\s+)?(?:volume|sound)|"
                    r"make\s+(?:it|the\s+(?:volume|sound))\s+(?:quieter|lower|softer)|quieter|softer|volume\s+lower)", t) or \
            re.search(r"(?:சத்தம்|ஒலி|வால்யூம்|சவுண்ட்)(?:\s*அளவை)?\s*(?:குறை|குறைக்கவும்|குறைத்து\s*விடு|குறைவாக்கு)", t):
        return _simple("volume_down", [("change_volume", {"delta": -10})],
                       en=lambda r: _ok(r[0]), ta=lambda r: "ஒலி அளவு குறைக்கப்பட்டது ஐயா.")
    m = re.fullmatch(r"(?:set\s+|make\s+|put\s+|change\s+)?(?:the\s+)?(?:volume|sound)\s*(?:to|at)?\s*(\d{1,3})\s*(?:%|percent)?", t)
    if m:
        n = min(100, int(m.group(1)))
        return _simple("volume_set", [("set_volume", {"percent": n})], en=lambda r: _ok(r[0]),
                       ta=lambda r: f"ஒலி அளவு {ta_num(n)} சதவீதம் ஐயா.")
    m = re.fullmatch(r"(mute|unmute)(?:\s+(?:the\s+)?(?:sound|volume|audio|speakers?|it))?", t)
    if m or re.search(r"மியூட்|சத்தத்தை\s*நிறுத்து", t):
        un = bool(m and m.group(1) == "unmute")
        return _simple("mute", [("mute_audio", {"state": "off" if un else "on"})],
                       en=lambda r: ("Sound is back on, sir." if un else "Muted, sir."),
                       ta=lambda r: "சத்தம் நிறுத்தப்பட்டது ஐயா.")

    # ---- brightness
    if re.fullmatch(r"(?:turn\s+(?:the\s+)?brightness\s+up|brightness\s+up|(?:increase|raise|boost)\s+(?:the\s+)?brightness|brighter|make\s+(?:it|the\s+screen)\s+brighter)", t):
        return _simple("brightness_up", [("change_brightness", {"delta": 10})], en=lambda r: "Brightness up, sir.")
    if re.fullmatch(r"(?:turn\s+(?:the\s+)?brightness\s+down|brightness\s+down|(?:decrease|lower|reduce|dim)\s+(?:the\s+)?(?:brightness|screen)|dimmer|make\s+(?:it|the\s+screen)\s+dimmer)", t):
        return _simple("brightness_down", [("change_brightness", {"delta": -10})], en=lambda r: "Brightness down, sir.")
    m = re.fullmatch(r"(?:set\s+|make\s+|put\s+)?(?:the\s+)?(?:screen\s+)?brightness\s*(?:to|at)?\s*(\d{1,3})\s*(?:%|percent)?", t)
    if m:
        n = min(100, int(m.group(1)))
        return _simple("brightness_set", [("set_brightness", {"percent": n})], en=lambda r: _ok(r[0]))

    # ---- time / date / status
    if re.fullmatch(r"(?:what'?s?|what\s+is|tell\s+me|say|show\s+me)?\s*(?:the\s+)?(?:current\s+)?time(?:\s+(?:is\s+it|right\s+now|today|please))?", t) or \
            re.fullmatch(r"what\s+time\s+is\s+it(?:\s+(?:in\s+india|here))?", t) or \
            re.search(r"(?:இப்போது\s*)?(?:நேரம்|மணி)\s*(?:என்ன|எவ்வளவு|சொல்லு|சொல்லுங்கள்)", t):
        return _time_plan()
    if re.fullmatch(r"(?:what'?s?|what\s+is|tell\s+me)?\s*(?:the\s+|today'?s\s+)?(?:current\s+)?date(?:\s+today)?", t) or \
            re.fullmatch(r"what\s+day\s+is\s+(?:it|today)", t) or re.search(r"(?:இன்று\s*)?(?:தேதி|நாள்)\s*(?:என்ன|சொல்லு|சொல்லுங்கள்)", t):
        return _date_plan()
    if re.fullmatch(r"(?:how(?:'s|\s+is)\s+(?:my|the)\s+(?:system|pc|computer|laptop|machine)(?:\s+doing)?|system\s+(?:status|health|stats|report)|"
                    r"(?:cpu|ram|memory|gpu|battery|disk)(?:\s+(?:usage|status|level|percentage))?|check\s+(?:my\s+)?(?:system|battery|cpu|ram|gpu)|"
                    r"(?:what'?s?|what\s+is)\s+(?:my\s+|the\s+)?(?:battery|cpu|ram|memory|gpu)(?:\s+(?:level|usage|status))?)", t) or \
            re.search(r"சிஸ்டம்\s*(?:நிலை|ஸ்டேட்டஸ்)", t):
        return _status_plan()

    # ---- media keys
    m = re.fullmatch(r"(pause|resume|play|continue|stop)(?:\s+(?:the\s+)?(?:music|song|songs|video|media|playback|player|it))?", t)
    if m and (m.group(1) != "stop" or len(t.split()) > 1):
        act = {"pause": "pause", "resume": "play", "play": "play", "continue": "play", "stop": "stop"}[m.group(1)]
        return _simple("media", [("media_control", {"action": act})], en=lambda r: "Done, sir." if not failed(r[0]) else r[0])
    if re.fullmatch(r"(?:next|skip)(?:\s+(?:the\s+)?(?:song|track|one))?", t):
        return _simple("media_next", [("media_control", {"action": "next"})], en=lambda r: "Next track, sir.")
    if re.fullmatch(r"(?:previous|go\s+back|last)(?:\s+(?:the\s+)?(?:song|track))?", t):
        return _simple("media_prev", [("media_control", {"action": "previous"})], en=lambda r: "Previous track, sir.")

    # ---- screenshot / looking at the screen
    if re.fullmatch(r"(?:(?:take|capture|grab|make)\s+(?:a\s+)?screenshot|screenshot)", t) or re.search(r"ஸ்கிரீன்\s*ஷாட்", t):
        return _simple("screenshot", [("take_screenshot", {})], en=lambda r: r[0] if failed(r[0]) else "Screenshot saved, sir.",
                       ta=lambda r: "ஸ்கிரீன்ஷாட் சேமிக்கப்பட்டது ஐயா.")
    if re.fullmatch(r"(?:what'?s?|what\s+is)\s+(?:on|in)\s+(?:my|the)\s+screen|(?:read|describe|look\s+at|check)\s+(?:my|the)\s+screen|"
                    r"what\s+(?:do\s+you\s+see|am\s+i\s+(?:looking\s+at|seeing))", t):
        q = "Read out the main text on the screen." if t.startswith("read") else "Describe what is on the screen."
        return Plan("look", [("look_at_screen", {"question": q})], lambda r, lg: r[0])

    # ---- timers / reminders
    dur_group = rf"((?:{_DUR})(?:\s*(?:and\s+)?(?:{_DUR}))*|half\s+an?\s+hour)"
    m = (re.fullmatch(rf"(?:set\s+(?:a\s+)?|start\s+(?:a\s+)?)?(?:timer|alarm)\s+(?:for\s+)?{dur_group}", t) or
         re.fullmatch(rf"(?:set\s+(?:a\s+)?|start\s+(?:a\s+)?){dur_group}\s+(?:timer|alarm)", t) or
         re.fullmatch(rf"(?:remind\s+me\s+in|wake\s+me\s+(?:up\s+)?in)\s+{dur_group}(?:\s+to\s+(.+))?", t))
    if m:
        secs = parse_seconds(m.group(1))
        label = (m.group(2) if m.lastindex and m.lastindex >= 2 and m.group(2) else "Timer")
        if secs > 0:
            return _simple("timer", [("set_timer", {"seconds": secs, "label": label})],
                           en=lambda r: f"Timer set for {_fmt_dur(secs)}, sir.",
                           ta=lambda r: f"{_fmt_dur_ta(secs)} டைமர் வைக்கப்பட்டது ஐயா.")

    # ---- lock / notes
    if re.fullmatch(r"lock\s+(?:the\s+|my\s+)?(?:screen|computer|pc|laptop|system)|lock\s+(?:it|up)", t):
        return _simple("lock", [("lock_screen", {})], en=lambda r: r[0] if failed(r[0]) else "Locked, sir.")
    m = re.fullmatch(r"(?:take\s+a\s+note|make\s+a\s+note|note\s+down|note\s+that|write\s+down)(?:[:,]|\s+(?:that|to|of))?\s*(.+)", t)
    if m:
        return _simple("note", [("take_note", {"text": m.group(1).strip()})], en=lambda r: "Noted, sir." if not failed(r[0]) else r[0],
                       ta=lambda r: "குறிப்பு சேமிக்கப்பட்டது ஐயா.")

    # ---- briefing
    if re.search(r"\b(?:daily|morning|day)\s+(?:briefing|brief|summary|rundown)\b|\bbrief\s+me\b|\bcatch\s+me\s+up\b|"
                 r"\bwhat(?:'s|\s+is)\s+(?:my\s+)?(?:day|plan)\s+(?:like|for\s+today)|^briefing$|\b(?:my|the)\s+briefing\b|\bplan\s+for\s+(?:the|my)\s+day\b", t) or \
            re.search(r"இன்றைய\s*(?:சுருக்கம்|திட்டம்|நிலவரம்)|டெய்லி\s*பிரீஃபிங்", t):
        return Plan("briefing", [("daily_briefing", {"lang": lang})], lambda r, lg: reason(r[0]))

    # ---- calendar
    cal_words = r"(?:calendar|schedule|agenda|meetings?|appointments?|events?)"
    if re.search(r"\bnext\s+(?:meeting|event|appointment)\b|\bwhen\s+is\s+my\s+next\b", t) or re.search(r"அடுத்த\s*(?:கூட்டம்|நிகழ்வு)", t):
        return Plan("next_event", [("next_event", {"lang": lang})], lambda r, lg: reason(r[0]))
    if (re.search(rf"\b{cal_words}\b", t) and re.search(r"\b(?:what|show|check|read|tell|any|do\s+i\s+have|have\s+i\s+got|how)\b|^my\b", t)
            and not re.search(r"\b(?:add|create|delete|cancel|set\s+up|book)\b", t)) or \
            re.search(r"\bwhat\s+do\s+i\s+have\s+(?:on\s+)?(?:today|tomorrow|this\s+week|on\s+\w+day)\b", t) or \
            re.search(r"(?:கேலண்டர்|அட்டவணை|நிகழ்வுகள்|கூட்டங்கள்)", t):
        day = "today"
        dm = re.search(r"\b(today|tomorrow|this\s+week|next\s+7\s+days|the\s+week|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", t)
        if dm:
            day = dm.group(1)
        elif "நாளை" in t:
            day = "tomorrow"
        elif re.search(r"இந்த\s*வாரம்", t):
            day = "week"
        return Plan("calendar", [("calendar_events", {"day": day, "lang": lang})], lambda r, lg: reason(r[0]))

    # ---- mail
    mail_words = r"(?:e-?mails?|mails?|inbox|gmail)"
    m = re.fullmatch(rf"(?:search|find|look\s+for|any)\s+(?:my\s+)?(?:{mail_words}\s+)?(?:from|about|regarding|for)\s+(.+?)(?:\s+in\s+(?:my\s+)?{mail_words})?", t) \
        if re.search(rf"\b{mail_words}\b", t) else None
    if m:
        return Plan("search_mail", [("search_mail", {"query": m.group(1).strip()})], lambda r, lg: reason(r[0]))
    if re.search(rf"\bread\b.*\b(?:latest|last|newest|top|first|recent)\s+(?:{mail_words}|message)\b", t):
        return Plan("read_mail", [("read_mail", {"query": ""})], lambda r, lg: reason(r[0]))
    if (re.search(rf"\b{mail_words}\b", t) and re.search(r"\b(?:check|read|show|get|fetch|tell|what|any|new|unread|how\s+many|do\s+i\s+have|have\s+i\s+got)\b", t)
            and not re.match(r"(?:open|go\s+to|visit|launch)\b", t) and not re.search(r"\b(?:send|write|compose|reply|draft|delete)\b", t)) or \
            re.search(r"(?:மின்னஞ்சல்|இமெயில்|மெயில்)", t):
        return Plan("check_mail", [("check_mail", {"limit": 3, "lang": lang})], lambda r, lg: reason(r[0]))

    # ---- jobs
    if re.search(r"\b(?:show|list|check|what(?:'s|\s+is)|how\s+(?:many|are))\b.*\b(?:job\s+)?applications?\b|\bapplication\s+status\b|\bwhere\s+have\s+i\s+applied\b", t):
        return Plan("job_list", [("job_list", {})], lambda r, lg: reason(r[0]))
    if re.search(r"\bfollow-?\s?ups?\b", t) and re.search(r"\b(?:job|application|due|any|what)\b", t):
        return Plan("job_followups", [("job_followups", {})], lambda r, lg: reason(r[0]))
    m = re.fullmatch(r"(?:open|show)\s+(?:the\s+)?job\s+(?:boards?|sites?|portals?)\s+(?:for|to\s+find)\s+(.+?)(?:\s+in\s+([a-z ]+))?", t)
    if m:
        return Plan("job_boards", [("job_open_boards", {"query": m.group(1).strip(), "location": (m.group(2) or "").strip()})],
                    lambda r, lg: reason(r[0]))
    m = re.fullmatch(r"(?:find|search(?:\s+for)?|look\s+for|get)\s+(?:me\s+)?(?:some\s+|any\s+)?(.+?)\s+(?:jobs?|openings?|vacanc(?:y|ies)|positions?)(?:\s+(?:in|near|at)\s+([a-z ]+))?", t)
    if m:
        def jobs_say(r, lg):
            if failed(r[0]):
                return reason(r[0])
            lines = [re.sub(r"^\d+\.\s*", "", x) for x in r[0].splitlines()[:3]]
            return "Top results: " + "; ".join(f"number {i}, {x}" for i, x in enumerate(lines, 1)) + ". Say track number and the digit to save one."
        return Plan("job_search", [("job_search", {"query": m.group(1).strip(), "location": (m.group(2) or "").strip()})], jobs_say)
    m = re.fullmatch(r"(?:track|save|add)\s+(?:job\s+|result\s+|number\s+)+(\d|one|two|three|four|five|six)", t)
    if m:
        n = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6}.get(m.group(1)) or int(m.group(1))
        return Plan("job_track", [("job_track", {"from_result": n})], lambda r, lg: reason(r[0]))
    m = re.fullmatch(r"(?:i\s+(?:have\s+|'ve\s+)?applied\s+(?:to|for|at)|mark)\s+(.+?)(?:\s+as\s+(applied|interview|offer|rejected|withdrawn))?", t)
    if m and (m.group(2) or t.startswith("i")):
        return Plan("job_update", [("job_update", {"ref": m.group(1).strip(), "status": m.group(2) or "applied"})],
                    lambda r, lg: reason(r[0]))

    # ---- web: play/search in the browser
    m = re.fullmatch(r"play\s+(.+?)\s+on\s+youtube", t)
    if m:
        from urllib.parse import quote_plus
        return _open_url_plan(f"https://www.youtube.com/results?search_query={quote_plus(m.group(1))}", "YouTube")
    m = re.fullmatch(r"(?:search|google|look\s+up)\s+(?:for\s+)?(.+?)(?:\s+(?:on|in)\s+(google|youtube|the\s+web|the\s+internet))?", t)
    if m and not re.search(r"\b(files?|folders?|documents?|notes?)\b", m.group(1)) and not m.group(1).startswith("my "):
        from urllib.parse import quote_plus
        q, where = m.group(1), (m.group(2) or "google")
        if where == "youtube":
            return _open_url_plan(f"https://www.youtube.com/results?search_query={quote_plus(q)}", f"YouTube search for {q}")
        return _open_url_plan(f"https://www.google.com/search?q={quote_plus(q)}", f"a search for {q}")

    # ---- open / close apps, sites and folders
    m = re.fullmatch(r"(?:(open|launch|start|run|fire\s+up|bring\s+up|go\s+to|visit|browse(?:\s+to)?))\s+(?:up\s+)?(?:the\s+|my\s+|a\s+)?(.+?)(?:\s+(?:app|application|program|website|site|page))?", t)
    ta_m = re.fullmatch(r"(.+?)(?:ை|ஐ)?\s+(?:திறக்கவும்|திறங்கள்|திறந்து\s*விடு|திறந்துவிடு|திற|ஓபன்\s*பண்(?:ணு|ணுங்கள்|ணுங்க)|ஓபன்\s*செய்(?:யவும்|யுங்கள்)?|ஓபன்)", t)
    if m or ta_m:
        verb = m.group(1) if m else "open"
        target = (m.group(2) if m else ta_m.group(1)).strip()
        if re.search(r"\b(and|then)\b", target):
            return None                                           # compound request: let the LLM plan it
        tn = apps.norm(_TA_SITES.get(target, target))
        if re.search(r"\b(folder|directory)\b", target) or tn in FOLDERS and ("folder" in t or not apps.resolve(target)):
            key = apps.norm(re.sub(r"\b(folder|directory)\b", "", target))
            path = FOLDERS.get(key)
            if path:
                return Plan("open_path", [("open_path", {"path": path})],
                            lambda r, lg: r[0] if failed(r[0]) else (f"{target} திறக்கப்பட்டது ஐயா." if lg == "ta" else _ok(r[0])))
        if target.startswith(("~", "/")):
            return Plan("open_path", [("open_path", {"path": target})], lambda r, lg: r[0] if failed(r[0]) else _ok(r[0]))
        if re.fullmatch(r"(?:https?://)?(?:www\.)?[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:/\S*)?", target):
            return _open_url_plan(target, target)
        if tn in SITES and not (verb in ("start", "run")):
            return _open_url_plan(SITES[tn], target.title())
        if verb in ("go to", "visit", "browse", "browse to"):
            return None
        if verb in ("start", "run") and not apps.resolve(target):
            return None                                           # "run a scan" etc. is not an app
        if not apps.resolve(target) and (len(target.split()) > 3 or re.search(r"\b(report|file|document|note|screenshot|picture|photo)s?\b", target)):
            return None
        return _open_app_plan(target)

    m = re.fullmatch(r"(?:close|quit|kill|terminate)\s+(?:the\s+|my\s+)?(.+?)(?:\s+(?:app|application|window))?", t)
    ta_c = re.fullmatch(r"(.+?)(?:ை|ஐ)?\s+(?:மூடு|மூடவும்|மூடுங்கள்|குளோஸ்\s*பண்ணு|குளோஸ்)", t)
    if m or ta_c:
        target = (m.group(1) if m else ta_c.group(1)).strip()
        return Plan("close_app", [("close_app", {"name": target})],
                    lambda r, lg: r[0] if failed(r[0]) and lg != "ta" else
                    (f"{target} மூடப்பட்டது ஐயா." if lg == "ta" and not failed(r[0]) else
                     "மன்னிக்கவும் ஐயா, முடியவில்லை." if lg == "ta" else _ok(r[0])))
    return None


def route(text: str, lang: str = "en") -> Plan | None:
    """Plan for a request the router understands, else None (the language model handles it)."""
    plan = _route(text, lang)
    if plan is None:
        return None
    inner = plan.say
    plan.say = lambda res, lg: speakable(inner(res, lg))
    return plan
