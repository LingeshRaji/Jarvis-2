"""Long-term memory (facts) + simple semantic search over notes, all local via SQLite + Ollama embeddings."""
import sqlite3
import time
import numpy as np
import ollama
import config

EMBED_MODEL = config.EMBED_MODEL
_client = ollama.Client(host=config.OLLAMA_HOST)


def _db():
    con = sqlite3.connect(config.MEMORY_DB)
    con.execute("CREATE TABLE IF NOT EXISTS facts (id INTEGER PRIMARY KEY, ts REAL, text TEXT, emb BLOB)")
    con.execute("CREATE TABLE IF NOT EXISTS chunks (id INTEGER PRIMARY KEY, path TEXT, mtime REAL, text TEXT, emb BLOB)")
    return con


def _embed(text: str) -> np.ndarray:
    v = _client.embeddings(model=EMBED_MODEL, prompt=text)["embedding"]
    a = np.array(v, dtype=np.float32)
    return a / (np.linalg.norm(a) + 1e-9)


def remember(text: str) -> str:
    con = _db()
    con.execute("INSERT INTO facts (ts, text, emb) VALUES (?,?,?)", (time.time(), text, _embed(text).tobytes()))
    con.commit()
    return f"Remembered: {text}"


def _search(table: str, query: str, k: int):
    con = _db()
    rows = con.execute(f"SELECT text, emb FROM {table}").fetchall()
    if not rows:
        return []
    q = _embed(query)
    scored = [(float(np.dot(q, np.frombuffer(e, dtype=np.float32))), t) for t, e in rows]
    scored.sort(reverse=True)
    return scored[:k]


def recall(query: str, k: int = 4) -> list[str]:
    return [t for s, t in _search("facts", query, k) if s > 0.45]


def index_notes() -> str:
    """(Re)index .txt/.md files in the notes folder. Cheap: skips unchanged files."""
    con = _db()
    n = 0
    for p in config.NOTES_DIR.rglob("*"):
        if p.suffix.lower() not in {".txt", ".md"}:
            continue
        mt = p.stat().st_mtime
        row = con.execute("SELECT mtime FROM chunks WHERE path=? LIMIT 1", (str(p),)).fetchone()
        if row and row[0] >= mt:
            continue
        con.execute("DELETE FROM chunks WHERE path=?", (str(p),))
        text = p.read_text(errors="ignore")
        for i in range(0, len(text), 800):
            chunk = text[i:i + 900]
            if chunk.strip():
                con.execute("INSERT INTO chunks (path, mtime, text, emb) VALUES (?,?,?,?)",
                            (str(p), mt, chunk, _embed(chunk).tobytes()))
                n += 1
    con.commit()
    return f"Indexed {n} new chunks from {config.NOTES_DIR}"


def search_notes(query: str, k: int = 3) -> str:
    hits = [t for s, t in _search("chunks", query, k) if s > 0.4]
    return "\n---\n".join(hits) if hits else "No relevant notes found."
