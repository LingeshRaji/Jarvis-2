"""The Jarvis brain: instant command router + streaming LLM with tool calling + speech-to-speech loop.

How a request is handled
  1. router.route(): everyday commands (open an app, volume, time, mail, calendar, jobs...) run straight away,
     with no language model, and the reply is built from what the tool really returned.
  2. Everything else goes to the LLM with only the tools that could be relevant (smaller prompt = faster).
  3. Honesty guard: for "do this" requests the model's first words are held back. If it answers "Done, I opened X"
     without calling a tool, it is told to actually call one; if it still does not, Jarvis says plainly that nothing
     happened. Jarvis never speaks a success it did not get from a tool.

The Assistant knows nothing about the UI. It reports everything through `emit(type, **data)`, which the web server
forwards to the HUD (and the CLI prints). Events:
  state(state)            idle | listening | thinking | tool | speaking
  level(value, src)       0..1 audio level for the visualiser (src = mic | voice)
  user(text, lang)        what the user said / typed
  token(text)             streamed reply text
  reply_end(text)         full reply
  tool(name, args)        a tool is being run;  tool_result(name, result)
  confirm(id, prompt)     the user must approve something
  notice(text)            background job messages
  status(text, ok)        model loading / errors
  timing(...)             seconds: stt, first_sound, total, route
  voice_changed(lang, id) the selected voice changed
"""
import concurrent.futures as cf
import json
import queue
import re
import threading
import time
import uuid
from datetime import datetime

import ollama

import briefing
import config
import memory
import router
import tools
import voices
from results import is_error, reason

YES = {"yes", "yeah", "yep", "confirm", "proceed", "go ahead", "do it", "sure", "ok", "okay",
       "ஆம்", "ஆமா", "ஆமாம்", "சரி", "செய்", "ம்ம்"}
NO = {"no", "nope", "cancel", "stop", "don't", "deny", "வேண்டாம்", "இல்லை", "நிறுத்து"}

# --- honesty guard ----------------------------------------------------------------------------------
_ACTION = re.compile(
    r"\b(open|launch|start|close|quit|run|play|pause|resume|set|turn|increase|decrease|raise|lower|mute|unmute|lock|"
    r"take|capture|send|email|search|find|create|write|save|delete|remove|install|scan|check|read|apply|add|schedule|"
    r"remind|track|update|mark|copy|download|show|get|make|switch|enable|disable|type|click|screenshot|note|"
    r"prepare|draft)\b|திற|மூடு|போடு|செய்|அனுப்பு|தேடு|சேமி|எடு|நிறுத்து|ஓபன்|குளோஸ்|வை\b")
_QUESTION = re.compile(r"^(what|why|how|who|when|where|which|explain|tell me|describe|is |are |do you|does |did |"
                       r"can you tell|define|summari[sz]e|translate)\b")
_CLAIM = re.compile(
    r"\b(?:i(?:'ve|\s+have|'ll|\s+will)?\s+(?:just\s+)?(?:open|launch|start|clos|send|sav|set|turn|play|creat|delet|remov|"
    r"install|mut|lock|tak|captur|schedul|add|updat|mark|writ|complet|finish)\w*|"
    r"(?:opening|launching|starting|closing|sending|saving|playing|muting|locking|taking|scheduling)\b|"
    r"(?:it'?s|it\s+is|has\s+been|have\s+been|is\s+now)\s+(?:done|open|opened|launched|started|closed|sent|saved|set)\b|"
    r"done\b|all\s+set|on\s+it|right\s+away|will\s+do|there\s+you\s+go|sure\s+thing)"
    r"|திறக்கிறேன்|திறந்தேன்|செய்தேன்|முடிந்தது|அனுப்பினேன்|சேமித்தேன்|மூடினேன்|திறக்கப்பட்டது", re.I)
_TOOL_TAG = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.S)
NUDGE = ("You did not call any tool, so nothing has happened yet. Call the correct tool now. If no tool can do "
         "this, say plainly that you cannot do it. Do not claim success without a tool result.")
NOTHING_DONE = {"en": "I'm sorry, sir, I wasn't able to do that. Nothing was actually done.",
                "ta": "மன்னிக்கவும் ஐயா, என்னால் அதைச் செய்ய முடியவில்லை. எதுவும் நடக்கவில்லை."}
SAMPLE = {"en": "Good evening, sir. This is how I sound.",
          "ta": "வணக்கம் ஐயா. என் குரல் இப்படித்தான் இருக்கும்."}


def looks_like_action(text: str) -> bool:
    t = router.clean(text)
    return bool(_ACTION.search(t)) and not _QUESTION.match(t)


def claims_success(text: str) -> bool:
    return bool(_CLAIM.search(text or ""))


def extract_text_calls(text: str) -> tuple[str, list[dict]]:
    """Some small models print the tool call as <tool_call>{...}</tool_call> text instead of using the API."""
    calls = []
    for m in _TOOL_TAG.finditer(text):
        try:
            obj = json.loads(m.group(1))
            name, args = obj.get("name"), obj.get("arguments") or {}
            if isinstance(args, str):
                args = json.loads(args or "{}")
            if name in tools.TOOLS and isinstance(args, dict):
                calls.append({"function": {"name": name, "arguments": args}})
        except (ValueError, AttributeError):
            continue
    return (_TOOL_TAG.sub("", text).strip() if calls else text), calls


def _g(obj, key, default=None):
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def pop_sentences(buf: str, final: bool = False, early: bool = False) -> tuple[list[str], str]:
    """Split streamed text into speakable sentences. Returns (sentences, remainder).
    early=True also lets the very first sentence start at a comma, so speech begins sooner."""
    out, start = [], 0
    for m in re.finditer(r"[.!?।…]+[\"”')\]]*\s+|\n+", buf):
        piece = buf[start:m.end()]
        if len(piece.strip()) >= 12:
            out.append(piece.strip())
            start = m.end()
    rest = buf[start:]
    if early and not out:
        m = re.search(r"[,;:—–]\s", rest[24:])
        if m:
            cut = 24 + m.end()
            out.append(rest[:cut].strip())
            rest = rest[cut:]
    if final and rest.strip():
        out.append(rest.strip())
        rest = ""
    return out, rest


class _NotIdle:
    """Adapter so voice.wait_for_trigger can poll 'a turn has started'."""
    def __init__(self, idle: threading.Event):
        self.idle = idle

    def is_set(self) -> bool:
        return not self.idle.is_set()


class Assistant:
    def __init__(self, emit, voice_enabled: bool = True):
        self.emit = emit
        self.voice_enabled = voice_enabled
        self.client = ollama.Client(host=config.OLLAMA_HOST)
        self.history: list[dict] = []
        self.mode = config.LANGUAGE_MODE
        self.state = "idle"
        self.tts_enabled = True
        self.mic_enabled = True
        self.idle = threading.Event()
        self.idle.set()
        self.trigger = threading.Event()
        self._cancel = threading.Event()
        self._quit = threading.Event()
        self._turns: queue.Queue = queue.Queue()
        self._confirms: dict[str, dict] = {}
        self._pool = cf.ThreadPoolExecutor(max_workers=2)
        self._tm: dict = {}
        self._spoke = False
        self.speaker = None
        self._voice = None
        if voice_enabled:
            import voice as _voice
            self._voice = _voice
            self.speaker = _voice.Speaker(level_cb=lambda v: self.emit("level", value=v, src="voice"),
                                          on_play=self._on_first_sound)
        tools.confirm = self.ask_confirm
        tools.notify = self.notify

    # ------------------------------------------------------------------ lifecycle
    @property
    def tts_voice_ids(self) -> dict:
        return {lang: voices.current(lang).id for lang in ("en", "ta")}

    def start(self) -> None:
        threading.Thread(target=self._worker, daemon=True).start()
        threading.Thread(target=self._warmup, daemon=True).start()
        if self.voice_enabled:
            threading.Thread(target=self._prewarm_speech, daemon=True).start()
            threading.Thread(target=self._voice_loop, daemon=True).start()

    def shutdown(self) -> None:
        self._quit.set()
        self.stop()

    def _prewarm_speech(self) -> None:
        self._voice.prewarm(lambda what: self.emit("status", text=f"{what} ready", ok=True))

    def _warmup(self) -> None:
        self.emit("status", text=f"Loading {config.LLM_MODEL}…", ok=None)
        try:
            self.client.chat(model=config.LLM_MODEL, messages=[{"role": "user", "content": "hi"}],
                             options={"num_predict": 1}, keep_alive=config.KEEP_ALIVE)
            self.emit("status", text=f"{config.LLM_MODEL} online", ok=True)
        except Exception as e:
            self.emit("status", text=f"Cannot reach Ollama / {config.LLM_MODEL}: {e}", ok=False)
            return
        lang = "ta" if self.mode == "ta" else "en"
        if config.BRIEFING_ON_START and briefing.configured() and briefing.due_today():
            try:
                text = briefing.build(lang)
                briefing.mark_done()
                self.say_verbatim(text)
                return
            except Exception as e:
                self.emit("status", text=f"Briefing failed: {str(e)[:100]}", ok=False)
        h = datetime.now().hour
        part = "morning" if h < 12 else "afternoon" if h < 18 else "evening"
        if lang == "ta":
            self.say_verbatim(f"வணக்கம் {config.USER_NAME}. அனைத்து அமைப்புகளும் தயார்.")
        else:
            self.say_verbatim(f"Good {part}, {config.USER_NAME}. All systems online.")

    # ------------------------------------------------------------------ state helpers
    def set_state(self, state: str) -> None:
        if state != self.state:
            self.state = state
            self.emit("state", state=state)

    def set_mode(self, mode: str) -> None:
        if mode in ("auto", *config.LANGUAGES):
            self.mode = mode
            self.emit("mode", mode=mode)

    def stop(self) -> None:
        """Interrupt thinking/speaking."""
        self._cancel.set()
        if self.speaker:
            self.speaker.stop()

    # ------------------------------------------------------------------ voices
    def get_voices(self) -> dict:
        return voices.listing()

    def preview_voice(self, lang: str, vid: str) -> None:
        if not self.speaker:
            self.emit("status", text="Voice output is switched off (--no-voice).", ok=False)
            return
        threading.Thread(target=lambda: self.speaker.say(SAMPLE.get(lang, SAMPLE["en"]), {lang: vid}),
                         daemon=True).start()

    def set_voice(self, lang: str, vid: str) -> None:
        threading.Thread(target=self._set_voice, args=(lang, vid), daemon=True).start()

    def _set_voice(self, lang: str, vid: str) -> None:
        v = voices.BY_ID.get(vid)
        if not v or v.lang != lang:
            self.emit("status", text=f"Unknown voice {vid}", ok=False)
            return
        try:
            if not voices.installed(v):
                self.emit("status", text=f"Downloading {v.label}…", ok=None)
                voices.ensure(v, progress=lambda t: self.emit("status", text=t, ok=None))
            voices.choose(lang, vid)
        except Exception as e:
            self.emit("status", text=f"Could not set {v.label}: {str(e)[:100]}. Are you online?", ok=False)
            self.emit("voice_changed", lang=lang, id=voices.current(lang).id)
            return
        self.emit("voice_changed", lang=lang, id=vid)
        self.emit("status", text=f"Voice: {v.label}", ok=True)
        self.preview_voice(lang, vid)

    # ------------------------------------------------------------------ input
    def submit_text(self, text: str, lang: str | None = None, meta: dict | None = None) -> None:
        text = text.strip()
        if not text:
            return
        lang = lang or ("ta" if any("஀" <= c <= "௿" for c in text) else "en")
        self.idle.clear()
        self._turns.put(("turn", text, lang, meta or {"t0": time.time()}))

    def say_verbatim(self, text: str) -> None:
        self.idle.clear()
        self._turns.put(("say", text, "ta" if self.mode == "ta" else "en", {}))

    def notify(self, text: str) -> None:
        self.emit("notice", text=text)
        self.say_verbatim(text)

    def request_listen(self) -> None:
        """Orb click / Space: interrupt whatever is happening and listen now."""
        if not self.voice_enabled:
            return
        if not self.idle.is_set():
            self.stop()
            self.idle.wait(4)
        self.trigger.set()

    # ------------------------------------------------------------------ voice loop
    def _voice_loop(self) -> None:
        v = self._voice
        while not self._quit.is_set():
            self.idle.wait()
            if not self.mic_enabled and not self.trigger.is_set():
                time.sleep(0.2)
                continue
            self.set_state("idle")
            try:
                src = v.wait_for_trigger(self.trigger, lambda x: self.emit("level", value=x, src="mic"),
                                         stop=_NotIdle(self.idle))
                if src is None:
                    continue
                self.set_state("listening")
                audio = v.record_until_silence(lambda x: self.emit("level", value=x, src="mic"))
                t_end = time.time()
                self.emit("level", value=0.0, src="mic")
                self.set_state("thinking")
                text, lang = v.transcribe(audio, self.mode)
                meta = {"t0": t_end - config.SILENCE_SECONDS, "stt": time.time() - t_end}
            except Exception as e:
                self.emit("status", text=f"Microphone/speech error: {e}", ok=False)
                self.set_state("idle")
                time.sleep(2)
                continue
            if text:
                self.submit_text(text, lang, meta)
            else:
                self.set_state("idle")

    # ------------------------------------------------------------------ confirm
    def ask_confirm(self, prompt: str) -> bool:
        cid = uuid.uuid4().hex[:8]
        ev = threading.Event()
        self._confirms[cid] = {"ev": ev, "ok": None}
        self.emit("confirm", id=cid, prompt=prompt)
        if self.speaker and self.tts_enabled:
            self.speaker.say(prompt + (" ஆம் என்றால் சொல்லுங்கள்." if self.mode == "ta" else " Say yes to confirm."))
            threading.Thread(target=self._voice_confirm, args=(cid,), daemon=True).start()
        ev.wait(30)
        ok = bool(self._confirms.pop(cid, {}).get("ok"))
        self.emit("confirm_done", id=cid, ok=ok)
        return ok

    def resolve_confirm(self, cid: str, ok: bool) -> None:
        c = self._confirms.get(cid)
        if c and c["ok"] is None:
            c["ok"] = ok
            c["ev"].set()

    def _voice_confirm(self, cid: str) -> None:
        try:
            self.speaker.wait(12)
            c = self._confirms.get(cid)
            if not c or c["ok"] is not None:
                return
            text, _ = self._voice.listen(lambda x: self.emit("level", value=x, src="mic"), self.mode)
            words = set(re.findall(r"[\w']+", text.lower()))
            if words & YES:
                self.resolve_confirm(cid, True)
            elif words & NO:
                self.resolve_confirm(cid, False)
        except Exception:
            pass

    # ------------------------------------------------------------------ worker
    def _worker(self) -> None:
        while not self._quit.is_set():
            kind, text, lang, meta = self._turns.get()
            self._cancel.clear()
            try:
                if kind == "say":
                    self._say_turn(text, lang)
                else:
                    self._run_turn(text, lang, meta)
            except Exception as e:
                self.emit("status", text=f"Error: {e}", ok=False)
                self.emit("reply_end", text="")
                if self.speaker and self.tts_enabled and kind == "turn":
                    offline = "connect" in str(e).lower() or "refused" in str(e).lower()
                    self.speaker.say(
                        ("மன்னிக்கவும், ஏதோ தவறு நடந்தது." if lang == "ta" else
                         "My language model isn't responding, sir. Please check that Ollama is running." if offline
                         else "Apologies, something went wrong."))
            finally:
                if self.speaker and self.tts_enabled:
                    self.speaker.wait(120)
                self._report_timing(final=True)
                self.set_state("idle")
                if self._turns.empty():
                    self.idle.set()

    # ------------------------------------------------------------------ timing
    def _on_first_sound(self) -> None:
        tm = self._tm
        if tm and tm.get("first") is None:
            tm["first"] = time.time() - tm["t0"]
            self._report_timing()

    def _report_timing(self, final: bool = False) -> None:
        tm = self._tm
        if not tm or tm.get("t0") is None:
            return
        if final and tm.get("done"):
            return
        data = {"route": tm.get("route", "llm"), "stt": tm.get("stt"), "first_sound": tm.get("first"),
                "reply": tm.get("reply")}
        self.emit("timing", **data)
        if final:
            tm["done"] = True
            bits = [f"{k.replace('_', ' ')} {v:.1f}s" for k, v in data.items() if isinstance(v, float)]
            print(f"[timing] {' · '.join(bits) or 'n/a'} ({data['route']})")

    # ------------------------------------------------------------------ speaking
    def _speak(self, sentence: str) -> None:
        if self.speaker and self.tts_enabled and not self._cancel.is_set():
            self.set_state("speaking")
            self.speaker.say(sentence)
            self._spoke = True

    def _say_turn(self, text: str, lang: str) -> None:
        self.emit("user", text="", lang=lang)
        self.emit("token", text=text)
        self.emit("reply_end", text=text)
        self._tm = {}
        self._speak(text)

    def _deliver(self, text: str, lang: str) -> str:
        """Show and speak a complete reply (used for routed commands and guard messages)."""
        text = text.strip()
        self._delivered = True
        self.emit("token", text=text)
        self.emit("reply_end", text=text)
        self._tm["reply"] = time.time() - self._tm["t0"]
        for s in pop_sentences(text, final=True, early=True)[0]:
            self._speak(s)
        return text

    # ------------------------------------------------------------------ one turn
    def _run_turn(self, text: str, lang: str, meta: dict | None = None) -> None:
        meta = meta or {}
        self._tm = {"t0": meta.get("t0") or time.time(), "stt": meta.get("stt"), "first": None, "route": "llm"}
        self._spoke = False
        self._delivered = False
        self.emit("user", text=text, lang=lang)
        self.set_state("thinking")
        reply_lang = self.mode if self.mode in config.LANGUAGES else lang

        # 1) instant path: no language model
        plan = None
        try:
            plan = router.route(text, reply_lang)
        except Exception as e:
            print(f"[router] {e}")
        if plan is not None:
            try:
                results = []
                for name, args in plan.calls:
                    self.set_state("tool")
                    self.emit("tool", name=name, args=args)
                    r = tools.call(name, args)
                    self.emit("tool_result", name=name, result=r[:300])
                    results.append(r)
                reply = plan.say(results, reply_lang)
            except Exception as e:
                print(f"[router] plan failed ({e}); falling back to the language model")
            else:
                self._tm["route"] = "instant"
                final = self._deliver(reply, reply_lang)
                self.history += [{"role": "user", "content": text}, {"role": "assistant", "content": final}]
                self.history = self.history[-8:]
                return

        # 2) language model path
        facts = self._recall(text)
        sys_msg = config.SYSTEM_PROMPT
        sys_msg += f"\n\nThe user is speaking {config.LANGUAGES[reply_lang]} right now: reply in {config.LANGUAGES[reply_lang]}."
        sys_msg += f"\nNow: {datetime.now():%A %d %B %Y, %I:%M %p}."
        if facts:
            sys_msg += "\n\nKnown facts about the user:\n- " + "\n- ".join(facts)

        schemas = tools.select_schemas(text)
        guard = looks_like_action(text)
        messages = [{"role": "system", "content": sys_msg}] + self.history[-6:] + [{"role": "user", "content": text}]
        final_text, results, retried = "", [], False

        for _ in range(5):
            hold = guard and not results
            round_text, calls = self._stream_round(messages, schemas, hold)
            if self._cancel.is_set():
                break
            if hold and not calls:
                if claims_success(round_text):
                    if not retried:
                        retried = True
                        messages += [{"role": "assistant", "content": round_text}, {"role": "user", "content": NUDGE}]
                        continue
                    final_text = self._deliver(NOTHING_DONE[reply_lang if reply_lang in NOTHING_DONE else "en"], reply_lang)
                    break
                final_text = self._release(round_text, reply_lang)       # a harmless answer: say it now
                break
            if not calls:
                final_text = round_text
                break
            messages.append({"role": "assistant", "content": "", "tool_calls": calls})
            for c in calls:
                name, args = c["function"]["name"], c["function"]["arguments"]
                self.set_state("tool")
                self.emit("tool", name=name, args=args)
                result = tools.call(name, args)
                self.emit("tool_result", name=name, result=result[:300])
                results.append(result)
                messages.append({"role": "tool", "name": name, "content": result[:1500]})
            self.set_state("thinking")
            self._tm["route"] = "llm+tools"
        else:
            final_text = self._deliver("I seem to be going in circles, sir.", reply_lang)

        if not self._cancel.is_set():
            final_text = self._finish_reply(final_text, results, reply_lang)
        self.history += [{"role": "user", "content": text}, {"role": "assistant", "content": final_text}]
        self.history = self.history[-8:]

    def _finish_reply(self, final_text: str, results: list, lang: str) -> str:
        """Last honesty check, then close the reply."""
        final_text = final_text.strip()
        if self._delivered:
            return final_text
        if results and all(is_error(r) for r in results) and (not final_text or claims_success(final_text)):
            # every tool failed but the model sounds happy: say what really happened
            correction = router.speakable(results[-1])
            if correction != final_text:
                self.stop_speech_only()
                final_text = self._deliver(correction, lang)
                return final_text
        if not final_text:
            final_text = router.speakable(results[-1]) if results and not is_error(results[-1]) else (
                "Done." if lang == "en" else "முடிந்தது.")
            for s in pop_sentences(final_text, final=True)[0]:
                self._speak(s)
            self.emit("token", text=final_text)
        self._tm["reply"] = time.time() - self._tm["t0"]
        self.emit("reply_end", text=final_text)
        return final_text

    def stop_speech_only(self) -> None:
        if self.speaker:
            self.speaker.stop()

    def _release(self, text: str, lang: str) -> str:
        """Say text that was held back by the guard."""
        return self._deliver(text, lang) if text.strip() else ""

    def _recall(self, text: str) -> list[str]:
        if len(text.split()) < 4:
            return []
        try:
            return self._pool.submit(memory.recall, text).result(timeout=1.0)
        except Exception:
            return []

    def _stream_round(self, messages: list, schemas: list, hold: bool) -> tuple[str, list]:
        """One model call. Streams text to the HUD/voice unless `hold`. Returns (text, tool_calls)."""
        kw = dict(model=config.LLM_MODEL, messages=messages, tools=schemas, stream=True,
                  options=config.LLM_OPTIONS, keep_alive=config.KEEP_ALIVE)
        try:
            stream = self.client.chat(think=False, **kw)
        except TypeError:                      # older ollama client without `think`
            stream = self.client.chat(**kw)
        buf, round_text, calls = "", "", []
        for chunk in stream:
            if self._cancel.is_set():
                break
            msg = _g(chunk, "message")
            piece = _g(msg, "content") or ""
            if piece:
                round_text += piece
                if not hold and "<tool_call>" not in round_text:
                    buf += piece
                    self.emit("token", text=piece)
                    sentences, buf = pop_sentences(buf, early=not self._spoke)
                    for s in sentences:
                        self._speak(s)
            for tc in _g(msg, "tool_calls") or []:
                fn = _g(tc, "function")
                args = _g(fn, "arguments") or {}
                if isinstance(args, str):
                    args = json.loads(args or "{}")
                calls.append({"function": {"name": _g(fn, "name"), "arguments": dict(args)}})
        if self._cancel.is_set():
            return round_text, calls
        if not calls and "<tool_call>" in round_text:
            round_text, calls = extract_text_calls(round_text)
        if not hold and not calls and buf.strip():
            for s in pop_sentences(buf, final=True)[0]:
                self._speak(s)
        return round_text.strip(), calls
