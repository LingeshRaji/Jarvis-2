# J.A.R.V.I.S. v4: local Tamil + English voice assistant with a 3D holographic core

A desktop app, not a terminal program. Speak to it in Tamil or English, it answers out loud in the same language, and almost everything runs on your machine.

```
mic -> Whisper small (CPU) -> instant router ---------------------------> tools -> speech out
                        |        (open apps, volume, time, mail,                    |-- English: Piper or Edge (you choose)
                        |         calendar, jobs: no model needed)                  '-- Tamil: MMS (offline) or Edge (you choose)
                        '------> qwen3:4b via Ollama (GPU) -> tools   (everything else)
        HUD window <-- WebSocket <-- assistant core        screen vision: qwen2.5vl:3b
```

## What changed in v4

1. **"Open Firefox" really opens Firefox, and Jarvis never claims what did not happen.** Apps are found from your installed app menu entries (Flatpak and Snap included), started with a clean environment, and Jarvis only says "Opened" after the app is really running. If it fails you hear the reason ("I couldn't open firefox: it exited with code 3"). If the language model says "done" without calling a tool, Jarvis catches it, retries once, and otherwise tells you nothing was done.
2. **Much faster.** Everyday commands skip the language model entirely. The model is smaller (qwen3:4b fits in 6 GB of VRAM), the prompt sends only the tools a request needs, speech recognition uses the small model first, voices are loaded at start-up, and Jarvis starts speaking after the first clause. The HUD shows how long each reply took.
3. **Mail, calendar and a daily briefing.**
4. **Job application helper.**
5. **You choose the English and Tamil voices.**

## Install (Linux, about 8 GB of downloads)

```bash
unzip jarvis_v4.zip && cd jarvis
./setup.sh
```

### Updating an existing install (keeps your environment and settings)

```bash
unzip -o jarvis_v4.zip -d ~          # extract over the old jarvis folder (adjust the path if it lives elsewhere)
cd ~/jarvis && ./update.sh
```

Then run `.venv/bin/python jarvis.py --doctor`. It checks the display, Ollama, models, microphone and voices, and **times each stage on your machine**, so you can see where any remaining delay is.

## Run

- Open **J.A.R.V.I.S.** from your application menu, or `.venv/bin/python jarvis.py`
- Preview the interface with no models or microphone: `python jarvis.py --demo` (demo mode gives canned answers)
- Typing only, no audio: `python jarvis.py --no-voice`
- Terminal mode: `python jarvis.py --cli`

## Talking to it

| Do this | To get this |
|---|---|
| Say "Hey Jarvis" | starts listening (English wake word) |
| Press **Space** or click the microphone | starts listening, any language, also interrupts Jarvis |
| Press **Esc** or the stop button | stops speaking or thinking |
| Auto / English / தமிழ் switch | Auto detects Tamil vs English per sentence |

Risky actions (shell commands, closing apps, locking the screen, sending mail, setting a scan scope) open an **Authorise / Deny** dialog. You can also say "yes" / "ஆம்" or "no" / "வேண்டாம்".

## Choosing voices

Click **Choose voice…** in the left panel (or run `python jarvis.py --voices`). Pick one English and one Tamil voice, press **Preview** to hear it, and the choice is saved in `~/.jarvis/settings.json`.

| | Offline (no internet) | Online (more natural, needs internet for each sentence) |
|---|---|---|
| English | 10 Piper voices: Alan (default, British male), Northern English male, Ryan, Lessac, Joe, HFC (American male), Cori, Jenny, Alba, Amy | Edge neural: Ryan, Thomas, Sonia (British); Andrew, Guy, Aria (American); Prabhat, Neerja (Indian English) |
| Tamil | MMS Tamil (one voice, a little robotic; there is no Tamil Piper voice) | Edge neural: Valluvar, Pallavi (Tamil Nadu); Kumar, Saranya (Sri Lanka); Anbu, Venba (Singapore); Surya, Kani (Malaysia) |

Offline Piper voices download once (about 60 MB) when you pick them. If an online voice cannot connect, Jarvis falls back to the offline voice for that language instead of going silent. The voice names were checked against the Piper voice list; I could not play any of them from my side, so use Preview.

## Mail, calendar and the daily briefing

One-time setup: `python jarvis.py --setup-accounts`

- **Mail (Gmail or any IMAP account):** use an *app password* (Google Account > Security > 2-Step Verification > App passwords), not your normal password. Reading never marks messages as read.
- **Calendar:** paste the private `.ics` link (Google Calendar > Settings > your calendar > "Secret address in iCal format") or a path to an `.ics` file. Repeating events are handled. Offline, the last downloaded copy is used.
- Your password and calendar link are typed in the terminal and stored in `~/.jarvis/accounts.json` (permissions 600). They are never spoken or sent to the language model. Anyone who can read that file can read your mail, so keep it private and revoke the app password if the computer is lost.

Things to say: "Check my mail", "Any mail from the recruiter?", "Read the latest email", "What's on my calendar today / tomorrow / on Friday?", "What's my next meeting?", "Give me my briefing". Sending mail always asks you to confirm first.

The **daily briefing** (date, weather if `WEATHER_CITY` is set, today's events, unread mail, job follow-ups due) is spoken the first time Jarvis starts each day. Switch it off with `BRIEFING_ON_START = False`.

## Job applications

One-time setup: `python jarvis.py --setup-jobs` (your details and resume path, stored in `~/.jarvis/profile.json`).

- "Find SOC analyst jobs in Chennai" lists numbered results (needs internet). "Open job boards for SOC analyst" opens the boards in your browser.
- "Track job two" saves one. "I applied to Acme" or "Mark Acme as interview" updates the tracker. "Show my applications" and "Any follow-ups due?" read it back (a follow-up is due 7 days after applying).
- "Prepare an application to Acme for SOC Analyst" writes a cover letter from **only the facts in your profile**, saves it in `~/jarvis_applications/`, copies it to the clipboard and opens the apply page.
- If a posting gives a recruiter's email address, "email my application to hr@acme.com for Acme, SOC Analyst" sends the cover letter and resume after you confirm.

**Jarvis does not press Submit on job sites for you.** Auto-filling and submitting forms on LinkedIn, Naukri and similar sites breaks their rules (accounts get banned), fails on captchas and changing forms, and a small local model can put a wrong answer in a real application. So you check the letter and submit; Jarvis does the searching, writing, tracking and reminding. Read every letter before sending.

## The 3D core

A real 3D scene (Three.js, bundled locally): a glowing core, wireframe shells, rings, particles and a ring of bars that follows your voice and Jarvis's. Move the mouse to tilt it, drag to spin it. Colour shows state: cyan idle, green listening, amber thinking, pale white speaking. `HUD_QUALITY` in `config.py`: `"high"`, `"medium"` (no glow) or `"low"` (flat 2D).

## What else it can do

- **Computer:** open and close apps, files and sites, volume (up, down, set, mute), brightness, media keys, screenshots, lock screen, shell commands, find files, timers and reminders, notes.
- **Information:** web search and weather (online), calculator, notes search, long-term memory.
- **Screen vision:** "What's on my screen?", "Explain this error."
- **Pentest helper** (authorised targets only): start an engagement with a confirmed scope, run nmap/nikto/whatweb/gobuster in the background, record findings, generate a Markdown/HTML report in `~/jarvis_reports/`.

## Speed: what to expect and how to tune

I could not measure real timings from my side (no GPU, Ollama or microphone there). Run `python jarvis.py --doctor` and the HUD readout (under the status line) to see your numbers. Expected: routed commands answer in well under a second; model answers start speaking after the first sentence or clause.

| Problem | Change in `config.py` |
|---|---|
| Still slow on chat | keep `qwen3:4b`; make sure `ollama ps` shows it fully on GPU. Close other GPU programs |
| Tamil answers poor | `LLM_MODEL = "qwen3:8b"` (better Tamil, slower) |
| Slow to start listening to Tamil | `PREWARM_TAMIL_STT = True` (default) keeps the Tamil recogniser loaded (about 1.5 GB RAM) |
| English misheard | `WHISPER_MODEL_EN = "medium"` |
| Cuts you off mid-sentence | raise `SILENCE_SECONDS` (default 0.8) |
| Online voice lags | choose an offline voice |
| More authorised lab ranges | `AUTHORISED_TARGETS` |

## Troubleshooting

- **An app will not open:** Jarvis now says why. Run `--doctor`. "can't see a graphical display" means Jarvis was started from a session without `DISPLAY`/`WAYLAND_DISPLAY` (for example over plain SSH).
- **HUD shows "Reconnecting":** the backend stopped. Start it from a terminal to see the error.
- **"Cannot reach Ollama":** run `ollama serve`.
- **Mail login fails:** use an app password, and check IMAP is enabled in Gmail settings.
- **Tamil letters show as boxes:** install a Tamil font (`noto-fonts` / `fonts-noto-core`).
- **Screen vision fails:** install `grim` (Wayland) or `scrot` (X11) and `ollama pull qwen2.5vl:3b`.

## Safety and privacy

- The HUD listens on `127.0.0.1` only. Nothing leaves your machine except what you turn on: web search, weather, job search, Edge voices, and your own mail/calendar connections.
- Scans are refused outside `AUTHORISED_TARGETS` plus the scope you confirm. Only test systems you own or have written permission to test.
- Dangerous shell patterns never run; anything outside a small safe list needs your confirmation. Email in your inbox is untrusted text: Jarvis reads it aloud but you should not let instructions inside an email drive actions.

## Files

`jarvis.py` launcher (`--doctor`, `--voices`, `--setup-accounts`, `--setup-jobs`), `assistant.py` brain, `router.py` instant commands, `apps.py` reliable app launching, `results.py` error convention, `voice.py` + `voices.py` speech and voice catalogue, `tools.py` abilities, `mailcal.py` mail and calendar, `briefing.py` daily briefing, `jobs.py` job helper, `pentest.py`, `vision.py`, `server.py` + `ui/` the HUD, `doctor.py`, `demo.py`, `tests/` offline tests (`test_core.py`, `test_v4.py`), `setup.sh`, `update.sh`.
