"""Job-hunting helper: search, a tracker, tailored cover letters, and getting the application ready.

What it does for you:  finds listings, opens the job boards, keeps a tracker with follow-up dates, writes a cover
letter from YOUR profile (it is told not to invent anything), puts it on the clipboard, opens the apply page, and can
email an application with your resume attached (after you confirm).
What it deliberately does not do: fill in and submit web forms on its own. Application forms differ on every site, sit
behind logins and CAPTCHAs, and LinkedIn forbids automation, so a mistaken auto-submit could cost you an opportunity
or your account. You press the final button.
"""
import json
import re
import shutil
import sqlite3
import subprocess
import time
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta
from pathlib import Path

import apps
import config
from results import fail

STATUSES = ["saved", "preparing", "applied", "interview", "offer", "rejected", "withdrawn"]
FOLLOW_UP_DAYS = 7
LAST_RESULTS: list[dict] = []          # the last search, so "track number 2" works
SETUP_HINT = "Run 'python jarvis.py --setup-jobs' once to add your details."


# ------------------------------------------------------------------------------------------ storage
def _db():
    con = sqlite3.connect(config.JOBS_DB)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY, created REAL, company TEXT, role TEXT, url TEXT, status TEXT,
        notes TEXT, applied_on TEXT, follow_up TEXT, letter_path TEXT)""")
    return con


def load_profile() -> dict:
    try:
        return json.loads(config.PROFILE_FILE.read_text())
    except (OSError, ValueError):
        return {}


def save_profile(p: dict) -> None:
    config.PROFILE_FILE.write_text(json.dumps(p, indent=2, ensure_ascii=False))


def profile_ready() -> bool:
    p = load_profile()
    return bool(p.get("name") and p.get("summary"))


# ------------------------------------------------------------------------------------------ search
BOARDS = {
    "LinkedIn": "https://www.linkedin.com/jobs/search/?keywords={q}&location={l}",
    "Indeed": "https://in.indeed.com/jobs?q={q}&l={l}",
    "Naukri": "https://www.naukri.com/{qs}-jobs{ls}",
    "Google Jobs": "https://www.google.com/search?q={q}+jobs+{l}&ibp=htl;jobs",
}


def open_boards(query: str, location: str = "") -> str:
    q, l = urllib.parse.quote_plus(query), urllib.parse.quote_plus(location)
    slug = lambda s: re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")
    opened = []
    for name, tpl in BOARDS.items():
        url = tpl.format(q=q, l=l, qs=slug(query), ls=(f"-in-{slug(location)}" if location else ""))
        if not apps.open_url(url).startswith("ERROR"):
            opened.append(name)
            time.sleep(0.4)
    if not opened:
        return fail("I couldn't open the browser for the job boards.")
    return f"Opened {', '.join(opened)} for {query}{' in ' + location if location else ''}."


def search(query: str, location: str = "", limit: int = 6) -> str:
    """Quick web search for listings; results are numbered so you can say 'track number two'."""
    try:
        from ddgs import DDGS
        q = f"{query} jobs {location}".strip()
        res = DDGS().text(q + " apply", region="in-en", max_results=limit + 4)
    except Exception as e:
        return fail(f"Job search needs internet ({str(e)[:80]}).")
    LAST_RESULTS.clear()
    for r in res:
        url = r.get("href") or r.get("url") or ""
        if url and len(LAST_RESULTS) < limit:
            LAST_RESULTS.append({"title": r.get("title", "")[:90], "url": url, "snippet": (r.get("body") or "")[:160]})
    if not LAST_RESULTS:
        return f"No listings found for {query}."
    return "\n".join(f"{i}. {r['title']} ({urllib.parse.urlparse(r['url']).netloc.replace('www.', '')})"
                     for i, r in enumerate(LAST_RESULTS, 1))


# ------------------------------------------------------------------------------------------ tracker
def _find(con, ref: str):
    ref = str(ref).strip()
    if ref.isdigit():
        row = con.execute("SELECT * FROM applications WHERE id=?", (int(ref),)).fetchone()
        if row:
            return row
    return con.execute("SELECT * FROM applications WHERE lower(company) LIKE ? OR lower(role) LIKE ? "
                       "ORDER BY created DESC LIMIT 1", (f"%{ref.lower()}%",) * 2).fetchone()


def track(company: str = "", role: str = "", url: str = "", status: str = "saved", notes: str = "",
          from_result: int = 0) -> str:
    """Add an application to the tracker. from_result=N takes details from the Nth result of the last search."""
    if from_result:
        if not 1 <= from_result <= len(LAST_RESULTS):
            return fail("I don't have that search result any more. Search again first.")
        r = LAST_RESULTS[from_result - 1]
        url = url or r["url"]
        role = role or r["title"]
        company = company or urllib.parse.urlparse(r["url"]).netloc.replace("www.", "").split(".")[0].title()
    if not company or not role:
        return fail("I need both a company and a role to track an application.")
    status = status.lower() if status.lower() in STATUSES else "saved"
    follow = (date.today() + timedelta(days=FOLLOW_UP_DAYS)).isoformat() if status == "applied" else ""
    con = _db()
    dup = con.execute("SELECT id FROM applications WHERE lower(company)=? AND lower(role)=?",
                      (company.lower(), role.lower())).fetchone()
    if dup:
        return fail(f"{role} at {company} is already tracked as number {dup['id']}.")
    cur = con.execute("INSERT INTO applications (created, company, role, url, status, notes, applied_on, follow_up) "
                      "VALUES (?,?,?,?,?,?,?,?)",
                      (time.time(), company, role, url, status, notes,
                       date.today().isoformat() if status == "applied" else "", follow))
    con.commit()
    return f"Tracking {role} at {company} as number {cur.lastrowid}, status {status}."


def update(ref: str, status: str = "", notes: str = "") -> str:
    con = _db()
    row = _find(con, ref)
    if not row:
        return fail(f"I can't find an application matching '{ref}'.")
    sets, vals = [], []
    if status:
        status = status.lower()
        if status not in STATUSES:
            return fail(f"Status must be one of {', '.join(STATUSES)}.")
        sets.append("status=?")
        vals.append(status)
        if status == "applied":
            sets += ["applied_on=?", "follow_up=?"]
            vals += [date.today().isoformat(), (date.today() + timedelta(days=FOLLOW_UP_DAYS)).isoformat()]
        elif status in ("rejected", "withdrawn", "offer"):
            sets.append("follow_up=?")
            vals.append("")
    if notes:
        sets.append("notes=?")
        vals.append((row["notes"] + "; " if row["notes"] else "") + notes)
    if not sets:
        return fail("Nothing to update.")
    con.execute(f"UPDATE applications SET {', '.join(sets)} WHERE id=?", (*vals, row["id"]))
    con.commit()
    return f"Updated {row['role']} at {row['company']}" + (f": now {status}." if status else ".")


def list_applications(status: str = "") -> str:
    con = _db()
    rows = con.execute("SELECT * FROM applications" + (" WHERE status=?" if status else "") + " ORDER BY created DESC",
                       (status.lower(),) if status else ()).fetchall()
    if not rows:
        return "No applications tracked yet." if not status else f"No applications with status {status}."
    counts: dict = {}
    for r in rows:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    head = f"{len(rows)} application{'s' if len(rows) != 1 else ''}: " + ", ".join(f"{n} {s}" for s, n in counts.items()) + "."
    items = " ".join(f"{r['id']}: {r['role']} at {r['company']}, {r['status']}." for r in rows[:6])
    return f"{head} {items}" + (f" And {len(rows) - 6} more." if len(rows) > 6 else "")


def due_followups() -> list[sqlite3.Row]:
    con = _db()
    return con.execute("SELECT * FROM applications WHERE status='applied' AND follow_up != '' AND follow_up <= ? "
                       "ORDER BY follow_up", (date.today().isoformat(),)).fetchall()


def followups_summary() -> str:
    rows = due_followups()
    if not rows:
        return "No follow-ups due, sir."
    return f"{len(rows)} follow-up{'s' if len(rows) != 1 else ''} due: " + ", ".join(
        f"{r['role']} at {r['company']}" for r in rows[:5]) + "."


# ------------------------------------------------------------------------------------------ letters
def _page_text(url: str, limit: int = 5000) -> str:
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=8) as r:
            html = r.read(400_000).decode("utf-8", "ignore")
    except Exception:
        return ""
    html = re.sub(r"(?is)<(script|style|nav|footer|header).*?</\1>", " ", html)
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)).strip()[:limit]


def _copy(text: str) -> bool:
    env = apps.clean_env()
    for cmd in (["wl-copy"], ["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"]):
        if shutil.which(cmd[0]):
            try:
                if subprocess.run(cmd, input=text.encode(), env=env, timeout=5, capture_output=True).returncode == 0:
                    return True
            except (OSError, subprocess.TimeoutExpired):
                continue
    return False


def _latest_letter(company: str, role: str):
    files = list(config.APPLICATIONS_DIR.glob(f"*{_slug(company)}-{_slug(role)}.txt"))
    return max(files, key=lambda f: f.stat().st_mtime) if files else None


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:40] or "x"


def cover_letter(company: str, role: str, job_description: str = "", url: str = "") -> str:
    """Write a cover letter from the saved profile. Returns the text; also saved under ~/jarvis_applications."""
    if not profile_ready():
        return fail("I don't have your details yet. " + SETUP_HINT)
    p = load_profile()
    jd = job_description.strip() or (_page_text(url) if url else "")
    facts = json.dumps({k: v for k, v in p.items() if k not in ("resume_path",) and v}, ensure_ascii=False)
    prompt = (f"Write a cover letter for the role '{role}' at '{company}'.\n"
              f"APPLICANT FACTS (the only things you may state about the applicant):\n{facts}\n\n"
              + (f"JOB DESCRIPTION:\n{jd}\n\n" if jd else "No job description is available; keep it general to the role.\n\n")
              + "Rules: 180 to 230 words. Plain text, no markdown, no placeholders like [Name]. Use ONLY the applicant "
                "facts above; never invent employers, degrees, years of experience, certifications or skills. If the job "
                "asks for something not in the facts, do not claim it. Open with the role and company, give two or three "
                f"concrete strengths from the facts that match the job, close politely. Sign off with {p.get('name')}.")
    try:
        import ollama
        r = ollama.Client(host=config.OLLAMA_HOST).chat(
            model=config.LLM_MODEL, messages=[{"role": "user", "content": prompt}], think=False,
            options={"temperature": 0.5, "num_ctx": 4096, "num_predict": 450}, keep_alive=config.KEEP_ALIVE)
        letter = (r["message"]["content"] if isinstance(r, dict) else r.message.content).strip()
    except Exception as e:
        return fail(f"I couldn't write the letter ({str(e)[:100]}). Is Ollama running?")
    if len(letter.split()) < 60:
        return fail("The model gave a letter that was too short. Try again.")
    f = config.APPLICATIONS_DIR / f"{date.today():%Y-%m-%d}-{_slug(company)}-{_slug(role)}.txt"
    f.write_text(letter)
    return letter


def prepare(company: str, role: str, url: str = "", job_description: str = "") -> str:
    """The 'apply' flow: track it, write the letter, copy it, and open the apply page. You submit."""
    con = _db()
    existing = con.execute("SELECT id FROM applications WHERE lower(company)=? AND lower(role)=?",
                           (company.lower(), role.lower())).fetchone()
    if not existing:
        track(company, role, url, "preparing")
    letter = cover_letter(company, role, job_description, url)
    if letter.startswith("ERROR"):
        return letter
    row = _find(_db(), company)
    path = _latest_letter(company, role)
    if row and path:
        c = _db()
        c.execute("UPDATE applications SET letter_path=? WHERE id=?", (str(path), row["id"]))
        c.commit()
    copied = _copy(letter)
    opened = apps.open_url(url) if url else ""
    resume = load_profile().get("resume_path", "")
    out = [f"Cover letter for {role} at {company} is ready and saved in the applications folder"]
    out.append("and copied to the clipboard" if copied else "(I couldn't reach the clipboard, so open the saved file)")
    if url:
        out.append("and the application page is open" if not opened.startswith("ERROR") else "but I couldn't open the page")
    msg = ", ".join(out) + "."
    if resume:
        msg += " Attach your resume and press submit when you're happy, sir. Tell me when you've applied and I'll set a follow-up."
    else:
        msg += " Add your resume path in the profile to attach it. Tell me when you've applied and I'll set a follow-up."
    return msg


def email_application(to: str, company: str, role: str, confirm=None) -> str:
    """Email the saved cover letter and your resume to a recruiter (asks you to confirm before sending)."""
    import mailcal
    p = load_profile()
    path = _latest_letter(company, role)
    if not path:
        return fail("Write the cover letter first (prepare the application).")
    resume = p.get("resume_path", "")
    r = mailcal.send(to, f"Application for {role} - {p.get('name', '')}".strip(" -"), path.read_text(),
                     [resume] if resume else None, confirm)
    if not r.startswith("ERROR"):
        update(company, "applied")
    return r


# ------------------------------------------------------------------------------------------ setup wizard
def setup_profile() -> None:
    print("\n== Your details for cover letters (kept only on this computer) ==")
    print("Jarvis may only state what you write here, so be accurate. Press Enter to keep a saved value.\n")
    p = load_profile()
    def ask(key, prompt, hint=""):
        cur = p.get(key, "")
        shown = ", ".join(cur) if isinstance(cur, list) else cur
        v = input(f"{prompt}{hint} [{shown}]: ").strip()
        if v:
            p[key] = [x.strip() for x in v.split(",") if x.strip()] if isinstance(cur, list) else v
    p.setdefault("skills", [])
    p.setdefault("target_roles", [])
    p.setdefault("certifications", [])
    ask("name", "Full name")
    ask("email", "Email")
    ask("phone", "Phone")
    ask("location", "City")
    ask("education", "Education (e.g. B.E. CSE (AI & ML), college, year)")
    ask("certifications", "Certifications", " (comma separated)")
    ask("skills", "Key skills", " (comma separated)")
    ask("target_roles", "Roles you want", " (comma separated)")
    ask("summary", "Two or three sentences about you and what you are looking for")
    ask("projects", "Projects or lab work worth mentioning (one line)")
    ask("links", "Links (GitHub, LinkedIn, portfolio)")
    ask("resume_path", "Path to your resume PDF")
    save_profile(p)
    print(f"\nSaved to {config.PROFILE_FILE}. Edit that file any time.")
