"""Launch desktop apps and websites reliably, and report truthfully whether it worked.

Finds an app by (in order): known aliases, a program on PATH, then installed .desktop entries (this covers
Flatpak and Snap apps) with fuzzy matching, so "fire fox", "Firefox." and "பயர்பாக்ஸ்" all work.
The app is started with a clean environment (no leaked venv variables, desktop session variables filled in).
Jarvis only says "Opened" after checking that the process really started or is really running; failures use the
"ERROR: " convention from results.py.
"""
import difflib
import glob
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import psutil

from results import fail

# Spoken/transcribed names -> program names to try, best first.
_BROWSERS = ["firefox", "firefox-esr", "chromium", "chromium-browser", "google-chrome", "google-chrome-stable",
             "brave-browser", "brave"]
_TERMINALS = ["x-terminal-emulator", "kitty", "alacritty", "gnome-terminal", "konsole", "xfce4-terminal", "foot",
              "terminator", "tilix", "xterm"]
_FILES = ["nautilus", "dolphin", "thunar", "nemo", "pcmanfm", "caja"]
_EDITORS = ["gnome-text-editor", "gedit", "kate", "mousepad", "xed", "pluma"]
ALIASES = {
    "browser": _BROWSERS, "webbrowser": _BROWSERS, "internet": _BROWSERS,
    "firefox": ["firefox", "firefox-esr", "firefox-developer-edition"],
    "chromium": ["chromium", "chromium-browser"],
    "brave": ["brave-browser", "brave"],
    "chrome": ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser"],
    "googlechrome": ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser"],
    "terminal": _TERMINALS, "console": _TERMINALS,
    "filemanager": _FILES, "files": _FILES,
    "texteditor": _EDITORS, "editor": _EDITORS + ["code"], "notepad": _EDITORS,
    "calculator": ["gnome-calculator", "kcalc", "galculator", "qalculate-gtk", "mate-calc"],
    "settings": ["gnome-control-center", "systemsettings", "xfce4-settings-manager", "cinnamon-settings"],
    "code": ["code", "code-oss", "codium", "vscodium"],
    "vscode": ["code", "code-oss", "codium", "vscodium"],
    "visualstudiocode": ["code", "code-oss", "codium", "vscodium"],
    "burp": ["burpsuite"], "burpsuite": ["burpsuite"],
    "wireshark": ["wireshark"], "spotify": ["spotify"], "vlc": ["vlc"],
    "telegram": ["telegram-desktop", "Telegram"], "discord": ["discord", "Discord"],
    "zap": ["zaproxy", "owasp-zap"], "ghidra": ["ghidra", "ghidraRun"],
    "taskmanager": ["gnome-system-monitor", "plasma-systemmonitor", "xfce4-taskmanager"],
    "systemmonitor": ["gnome-system-monitor", "plasma-systemmonitor", "xfce4-taskmanager"],
}

# Tamil spellings (Whisper writes loan words in Tamil script)
TAMIL_NAMES = {
    "பயர்பாக்ஸ்": "firefox", "ஃபயர்பாக்ஸ்": "firefox", "பயர்ஃபாக்ஸ்": "firefox", "பையர்பாக்ஸ்": "firefox",
    "குரோம்": "chrome", "கூகுள் குரோம்": "chrome", "டெர்மினல்": "terminal", "கால்குலேட்டர்": "calculator",
    "கேல்குலேட்டர்": "calculator", "செட்டிங்ஸ்": "settings", "பிரவுசர்": "browser", "ப்ரவுசர்": "browser",
    "ஸ்பாட்டிஃபை": "spotify", "வீஎஸ் கோட்": "vscode", "வைர்ஷார்க்": "wireshark", "ஃபைல்ஸ்": "files",
    "வீஎல்சி": "vlc", "டெலிகிராம்": "telegram", "டிஸ்கார்ட்": "discord",
}

_NO_PROCESS = {"python", "python3", "ollama", "systemd", "bash", "sh", "zsh", "fish", "sshd", "dbus-daemon"}
# Words that only wrap the real program in a launch command; they say nothing about what should be running.
_WRAPPERS = {"gtk-launch", "gio", "env", "flatpak", "snap", "run", "launch", "sh", "bash", "xdg-open", "setsid",
             "nohup", "sudo", "open"}


_INTERPRETERS = {"python", "python3", "sh", "bash", "dash", "zsh", "perl", "node", "ruby", "java"}


def norm(s: str) -> str:
    return re.sub(r"[^0-9a-z஀-௿]", "", s.lower())


# ----------------------------------------------------------------------------------- environment
def clean_env() -> dict:
    """Environment for child apps: no Jarvis virtualenv, and the desktop-session variables filled in."""
    env = dict(os.environ)
    roots = set()
    if sys.prefix != getattr(sys, "base_prefix", sys.prefix):
        roots.add(sys.prefix)
    if env.get("VIRTUAL_ENV"):
        roots.add(env["VIRTUAL_ENV"])
    for k in ("VIRTUAL_ENV", "PYTHONHOME", "PYTHONPATH", "PYTHONSTARTUP", "PYTHONEXECUTABLE", "__PYVENV_LAUNCHER__"):
        env.pop(k, None)

    def inside(p: str) -> bool:
        return any(p == r or p.startswith(r + os.sep) for r in roots)

    path = [p for p in env.get("PATH", "").split(os.pathsep) if p and not inside(p)]
    if env.get("LD_LIBRARY_PATH"):
        ld = [p for p in env["LD_LIBRARY_PATH"].split(":") if p and not inside(p) and "site-packages" not in p]
        env["LD_LIBRARY_PATH"] = ":".join(ld) if ld else ""
        if not ld:
            env.pop("LD_LIBRARY_PATH")
    home = Path.home()
    for extra in ("/usr/local/bin", "/usr/bin", "/bin", "/snap/bin", "/var/lib/flatpak/exports/bin",
                  str(home / ".local/share/flatpak/exports/bin"), str(home / ".local/bin")):
        if extra not in path:
            path.append(extra)                       # snap / flatpak launchers live here
    env["PATH"] = os.pathsep.join(path)

    rt = env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    if "DBUS_SESSION_BUS_ADDRESS" not in env and os.path.exists(f"{rt}/bus"):
        env["DBUS_SESSION_BUS_ADDRESS"] = f"unix:path={rt}/bus"
    if not env.get("DISPLAY") and not env.get("WAYLAND_DISPLAY"):
        socks = [s for s in sorted(glob.glob(f"{rt}/wayland-[0-9]*")) if not s.endswith(".lock")]
        x11 = sorted(glob.glob("/tmp/.X11-unix/X*"))
        if socks:
            env["WAYLAND_DISPLAY"] = os.path.basename(socks[0])
        elif x11:
            env["DISPLAY"] = ":" + os.path.basename(x11[0])[1:]
    if "XAUTHORITY" not in env and (home / ".Xauthority").exists():
        env["XAUTHORITY"] = str(home / ".Xauthority")
    return env


def has_display() -> bool:
    e = clean_env()
    return bool(e.get("DISPLAY") or e.get("WAYLAND_DISPLAY"))


def _which(name: str) -> str | None:
    return shutil.which(name, path=clean_env()["PATH"])


# ----------------------------------------------------------------------------------- .desktop index
def _app_dirs() -> list[Path]:
    home = Path.home()
    dirs = [Path(os.environ.get("XDG_DATA_HOME") or home / ".local/share") / "applications"]
    for d in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":"):
        if d:
            dirs.append(Path(d) / "applications")
    dirs += [Path("/var/lib/flatpak/exports/share/applications"),
             home / ".local/share/flatpak/exports/share/applications",
             Path("/var/lib/snapd/desktop/applications")]
    seen, out = set(), []
    for d in dirs:
        if d not in seen:
            seen.add(d)
            out.append(d)
    return out


def _parse_desktop(path: Path) -> dict | None:
    try:
        text = path.read_text(errors="ignore")
    except OSError:
        return None
    data, inside = {}, False
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("["):
            inside = line == "[Desktop Entry]"
            continue
        if inside and "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            k = k.strip()
            if k in ("Name", "GenericName", "Exec", "Keywords", "Type", "NoDisplay", "Hidden", "Terminal") and k not in data:
                data[k] = v.strip()
    if (data.get("Type", "Application") != "Application" or data.get("NoDisplay", "").lower() == "true"
            or data.get("Hidden", "").lower() == "true" or data.get("Terminal", "").lower() == "true"
            or "Exec" not in data):
        return None
    return data


_index: list[dict] | None = None
_index_t = 0.0


def desktop_index(force: bool = False) -> list[dict]:
    global _index, _index_t
    if _index is not None and not force and time.time() - _index_t < 300:
        return _index
    entries = []
    for d in _app_dirs():
        if not d.is_dir():
            continue
        for f in d.glob("*.desktop"):
            data = _parse_desktop(f)
            if not data:
                continue
            try:
                exe = shlex.split(re.sub(r"%[a-zA-Z]", "", data["Exec"]) or "true")[:1]
            except ValueError:
                exe = []
            names = {norm(data.get("Name", "")), norm(f.stem.split(".")[-1]), norm(f.stem),
                     norm(Path(exe[0]).name) if exe else "", norm(data.get("GenericName", ""))}
            names |= {norm(k) for k in data.get("Keywords", "").split(";") if k}
            entries.append({"id": f.stem, "path": f, "label": data.get("Name", f.stem), "exec": data["Exec"],
                            "names": {n for n in names if n}})
    _index, _index_t = entries, time.time()
    return entries


def _desktop_cmd(e: dict) -> list[str]:
    if _which("gtk-launch"):
        return ["gtk-launch", e["id"]]
    if _which("gio"):
        return ["gio", "launch", str(e["path"])]
    try:
        return shlex.split(re.sub(r"\s*%[a-zA-Z]", "", e["exec"]))
    except ValueError:
        return []


def _strip_tamil_suffix(s: str) -> str:
    return re.sub(r"(ஐ|ை|யை|ஆ)$", "", s.strip())


def _best_desktop(qn: str) -> dict | None:
    best, best_score = None, 0.0
    for e in desktop_index():
        if qn in e["names"]:
            score = 1.0
        elif len(qn) >= 4 and any(n.startswith(qn) or (len(n) >= 4 and qn.startswith(n)) for n in e["names"]):
            score = 0.92
        elif len(qn) >= 4 and any(qn in n for n in e["names"]):
            score = 0.85
        else:
            score = max((difflib.SequenceMatcher(None, qn, n).ratio() for n in e["names"]), default=0.0)
            score = score if score >= 0.78 else 0.0
        if score > best_score:
            best, best_score = e, score
    return best


def _tokens(cmd: list[str], extra=()) -> set[str]:
    """Names a running process of this app would carry, used to check that the app really is running."""
    toks = set()
    for part in list(cmd)[:4] + list(extra):
        base = os.path.basename(str(part)).lower()
        if base.endswith(".desktop"):
            base = base[:-8]
        if not base or base.startswith("-") or "=" in base or base in _WRAPPERS:
            continue
        toks.add(base)
        if "." in base:
            toks.add(base.split(".")[-1])            # org.mozilla.firefox -> firefox
    return {t for t in toks if len(t) >= 3 and t not in _WRAPPERS}


def _candidates(query: str):
    """Ways to start `query`, best first: aliases, programs on PATH, then the best .desktop entry."""
    q = query.strip().strip(".,!?\"'")
    q = TAMIL_NAMES.get(q) or TAMIL_NAMES.get(_strip_tamil_suffix(q)) or q
    qn = norm(q)
    if not qn:
        return
    seen: set = set()

    def make(label, cmd, source, extra=()):
        if not cmd or tuple(cmd) in seen:
            return None
        seen.add(tuple(cmd))
        return {"label": label, "cmd": cmd, "source": source, "expect": _tokens(cmd, extra)}

    for prog in ALIASES.get(qn, []):
        exe = _which(prog)
        c = make(prog, [exe], "path", (prog,)) if exe else None
        if c:
            yield c
    for cand in (q.lower().replace(" ", "-"), q.lower().replace(" ", ""), q.lower()):
        exe = _which(cand)
        c = make(q.title(), [exe], "path", (cand,)) if exe else None
        if c:
            yield c
    best = _best_desktop(qn)
    if best:
        c = make(best["label"], _desktop_cmd(best), "desktop", (best["id"],))
        if c:
            yield c


def resolve(query: str) -> dict | None:
    """Return {'label', 'cmd', 'source', 'expect'} for the best way to start an app, or None."""
    return next(iter(_candidates(query)), None)


def is_gui_app(name: str) -> bool:
    """True for apps with a desktop entry or a known alias (so Jarvis opens them instead of running them in a shell)."""
    qn = norm(TAMIL_NAMES.get(name.strip()) or name)
    return bool(qn) and (qn in ALIASES or any(qn in e["names"] for e in desktop_index()))


def suggestions(query: str, n: int = 3) -> list[str]:
    qn = norm(query)
    labels = {e["label"]: max((difflib.SequenceMatcher(None, qn, x).ratio() for x in e["names"]), default=0)
              for e in desktop_index()}
    return [k for k, _ in sorted(labels.items(), key=lambda kv: -kv[1])[:n] if labels[k] > 0.45]


# ----------------------------------------------------------------------------------- launching
def process_running(tokens) -> bool:
    """Is a process (other than Jarvis and its own HUD window) running under one of these names?"""
    tokens = {t for t in tokens if t}
    if not tokens:
        return False
    me = {os.getpid(), os.getppid()}
    for p in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            if p.info["pid"] in me:
                continue
            cmd = p.info["cmdline"] or []
            blob = " ".join(cmd).lower()
            if "jarvis" in blob or "browser-profile" in blob:
                continue                              # Jarvis itself / its HUD window must not count
            name = (p.info["name"] or "").lower()
            argv0 = os.path.basename(cmd[0]).lower() if cmd else ""
            argv1 = os.path.basename(cmd[1]).lower() if len(cmd) > 1 and not cmd[1].startswith("-") else ""
            if argv0 in _INTERPRETERS or name in _INTERPRETERS:
                names = (argv1,)                      # a script run by an interpreter: judge by the script's name
            else:
                names = (name, argv0)
            for t in tokens:
                if any(n and (n == t or n.startswith(t)) for n in names):
                    return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    return False


def launch(cmd: list[str], wait: float = 1.6, expect=()) -> tuple[bool, str]:
    """Start a program detached and check that it really started. Returns (ok, reason_if_not).

    A program that is still running after `wait` seconds started fine. One that exits with an error failed (its last
    error line is returned). One that exits with code 0 is a launcher that handed over to another process, so we
    check that process (`expect`) is actually there instead of trusting the exit code.
    """
    log = tempfile.TemporaryFile()                    # anonymous file: the app can keep writing without filling a pipe
    try:
        p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                             start_new_session=True, env=clean_env())
    except OSError as e:
        return False, str(e)
    deadline = time.time() + wait
    while time.time() < deadline:
        rc = p.poll()
        if rc is not None:
            if rc != 0:
                log.seek(0)
                tail = log.read()[-400:].decode(errors="ignore").strip().splitlines()
                return False, (tail[-1][:160] if tail else f"it exited with code {rc}")
            if expect:
                end = time.time() + 2.5
                while time.time() < end:
                    if process_running(expect):
                        return True, ""
                    time.sleep(0.25)
                return False, "the launcher finished but I can't see the app running"
            return True, ""
        time.sleep(0.1)
    return True, ""                                   # still running after the wait: a GUI app that stays open


def open_app(name: str) -> str:
    name = name.strip()
    if not name:
        return fail("Which app should I open?")
    if not has_display():
        return fail(f"I can't open {name}: Jarvis can't see a graphical display (DISPLAY / WAYLAND_DISPLAY is not set).")
    first_error, tried = None, 0
    for app in _candidates(name):
        tried += 1
        ok, why = launch(app["cmd"], expect=app["expect"])
        if ok:
            return f"Opened {app['label']}."
        first_error = first_error or f"I couldn't open {app['label']}: {why}"
        if tried >= 3:
            break
    if first_error:
        return fail(first_error)
    s = suggestions(name)
    return fail(f"I couldn't find an app called {name}." + (f" Did you mean {', '.join(s)}?" if s else ""))


def open_url(url: str) -> str:
    url = url.strip()
    if not re.match(r"^[a-z][a-z0-9+.-]*://", url):
        url = "https://" + url
    if not has_display():
        return fail("I can't open the link: Jarvis can't see a graphical display.")
    attempts = []
    if _which("xdg-open"):
        attempts.append(["xdg-open", url])
    if _which("gio"):
        attempts.append(["gio", "open", url])
    for app in list(_candidates("browser"))[:2]:
        attempts.append(app["cmd"] + [url])
    if not attempts:
        return fail("I can't open the link: xdg-open is not installed and I found no browser.")
    why = ""
    for cmd in attempts:
        ok, why = launch(cmd)
        if ok:
            return f"Opened {url}."
    return fail(f"I couldn't open the link: {why}")


def open_path(path: str) -> str:
    p = os.path.expanduser(path)
    if not os.path.exists(p):
        return fail(f"That path does not exist: {p}")
    if not has_display():
        return fail("I can't open it: Jarvis can't see a graphical display.")
    if not _which("xdg-open"):
        return fail("I can't open it: xdg-open is not installed.")
    ok, why = launch(["xdg-open", p])
    return f"Opened {p}." if ok else fail(f"I couldn't open it: {why}")


def close_app(name: str, confirm) -> str:
    qn = norm(TAMIL_NAMES.get(name.strip()) or name)
    if not qn:
        return fail("Which app should I close?")
    me = os.getuid()
    targets = []
    for p in psutil.process_iter(["name", "cmdline", "pid", "uids"]):
        try:
            info = p.info
            if info.get("uids") and info["uids"].real != me:
                continue                              # only the user's own processes
            pname = norm(info["name"] or "")
            cmd = " ".join(info["cmdline"] or [])
            if "jarvis" in cmd.lower() or "browser-profile" in cmd or (info["name"] or "") in _NO_PROCESS:
                continue                              # never close Jarvis itself or its HUD window
            if pname == qn or (len(qn) >= 4 and (pname.startswith(qn) or qn in pname)):
                targets.append(p)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    if not targets:
        return fail(f"{name} doesn't seem to be running.")
    names = sorted({t.info["name"] for t in targets if t.info.get("name")})[:3]
    if not confirm(f"Close {name} ({', '.join(names)})? Unsaved work may be lost."):
        return fail("Cancelled.")
    for p in targets:
        try:
            p.terminate()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    _, alive = psutil.wait_procs(targets, timeout=3)
    if alive:
        return fail(f"{name} didn't close. It may be asking you to save your work.")
    return f"Closed {name}."
