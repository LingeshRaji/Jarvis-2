#!/usr/bin/env bash
# Update an existing Jarvis install to v4 without redoing the full setup.
# 1) unzip the new version over your old folder:   unzip -o jarvis_v4.zip -d ~   (keeps your .venv and ~/.jarvis)
# 2) run this script from the jarvis folder:        ./update.sh
set -e
cd "$(dirname "$0")"
command -v ollama >/dev/null || { echo "Ollama is not installed; run ./setup.sh instead."; exit 1; }
[ -d .venv ] || { echo "No .venv here; run ./setup.sh instead."; exit 1; }
(pgrep -x ollama >/dev/null || (nohup ollama serve >/dev/null 2>&1 &)); sleep 2
echo "==> Faster language model"
ollama pull qwen3:4b
echo "==> Python packages"
. .venv/bin/activate
pip install -q -U -r requirements.txt
echo "==> Speech models (small English recogniser; the Tamil one is already cached)"
python - <<'PY'
import config
from faster_whisper import WhisperModel
WhisperModel(config.WHISPER_MODEL_EN, device="cpu", compute_type="int8")
print("ok")
PY
sudo -n true 2>/dev/null && { command -v apt >/dev/null && sudo apt install -y xdg-utils libglib2.0-bin || true; } || true
echo
echo "Updated. Next:"
echo "  python jarvis.py --doctor           # checks everything and times each stage"
echo "  python jarvis.py --voices           # pick your English and Tamil voices"
echo "  python jarvis.py --setup-accounts   # connect Gmail + calendar"
echo "  python jarvis.py --setup-jobs       # details for job applications"
