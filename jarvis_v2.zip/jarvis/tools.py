"""Tools Jarvis can call. Each tool is a plain function plus a JSON schema for the LLM."""
import ast
import operator
import os
import re
import shlex
import shutil
import signal
import subprocess
import threading
import urllib.parse
import urllib.request
from datetime import datetime

import psutil

import apps
import briefing
import config
import jobs
import mailcal
import memory
import pentest
import vision
from results import fail

SHELL_TIMEOUT = 60                      # seconds before a shell command is stopped

# Replaced by the Assistant at start-up (GUI confirm dialog / spoken confirm / spoken notification).
confirm = lambda prompt: input(f"{prompt} [y/N] ").strip().lower() == "y"
notify = lambda text: print(f"JARVIS: {text}")


# =============================================================== system
def get_time() -> str:
    return datetime.now().strftime("%A, %d %B %Y, %I:%M %p")


def system_status() -> str:
    vm = psutil.virtual_memory()
    bat = psutil.sensors_battery()
    out = f"CPU {psutil.cpu_percent(interval=0.4)}%, RAM {vm.percent}% of {vm.total // 2**30}GB, disk {psutil.disk_usage('/').percent}% used"
    if bat:
        out += f", battery {bat.percent:.0f}%{' (charging)' if bat.power_plugged else ''}"
    if shutil.which("nvidia-smi"):
        g = subprocess.run(["nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu",
                            "--format=csv,noheader"], capture_output=True, text=True).stdout.strip()
        out += f", GPU {g}"
    return out


def open_app(name: str) -> str:
    return apps.open_app(name)


def close_app(name: str) -> str:
    return apps.close_app(name, confirm)


def open_url(url: str) -> str:
    return apps.open_url(url)


def open_path(path: str) -> str:
    return apps.open_path(path)


def _audio_env() -> dict:
    return apps.clean_env()


def _volume_cmds(arg: str):
    """Candidate commands to set/step the volume, best first. `arg` is '40%', '5%+' or '5%-'."""
    cmds = []
    if shutil.which("wpctl"):
        if arg.endswith(("+", "-")):
            cmds.append(["wpctl", "set-volume", "-l", "1.0", "@DEFAULT_AUDIO_SINK@", arg[:-1] + arg[-1]])
        else:
            cmds.append(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", arg])
    if shutil.which("pactl"):
        step = arg.rstrip("+-")
        val = {"+": f"+{step}", "-": f"-{step}"}.get(arg[-1], arg)
        cmds.append(["pactl", "set-sink-volume", "@DEFAULT_SINK@", val])
    if shutil.which("amixer"):
        cmds.append(["amixer", "sset", "Master", arg])
    return cmds


def _run_first_ok(cmds, timeout=6) -> bool:
    for c in cmds:
        try:
            if subprocess.run(c, capture_output=True, timeout=timeout, env=_audio_env()).returncode == 0:
                return True
        except (OSError, subprocess.TimeoutExpired):
            continue
    return False


def _current_volume() -> int | None:
    try:
        if shutil.which("wpctl"):
            out = subprocess.run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], capture_output=True, text=True,
                                 timeout=4, env=_audio_env()).stdout
            return round(float(out.split()[1]) * 100)
    except Exception:
        pass
    return None


def set_volume(percent: int) -> str:
    percent = max(0, min(100, int(percent)))
    cmds = _volume_cmds(f"{percent}%")
    if not cmds:
        return fail("No volume control found (install pipewire-utils or alsa-utils).")
    return f"Volume set to {percent}%." if _run_first_ok(cmds) else fail("The volume command failed.")


def change_volume(delta: int) -> str:
    delta = max(-100, min(100, int(delta)))
    cmds = _volume_cmds(f"{abs(delta)}%{'+' if delta >= 0 else '-'}")
    if not cmds:
        return fail("No volume control found (install pipewire-utils or alsa-utils).")
    if not _run_first_ok(cmds):
        return fail("The volume command failed.")
    now = _current_volume()
    return f"Volume {'up' if delta >= 0 else 'down'}" + (f", now {now}%." if now is not None else ".")


def mute_audio(state: str = "on") -> str:
    mute = str(state).strip().lower() not in ("off", "false", "0", "unmute", "no")
    flag = "1" if mute else "0"
    cmds = []
    if shutil.which("wpctl"):
        cmds.append(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", flag])
    if shutil.which("pactl"):
        cmds.append(["pactl", "set-sink-mute", "@DEFAULT_SINK@", flag])
    if shutil.which("amixer"):
        cmds.append(["amixer", "sset", "Master", "mute" if mute else "unmute"])
    if not cmds:
        return fail("No volume control found (install pipewire-utils or alsa-utils).")
    return ("Muted." if mute else "Unmuted.") if _run_first_ok(cmds) else fail("The mute command failed.")


def set_brightness(percent: int) -> str:
    if not shutil.which("brightnessctl"):
        return fail("brightnessctl is not installed.")
    p = max(5, min(100, int(percent)))
    r = subprocess.run(["brightnessctl", "set", f"{p}%"], capture_output=True, text=True, env=_audio_env())
    return f"Brightness set to {p}%." if r.returncode == 0 else fail("brightnessctl failed: " + (r.stderr.strip()[:120] or "no backlight device"))


def change_brightness(delta: int) -> str:
    if not shutil.which("brightnessctl"):
        return fail("brightnessctl is not installed.")
    d = max(-100, min(100, int(delta)))
    r = subprocess.run(["brightnessctl", "set", f"{abs(d)}%{'+' if d >= 0 else '-'}"], capture_output=True, text=True,
                       env=_audio_env())
    return f"Brightness {'up' if d >= 0 else 'down'}." if r.returncode == 0 else fail("brightnessctl failed: " + (r.stderr.strip()[:120] or "no backlight device"))


def media_control(action: str) -> str:
    acts = {"play": "play", "pause": "pause", "toggle": "play-pause", "next": "next", "previous": "previous", "stop": "stop"}
    if action not in acts:
        return fail(f"Action must be one of {', '.join(acts)}.")
    if not shutil.which("playerctl"):
        return fail("playerctl is not installed.")
    r = subprocess.run(["playerctl", acts[action]], capture_output=True, text=True, env=_audio_env())
    return "Done." if r.returncode == 0 else fail(r.stderr.strip()[:120] or "No media player is running.")


def lock_screen() -> str:
    if not confirm("Lock the screen?"):
        return fail("Cancelled.")
    for c in (["loginctl", "lock-session"], ["xdg-screensaver", "lock"]):
        if shutil.which(c[0]) and subprocess.run(c, capture_output=True, env=_audio_env()).returncode == 0:
            return "Locked."
    return fail("I couldn't lock the screen (no loginctl or xdg-screensaver).")


def take_screenshot() -> str:
    try:
        p = vision.screenshot(config.HOME / f"screenshot-{datetime.now():%Y%m%d-%H%M%S}.png")
        return f"Screenshot saved to {p}."
    except Exception as e:
        return fail(f"Screenshot failed: {e}")


def _gui_redirect(command: str) -> str | None:
    """If the command just launches a desktop app (e.g. 'firefox', 'nohup firefox &'), return the app name."""
    try:
        parts = shlex.split(command.strip().rstrip("&").strip())
    except ValueError:
        return None
    while parts and parts[0] in ("nohup", "setsid", "exec", "env"):
        parts = parts[1:]
    if not parts or any(c in command for c in (";", "&&", "||", "|", ">", "<", "`", "$(")):
        return None
    prog = os.path.basename(parts[0])
    args = [x for x in parts[1:] if not x.startswith("-")]
    if prog in ("xdg-open", "gio") and args:
        return None
    if len(parts) == 1 and apps.is_gui_app(prog) and prog not in config.SAFE_COMMANDS:
        return prog
    return None


def run_shell(command: str) -> str:
    low = command.lower()
    if any(p in low for p in config.BLOCKED_PATTERNS):
        return fail("Blocked: that command is on the never-run list.")
    app = _gui_redirect(command)
    if app:
        return apps.open_app(app)            # GUI programs must be launched detached, not run in a blocking shell
    try:
        first = shlex.split(command)[0]
    except (ValueError, IndexError):
        return fail("Could not parse that command.")
    chained = any(c in command for c in [";", "&&", "||", "|", ">", "`", "$("])
    if first not in config.SAFE_COMMANDS or chained:
        if not confirm(f"Run shell command: {command}?"):
            return fail("Cancelled by user.")
    background = command.rstrip().endswith("&")
    if background:
        ok, why = apps.launch(["bash", "-c", command.rstrip().rstrip("&")], wait=1.5)
        return "Started in the background." if ok else fail(why)
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                         stdin=subprocess.DEVNULL, start_new_session=True, env=apps.clean_env())
    try:
        out, _ = p.communicate(timeout=SHELL_TIMEOUT)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(p.pid, signal.SIGKILL)  # kill the whole group, or a child can keep the pipe open and hang us
        except ProcessLookupError:
            pass
        p.communicate()
        return fail(f"The command timed out after {SHELL_TIMEOUT} seconds and was stopped.")
    out = (out or "").strip()[-3000:] or "(no output)"
    return out if p.returncode == 0 else fail(f"exit code {p.returncode}: {out[-600:]}")


# =============================================================== files / notes / memory
def read_file(path: str) -> str:
    p = os.path.expanduser(path)
    if not os.path.isfile(p):
        return fail("File not found.")
    with open(p, errors="ignore") as f:
        return f.read(6000)


def find_files(pattern: str, directory: str = "~") -> str:
    import fnmatch
    import time
    root, hits, t0 = os.path.expanduser(directory), [], time.time()
    pat = f"*{pattern}*" if not any(c in pattern for c in "*?[") else pattern
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if not d.startswith(".") and d not in ("node_modules", "__pycache__")]
        for fn in fns:
            if fnmatch.fnmatch(fn.lower(), pat.lower()):
                hits.append(os.path.join(dp, fn))
        if len(hits) >= 10 or time.time() - t0 > 6:
            break
    return "\n".join(hits) or "No matching files."


def take_note(text: str) -> str:
    f = config.NOTES_DIR / f"{datetime.now():%Y-%m-%d}.md"
    with open(f, "a") as fh:
        fh.write(f"- {datetime.now():%H:%M} {text}\n")
    return "Note saved."


def remember_fact(fact: str) -> str:
    return memory.remember(fact)


def search_notes(query: str) -> str:
    memory.index_notes()
    return memory.search_notes(query)


# =============================================================== information
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv, ast.USub: operator.neg}


def calculate(expression: str) -> str:
    def ev(n):
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.operand))
        raise ValueError("unsupported")
    try:
        return str(ev(ast.parse(expression.replace("^", "**"), mode="eval").body))
    except Exception:
        return fail("I could not evaluate that expression.")


def web_search(query: str) -> str:
    try:
        from ddgs import DDGS
        res = DDGS().text(query, max_results=5)
        return "\n".join(f"- {r['title']}: {r['body'][:220]}" for r in res) or "No results."
    except Exception as e:
        return fail(f"Web search is unavailable (offline?): {str(e)[:100]}")


def get_weather(city: str) -> str:
    try:
        url = f"https://wttr.in/{urllib.parse.quote(city)}?format=3"
        with urllib.request.urlopen(url, timeout=8) as r:
            return r.read().decode().strip()
    except Exception as e:
        return fail(f"Could not fetch the weather (offline?): {str(e)[:100]}")


def set_timer(seconds: int, label: str = "Timer") -> str:
    seconds = int(seconds)
    threading.Timer(seconds, lambda: notify(f"{label} is done, sir.")).start()
    m, s = divmod(seconds, 60)
    return f"Timer set for {m} minutes {s} seconds." if m else f"Timer set for {s} seconds."


# =============================================================== vision
def look_at_screen(question: str = "Describe what is on the screen.") -> str:
    try:
        return vision.look_at_screen(question)
    except Exception as e:
        return fail(f"Screen vision failed: {str(e)[:120]}. Is '{config.VISION_MODEL}' pulled?")


def describe_image(path: str, question: str = "Describe this image.") -> str:
    p = os.path.expanduser(path)
    if not os.path.isfile(p):
        return fail("Image not found.")
    try:
        return vision.ask_image(p, question)
    except Exception as e:
        return fail(f"Image analysis failed: {str(e)[:120]}")


# =============================================================== pentest
_PT_FAIL = re.compile(r"^(Tell me the scope|Scope not confirmed|No active engagement|Unknown scan type|"
                      r"That target does not look valid|No wordlist|No scan called|.+ is outside the authori[sz]ed scope|"
                      r".+ is not installed)")


def _pt(result: str) -> str:
    """pentest.py reports problems as plain sentences; mark them with the ERROR convention."""
    return fail(result) if _PT_FAIL.match(result) else result


def pentest_start(name: str, scope: str) -> str:
    return _pt(pentest.start(name, scope, confirm))


def pentest_status() -> str:
    return _pt(pentest.status())


def pentest_scan(tool: str, target: str) -> str:
    return _pt(pentest.run_scan(tool, target, notify))


def pentest_scan_output(scan_id: str = "") -> str:
    return _pt(pentest.scan_output(scan_id))


def pentest_add_finding(title: str, severity: str, target: str, description: str,
                        evidence: str = "", remediation: str = "") -> str:
    return _pt(pentest.add_finding(title, severity, target, description, evidence, remediation))


def pentest_list_findings() -> str:
    return pentest.list_findings()


def pentest_report() -> str:
    return _pt(pentest.generate_report())


# =============================================================== mail / calendar / briefing
def check_mail(limit: int = 3, lang: str = "en") -> str:
    return mailcal.unread_summary(max(1, min(8, int(limit))), lang)


def search_mail(query: str) -> str:
    return mailcal.search_summary(query)


def read_mail(query: str = "") -> str:
    try:
        return mailcal.read(query)
    except Exception as e:
        return fail(str(e)[:160])


def send_mail(to: str, subject: str, body: str, attachment: str = "") -> str:
    return mailcal.send(to, subject, body, [attachment] if attachment else None, confirm)


def calendar_events(day: str = "today", lang: str = "en") -> str:
    return mailcal.events_summary(day, lang)


def next_event(lang: str = "en") -> str:
    return mailcal.next_event_summary(lang)


def daily_briefing(lang: str = "en") -> str:
    return briefing.build(lang)


# =============================================================== job applications
def job_search(query: str, location: str = "") -> str:
    return jobs.search(query, location)


def job_open_boards(query: str, location: str = "") -> str:
    return jobs.open_boards(query, location)


def job_track(company: str = "", role: str = "", url: str = "", status: str = "saved", notes: str = "",
              from_result: int = 0) -> str:
    return jobs.track(company, role, url, status, notes, int(from_result or 0))


def job_update(ref: str, status: str = "", notes: str = "") -> str:
    return jobs.update(ref, status, notes)


def job_list(status: str = "") -> str:
    return jobs.list_applications(status)


def job_followups() -> str:
    return jobs.followups_summary()


def job_cover_letter(company: str, role: str, job_description: str = "", url: str = "") -> str:
    r = jobs.cover_letter(company, role, job_description, url)
    return r if r.startswith("ERROR") else "Cover letter written and saved in the applications folder:\n" + r


def job_prepare(company: str, role: str, url: str = "", job_description: str = "") -> str:
    return jobs.prepare(company, role, url, job_description)


def job_email_application(to: str, company: str, role: str) -> str:
    return jobs.email_application(to, company, role, confirm)


# =============================================================== registry
def _fn(name, desc, props=None, required=None):
    return {"type": "function", "function": {
        "name": name, "description": desc,
        "parameters": {"type": "object", "properties": props or {}, "required": required or []}}}


_S = lambda d: {"type": "string", "description": d}
_I = lambda d: {"type": "integer", "description": d}

_TOOL_LIST = [
    (get_time, _fn("get_time", "Current date and time.")),
    (system_status, _fn("system_status", "CPU, RAM, disk, battery and GPU status.")),
    (open_app, _fn("open_app", "Launch a desktop app by name.", {"name": _S("app name, e.g. firefox")}, ["name"])),
    (open_url, _fn("open_url", "Open a website in the browser.", {"url": _S("URL")}, ["url"])),
    (open_path, _fn("open_path", "Open a file or folder with its default app.", {"path": _S("path")}, ["path"])),
    (close_app, _fn("close_app", "Close a running desktop app (asks for confirmation).", {"name": _S("app name")}, ["name"])),
    (set_volume, _fn("set_volume", "Set system volume to an exact level 0-100.", {"percent": _I("0-100")}, ["percent"])),
    (change_volume, _fn("change_volume", "Raise (positive) or lower (negative) the volume by a number of percent.", {"delta": _I("e.g. 10 or -10")}, ["delta"])),
    (mute_audio, _fn("mute_audio", "Mute or unmute the sound.", {"state": {"type": "string", "enum": ["on", "off"], "description": "on = mute, off = unmute"}})),
    (change_brightness, _fn("change_brightness", "Raise (positive) or lower (negative) the screen brightness by percent.", {"delta": _I("e.g. 10 or -10")}, ["delta"])),
    (take_screenshot, _fn("take_screenshot", "Save a screenshot of the screen to a file.")),
    (set_brightness, _fn("set_brightness", "Set screen brightness 5-100.", {"percent": _I("5-100")}, ["percent"])),
    (media_control, _fn("media_control", "Control music/video playback.",
                        {"action": {"type": "string", "enum": ["play", "pause", "toggle", "next", "previous", "stop"]}}, ["action"])),
    (lock_screen, _fn("lock_screen", "Lock the screen (asks for confirmation).")),
    (run_shell, _fn("run_shell", "Run a shell command on this Linux machine. Risky ones ask the user first.", {"command": _S("the command")}, ["command"])),
    (read_file, _fn("read_file", "Read the start of a text file.", {"path": _S("file path")}, ["path"])),
    (find_files, _fn("find_files", "Find files by name under a folder.", {"pattern": _S("name or glob"), "directory": _S("folder, default home")}, ["pattern"])),
    (take_note, _fn("take_note", "Append a note to today's notes file.", {"text": _S("note")}, ["text"])),
    (remember_fact, _fn("remember_fact", "Store a durable fact about the user in long-term memory.", {"fact": _S("the fact")}, ["fact"])),
    (search_notes, _fn("search_notes", "Semantic search over the user's notes folder.", {"query": _S("what to look for")}, ["query"])),
    (calculate, _fn("calculate", "Evaluate an arithmetic expression exactly.", {"expression": _S("e.g. 12*(3+4)")}, ["expression"])),
    (web_search, _fn("web_search", "Search the web (needs internet).", {"query": _S("search query")}, ["query"])),
    (get_weather, _fn("get_weather", "Current weather for a city (needs internet).", {"city": _S("city name")}, ["city"])),
    (set_timer, _fn("set_timer", "Set a countdown timer; Jarvis speaks when it ends.", {"seconds": _I("duration in seconds"), "label": _S("what it is for")}, ["seconds"])),
    (look_at_screen, _fn("look_at_screen", "Take a screenshot and answer a question about what is on screen (read text, explain an error, describe a window).", {"question": _S("what to look for")})),
    (describe_image, _fn("describe_image", "Answer a question about an image file.", {"path": _S("image path"), "question": _S("question")}, ["path"])),
    (check_mail, _fn("check_mail", "Summarise unread email (count and newest senders and subjects).", {"limit": _I("how many to list, default 3")})),
    (search_mail, _fn("search_mail", "Search the inbox. Gmail syntax works (from:amazon, newer_than:2d).", {"query": _S("search text")}, ["query"])),
    (read_mail, _fn("read_mail", "Read the body of the newest email matching a search (empty = newest unread). Does not mark it read.", {"query": _S("sender or subject words")})),
    (send_mail, _fn("send_mail", "Send an email. Always asks the user to confirm first.", {"to": _S("one email address"), "subject": _S("subject"), "body": _S("message text"), "attachment": _S("optional file path")}, ["to", "subject", "body"])),
    (calendar_events, _fn("calendar_events", "Read the calendar for a day.", {"day": _S("today, tomorrow, week, a weekday name, or YYYY-MM-DD")})),
    (next_event, _fn("next_event", "The next upcoming calendar event.")),
    (daily_briefing, _fn("daily_briefing", "Spoken briefing: date, weather, today's calendar, unread mail, job follow-ups.")),
    (job_search, _fn("job_search", "Search the web for job listings; results are numbered.", {"query": _S("role, e.g. security analyst"), "location": _S("city")}, ["query"])),
    (job_open_boards, _fn("job_open_boards", "Open LinkedIn, Indeed, Naukri and Google Jobs searches in the browser.", {"query": _S("role"), "location": _S("city")}, ["query"])),
    (job_track, _fn("job_track", "Add a job to the application tracker. from_result=N uses the Nth listing of the last job_search.", {"company": _S("company"), "role": _S("job title"), "url": _S("link"), "status": {"type": "string", "enum": jobs.STATUSES}, "notes": _S("notes"), "from_result": _I("result number from job_search")})),
    (job_update, _fn("job_update", "Change the status or add notes to a tracked application (by number or company name). Marking applied sets a 7-day follow-up.", {"ref": _S("number or company"), "status": {"type": "string", "enum": jobs.STATUSES}, "notes": _S("notes")}, ["ref"])),
    (job_list, _fn("job_list", "List tracked job applications, optionally by status.", {"status": {"type": "string", "enum": jobs.STATUSES}})),
    (job_followups, _fn("job_followups", "Applications that are due a follow-up.")),
    (job_cover_letter, _fn("job_cover_letter", "Write a tailored cover letter from the user's saved profile.", {"company": _S("company"), "role": _S("job title"), "job_description": _S("job description text, optional"), "url": _S("job link, optional")}, ["company", "role"])),
    (job_prepare, _fn("job_prepare", "Get an application ready: track it, write the cover letter, copy it to the clipboard and open the apply page. The user submits it.", {"company": _S("company"), "role": _S("job title"), "url": _S("apply link"), "job_description": _S("optional")}, ["company", "role"])),
    (job_email_application, _fn("job_email_application", "Email the cover letter and resume to a recruiter. Asks the user to confirm first.", {"to": _S("recruiter email"), "company": _S("company"), "role": _S("job title")}, ["to", "company", "role"])),
    (pentest_start, _fn("pentest_start", "Start or resume a pentest engagement with an authorised scope (asks the user to confirm).", {"name": _S("engagement name"), "scope": _S("comma-separated IPs, CIDR ranges or hostnames")}, ["name", "scope"])),
    (pentest_status, _fn("pentest_status", "Show the active pentest engagement, scans and findings count.")),
    (pentest_scan, _fn("pentest_scan", "Run a scan in the background against an in-scope target.", {"tool": {"type": "string", "enum": pentest.SCAN_TOOLS}, "target": _S("in-scope IP or host")}, ["tool", "target"])),
    (pentest_scan_output, _fn("pentest_scan_output", "Read a finished scan's output so it can be summarised. Empty scan_id means the latest.", {"scan_id": _S("e.g. s1")})),
    (pentest_add_finding, _fn("pentest_add_finding", "Record a vulnerability finding for the report.", {"title": _S("short title"), "severity": {"type": "string", "enum": pentest.SEVERITIES}, "target": _S("affected host/port"), "description": _S("what it is and impact"), "evidence": _S("proof, e.g. scan line"), "remediation": _S("how to fix")}, ["title", "severity", "target", "description"])),
    (pentest_list_findings, _fn("pentest_list_findings", "List recorded findings.")),
    (pentest_report, _fn("pentest_report", "Generate the pentest report (Markdown, plus HTML if pandoc is installed).")),
]

TOOLS = {f.__name__: (f, schema) for f, schema in _TOOL_LIST}
SCHEMAS = [s for _, s in _TOOL_LIST]


def call(name: str, args: dict) -> str:
    if name not in TOOLS:
        return fail(f"Unknown tool {name}.")
    try:
        return str(TOOLS[name][0](**args))
    except Exception as e:  # keep the assistant alive on tool errors
        return fail(f"Tool {name} failed: {str(e)[:160]}")


# =============================================================== tool subsetting (a smaller prompt is a faster prompt)
CORE = {"get_time", "open_app", "open_url", "run_shell", "remember_fact", "calculate", "web_search"}
GROUPS = {
    "device": ({"close_app", "open_path", "set_volume", "change_volume", "mute_audio", "set_brightness",
                "change_brightness", "media_control", "lock_screen", "take_screenshot", "set_timer", "find_files",
                "read_file", "take_note"},
               ("close", "quit", "volume", "sound", "mute", "bright", "music", "song", "pause", "play", "next track",
                "lock", "screenshot", "timer", "remind", "folder", "file", "note", "write down",
                "download", "document", "மூடு", "ஒலி", "வால்யூம்", "பிரைட்", "பாட்டு", "டைமர்", "நினைவூட்டு",
                "கோப்பு", "குறிப்பு", "பூட்டு")),
    "info": ({"system_status", "get_weather", "search_notes", "calculate"},
             ("status", "cpu", "ram", "memory", "battery", "disk", "gpu", "weather", "temperature", "notes", "note",
              "remember", "what did i", "நிலை", "வானிலை", "பேட்டரி", "குறிப்பு", "நினைவு")),
    "vision": ({"look_at_screen", "describe_image", "take_screenshot"},
               ("screen", "see", "look", "image", "picture", "photo", "read this", "error on", "what's on", "திரை", "படம்", "பார்")),
    "mail": ({"check_mail", "search_mail", "read_mail", "send_mail", "daily_briefing"},
             ("mail", "inbox", "gmail", "unread", "message from", "மின்னஞ்சல்", "மெயில்", "இமெயில்")),
    "calendar": ({"calendar_events", "next_event", "daily_briefing", "set_timer"},
                 ("calendar", "schedule", "meeting", "event", "appointment", "agenda", "my day", "briefing", "brief me",
                  "today", "tomorrow", "next week", "கேலண்டர்", "அட்டவணை", "கூட்டம்", "நிகழ்வு", "இன்று", "நாளை")),
    "jobs": ({"job_search", "job_open_boards", "job_track", "job_update", "job_list", "job_followups",
              "job_cover_letter", "job_prepare", "job_email_application", "send_mail", "open_url"},
             ("job", "apply", "application", "resume", "cv ", "cover letter", "interview", "recruiter", "hiring",
              "vacancy", "career", "வேலை", "விண்ணப்ப", "நேர்காணல்")),
    "pentest": (set(pentest_names := {"pentest_start", "pentest_status", "pentest_scan", "pentest_scan_output",
                                      "pentest_add_finding", "pentest_list_findings", "pentest_report"}),
                ("pentest", "scan", "nmap", "nikto", "vulnerab", "finding", "report", "scope", "engagement",
                 "exploit", "port", "security test", "ஸ்கேன்", "பாதிப்பு")),
}


def select_schemas(text: str) -> list[dict]:
    """Core tools plus the groups whose keywords appear in the request. Falls back to every tool for vague requests."""
    low = text.lower()
    names = set(CORE)
    for tools_, words in GROUPS.values():
        if any(w in low for w in words):
            names |= tools_
    if len(names) == len(CORE) and len(low.split()) > 12:
        return SCHEMAS                                   # long, unclear request: give the model everything
    return [s for s in SCHEMAS if s["function"]["name"] in names]
