#!/usr/bin/env bash
# One-shot setup for Jarvis v4 on Linux. Run: ./setup.sh   (about 8 GB of downloads)
set -e
cd "$(dirname "$0")"
DIR="$(pwd)"

echo "==> System packages (needs sudo)"
if command -v pacman >/dev/null; then
  sudo pacman -S --needed --noconfirm xdg-utils glib2 python python-pip portaudio libsndfile ffmpeg nmap chromium noto-fonts \
       scrot grim playerctl brightnessctl pandoc pipewire-pulse || true
elif command -v apt >/dev/null; then
  sudo apt update
  sudo apt install -y xdg-utils libglib2.0-bin python3 python3-venv python3-pip portaudio19-dev libsndfile1 ffmpeg nmap fonts-noto-core \
       scrot grim playerctl brightnessctl pandoc || true
  command -v chromium >/dev/null || command -v chromium-browser >/dev/null || command -v google-chrome >/dev/null \
       || sudo apt install -y chromium || sudo apt install -y chromium-browser || true
fi

echo "==> Ollama"
command -v ollama >/dev/null || curl -fsSL https://ollama.com/install.sh | sh
(pgrep -x ollama >/dev/null || (nohup ollama serve >/dev/null 2>&1 &)); sleep 3

echo "==> Models: language (2.5 GB), vision (3 GB), embeddings"
ollama pull qwen3:4b
ollama pull qwen2.5vl:3b
ollama pull nomic-embed-text

echo "==> Python environment"
python3 -m venv .venv
. .venv/bin/activate
pip install -U pip wheel
pip install torch --index-url https://download.pytorch.org/whl/cpu      # CPU build (Tamil voice), keeps GPU free
pip install -r requirements.txt
pip install --no-deps openwakeword                                        # avoids the tflite-runtime wheel problem

echo "==> English voice (Piper, British male)"
mkdir -p ~/.jarvis/voices && cd ~/.jarvis/voices
base=https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_GB/alan/medium
[ -f en_GB-alan-medium.onnx ]      || curl -L -O $base/en_GB-alan-medium.onnx
[ -f en_GB-alan-medium.onnx.json ] || curl -L -O $base/en_GB-alan-medium.onnx.json
cd "$DIR"

echo "==> Caching speech models so Jarvis works fully offline afterwards"
python - <<'PY'
import config
import openwakeword
openwakeword.utils.download_models()
from faster_whisper import WhisperModel
WhisperModel(config.WHISPER_MODEL_EN, device="cpu", compute_type="int8")
WhisperModel(config.WHISPER_MODEL_TA, device="cpu", compute_type="int8")
from transformers import AutoTokenizer, VitsModel
AutoTokenizer.from_pretrained("facebook/mms-tts-tam"); VitsModel.from_pretrained("facebook/mms-tts-tam")
print("speech models cached")
PY

echo "==> App launcher"
mkdir -p ~/.local/share/applications
cat > ~/.local/share/applications/jarvis.desktop <<EOF
[Desktop Entry]
Type=Application
Name=J.A.R.V.I.S.
Comment=Local Tamil/English voice assistant
Exec=$DIR/.venv/bin/python $DIR/jarvis.py
Path=$DIR
Icon=$DIR/ui/icon.svg
Terminal=false
Categories=Utility;
StartupWMClass=Jarvis
EOF

echo
echo "Done. Open 'J.A.R.V.I.S.' from your application menu, or run:  .venv/bin/python jarvis.py"
echo "Check speed and setup:  .venv/bin/python jarvis.py --doctor"
echo "Choose voices:  .venv/bin/python jarvis.py --voices   (or the gear in the app)"
echo "Connect mail/calendar:  .venv/bin/python jarvis.py --setup-accounts"
echo "Preview the interface without models:  .venv/bin/python jarvis.py --demo"
