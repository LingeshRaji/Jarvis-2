// 3D holographic core: gyroscope rings, wireframe shells, audio-reactive spectrum ring, particle field,
// scan beam and bloom. Everything is vendored locally, so it works offline.
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

const COL = {
  offline: [110, 135, 148], idle: [95, 227, 255], listening: [141, 255, 217],
  thinking: [255, 179, 71], tool: [255, 179, 71], speaking: [200, 246, 255],
};

function spriteTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d'), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

function discTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d'), gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.7, 'rgba(255,255,255,.07)');
  gr.addColorStop(0.95, 'rgba(255,255,255,.5)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export async function createCore3D(canvas, { quality = 'high', reduce = false } = {}) {
  const renderer = new THREE.WebGLRenderer({
    canvas, antialias: quality === 'high', alpha: false,
    powerPreference: 'low-power',            // prefer the integrated GPU so the NVIDIA card keeps its VRAM for the LLM
  });
  const dpr = Math.min(window.devicePixelRatio || 1, quality === 'high' ? 1.5 : 1);
  renderer.setPixelRatio(dpr);
  renderer.setClearColor(0x02070b, 1);

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x02070b, 0.03);
  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 120);

  // ---------------------------------------------------------------- state
  let state = 'offline', lvl = 0, target = 0, busyAmt = 0;
  const color = COL.offline.slice();
  const tintColor = new THREE.Color();
  const tint = [];   // { m, base, k }  materials that follow the state colour
  const dflt = () => 0.75 + lvl * 0.5;

  function basic(opacity, Cls = THREE.MeshBasicMaterial, k = dflt, extra = {}) {
    const m = new Cls({ color: 0x5fe3ff, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false, ...extra });
    tint.push({ m, base: opacity, k });
    return m;
  }

  const root = new THREE.Group(); scene.add(root);
  const core = new THREE.Group(); root.add(core);

  // ---------------------------------------------------------------- core sphere (fresnel glow)
  const coreMat = new THREE.ShaderMaterial({
    uniforms: { uColor: { value: new THREE.Color(0x5fe3ff) }, uTime: { value: 0 }, uLevel: { value: 0 } },
    vertexShader: `varying vec3 vN; varying vec3 vV;
      void main(){ vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position,1.0); vV = -mv.xyz; gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `uniform vec3 uColor; uniform float uTime; uniform float uLevel; varying vec3 vN; varying vec3 vV;
      void main(){
        float f = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 2.0);
        float pulse = 0.88 + 0.12 * sin(uTime * 2.1);
        vec3 c = mix(uColor, vec3(1.0), 0.22 - f * 0.12);
        float a = (0.3 + f * 0.95) * (0.85 + uLevel * 0.8) * pulse;
        gl_FragColor = vec4(c * a, 1.0);
      }`,
    transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
  });
  const coreSphere = new THREE.Mesh(new THREE.SphereGeometry(0.6, 48, 32), coreMat);
  core.add(coreSphere);

  // ---------------------------------------------------------------- wireframe shells
  const w1 = new THREE.LineSegments(new THREE.WireframeGeometry(new THREE.IcosahedronGeometry(0.95, 2)), basic(0.5, THREE.LineBasicMaterial));
  const w2 = new THREE.LineSegments(new THREE.WireframeGeometry(new THREE.IcosahedronGeometry(1.14, 1)), basic(0.24, THREE.LineBasicMaterial));
  core.add(w1, w2);

  // ---------------------------------------------------------------- gyroscope rings with orbiting nodes
  const specs = [
    { r: 1.62, tube: 0.014, arc: Math.PI * 2, tilt: [1.2, 0.2, 0.0], spin: 0.55, pre: [0.02, 0.05, 0] },
    { r: 2.02, tube: 0.026, arc: Math.PI * 1.5, tilt: [0.5, 1.0, 0.3], spin: -0.38, pre: [0.04, -0.03, 0] },
    { r: 2.42, tube: 0.014, arc: Math.PI * 2, tilt: [1.45, 0.4, 0.9], spin: 0.26, pre: [-0.03, 0.04, 0.02] },
    { r: 2.82, tube: 0.032, arc: Math.PI * 1.1, tilt: [0.9, -0.6, 0.2], spin: -0.18, pre: [0.01, 0.03, 0] },
  ];
  const gyros = specs.map((s) => {
    const pivot = new THREE.Group(); pivot.rotation.set(...s.tilt);
    const spinner = new THREE.Group();
    spinner.add(new THREE.Mesh(new THREE.TorusGeometry(s.r, s.tube, 8, 220, s.arc), basic(0.7)));
    const node = new THREE.Mesh(new THREE.SphereGeometry(0.075, 16, 16), basic(0.9));
    node.position.set(Math.cos(s.arc) * s.r, Math.sin(s.arc) * s.r, 0);
    spinner.add(node);
    if (s.arc < Math.PI * 2) pivot.add(new THREE.Mesh(new THREE.TorusGeometry(s.r, 0.004, 4, 220), basic(0.28)));
    pivot.add(spinner); core.add(pivot);
    return { pivot, spinner, ...s };
  });

  // ---------------------------------------------------------------- segmented coil
  const coil = new THREE.Group();
  for (let k = 0; k < 12; k++) {
    const seg = new THREE.Mesh(new THREE.TorusGeometry(1.3, 0.05, 6, 14, 0.42), basic(0.6));
    seg.rotation.z = (k / 12) * Math.PI * 2; coil.add(seg);
  }
  core.add(coil);

  // ---------------------------------------------------------------- audio-reactive spectrum ring
  const N = 112, R0 = 1.92;
  const spectrum = new THREE.InstancedMesh(new THREE.BoxGeometry(0.036, 1, 0.036), basic(0.8), N);
  spectrum.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  spectrum.frustumCulled = false;
  core.add(spectrum);
  const dummy = new THREE.Object3D();

  // ---------------------------------------------------------------- tick rings (one facing us, one lying flat)
  const tickPos = [];
  for (let i = 0; i < 240; i++) {
    const a = (i / 240) * Math.PI * 2, len = i % 20 === 0 ? 0.22 : i % 5 === 0 ? 0.12 : 0.06, r0 = 3.05;
    tickPos.push(Math.cos(a) * r0, Math.sin(a) * r0, 0, Math.cos(a) * (r0 + len), Math.sin(a) * (r0 + len), 0);
  }
  const tickGeo = new THREE.BufferGeometry();
  tickGeo.setAttribute('position', new THREE.Float32BufferAttribute(tickPos, 3));
  const ticks = new THREE.LineSegments(tickGeo, basic(0.7, THREE.LineBasicMaterial));
  const ticks2 = new THREE.LineSegments(tickGeo, basic(0.35, THREE.LineBasicMaterial));
  ticks2.rotation.x = Math.PI / 2 + 0.25; ticks2.scale.setScalar(1.12);
  core.add(ticks, ticks2);

  // ---------------------------------------------------------------- particle field
  const PN = 2200, pos = new Float32Array(PN * 3);
  for (let i = 0; i < PN; i++) {
    const r = i < PN * 0.6 ? 2.2 + Math.random() * 2.2 : 4.4 + Math.random() * 3.2;
    const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, s = Math.sqrt(1 - u * u);
    pos.set([r * s * Math.cos(th), r * u, r * s * Math.sin(th)], i * 3);
  }
  const pGeo = new THREE.BufferGeometry();
  pGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const points = new THREE.Points(pGeo, basic(0.8, THREE.PointsMaterial, dflt, { size: 0.06, map: spriteTexture(), sizeAttenuation: true }));
  core.add(points);

  // ---------------------------------------------------------------- scan beam (thinking)
  const scan = new THREE.Group();
  const scanRing = new THREE.Mesh(new THREE.TorusGeometry(2.45, 0.016, 6, 160), basic(0.9, THREE.MeshBasicMaterial, () => busyAmt));
  scanRing.rotation.x = Math.PI / 2;
  const scanDisc = new THREE.Mesh(new THREE.CircleGeometry(2.45, 64),
    basic(0.5, THREE.MeshBasicMaterial, () => busyAmt, { map: discTexture(), side: THREE.DoubleSide }));
  scanDisc.rotation.x = -Math.PI / 2;
  scan.add(scanRing, scanDisc); scan.visible = false; core.add(scan);

  // ---------------------------------------------------------------- post-processing
  let composer = null, bloom = null;
  if (quality === 'high') {
    composer = new EffectComposer(renderer);
    composer.setPixelRatio(dpr);
    composer.addPass(new RenderPass(scene, camera));
    bloom = new UnrealBloomPass(new THREE.Vector2(256, 256), 0.5, 0.4, 0.22);
    composer.addPass(bloom);
    composer.addPass(new OutputPass());
  }

  // ---------------------------------------------------------------- layout: put the core at (cx, cy), outer ring ~ R * 1.5 px
  function layout({ W, H, cx, cy, R }) {
    renderer.setSize(W, H, false);
    if (composer) composer.setSize(W, H);
    camera.aspect = W / H;
    const pxPerUnit = (R * 1.5) / 3.4;
    const d = H / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * pxPerUnit);
    camera.position.set(0, 0, d);
    camera.setViewOffset(W, H, W / 2 - cx, H / 2 - cy, W, H);
    camera.updateProjectionMatrix();
    pointer.cx = cx; pointer.cy = cy; pointer.W = W; pointer.H = H;
  }

  // ---------------------------------------------------------------- interaction: parallax + drag to spin
  const pointer = { x: 0, y: 0, cx: 0, cy: 0, W: 1, H: 1 };
  const drag = { x: 0, y: 0, active: false, lx: 0, ly: 0 };
  const isUi = (el) => el.closest && el.closest('input,button,label,#log,.rail,#confirm,#composer');
  window.addEventListener('pointermove', (e) => {
    pointer.x = Math.max(-1, Math.min(1, (e.clientX - pointer.cx) / (pointer.W / 2)));
    pointer.y = Math.max(-1, Math.min(1, (e.clientY - pointer.cy) / (pointer.H / 2)));
    if (drag.active) {
      drag.y += (e.clientX - drag.lx) * 0.008; drag.x += (e.clientY - drag.ly) * 0.008;
      drag.lx = e.clientX; drag.ly = e.clientY;
    }
  });
  window.addEventListener('pointerdown', (e) => {
    if (isUi(e.target)) return;
    drag.active = true; drag.lx = e.clientX; drag.ly = e.clientY; document.body.classList.add('grabbing');
  });
  const release = () => { drag.active = false; document.body.classList.remove('grabbing'); };
  window.addEventListener('pointerup', release);
  window.addEventListener('pointercancel', release);

  // ---------------------------------------------------------------- frame loop
  let last = performance.now();
  function frame(now) {
    const raw = Math.min(0.5, (now - last) / 1000), dt = Math.min(0.05, raw); last = now;
    const t = now / 1000, spin = reduce ? 0.15 : 1;
    const ease = (rate) => 1 - Math.exp(-raw * rate);       // frame-rate independent smoothing

    lvl += (target - lvl) * ease(14);
    const c = COL[state];
    for (let i = 0; i < 3; i++) color[i] += (c[i] - color[i]) * ease(5);
    const busy = state === 'thinking' || state === 'tool';
    busyAmt += ((busy ? 1 : 0) - busyAmt) * ease(5);
    const fast = 1 + busyAmt * 3;

    tintColor.setRGB(color[0] / 255, color[1] / 255, color[2] / 255, THREE.SRGBColorSpace);
    for (const { m, base, k } of tint) { m.color.copy(tintColor); m.opacity = Math.min(1, base * k()); }
    coreMat.uniforms.uColor.value.copy(tintColor);
    coreMat.uniforms.uTime.value = t;
    coreMat.uniforms.uLevel.value = lvl;

    for (const g of gyros) {
      g.spinner.rotation.z += g.spin * dt * spin * fast;
      g.pivot.rotation.x += g.pre[0] * dt * spin; g.pivot.rotation.y += g.pre[1] * dt * spin; g.pivot.rotation.z += g.pre[2] * dt * spin;
    }
    coil.rotation.z += 0.3 * dt * spin * fast;
    w1.rotation.y += 0.25 * dt * spin * fast; w1.rotation.x += 0.1 * dt * spin;
    w2.rotation.y -= 0.18 * dt * spin * fast; w2.rotation.z += 0.07 * dt * spin;
    ticks.rotation.z -= 0.05 * dt * spin * (1 + busyAmt * 4);
    ticks2.rotation.y += 0.04 * dt * spin;
    points.rotation.y += 0.02 * dt * spin; points.scale.setScalar(1 + lvl * 0.07);
    coreSphere.scale.setScalar(1 + 0.035 * Math.sin(t * 2.1) + lvl * 0.3);
    w1.scale.setScalar(1 + lvl * 0.1);

    for (let i = 0; i < N; i++) {
      const a = (i / N) * Math.PI * 2;
      const n = 0.5 + 0.5 * Math.sin(t * 4.2 + i * 0.55) * Math.sin(t * 2.7 + i * 1.7);
      const h = 0.06 + 0.04 * Math.sin(t * 1.6 + i * 0.22) + lvl * 0.95 * (0.25 + n);
      dummy.position.set(Math.cos(a) * (R0 + h / 2), Math.sin(a) * (R0 + h / 2), 0);
      dummy.rotation.set(0, 0, a - Math.PI / 2);
      dummy.scale.set(1, h, 1);
      dummy.updateMatrix();
      spectrum.setMatrixAt(i, dummy.matrix);
    }
    spectrum.instanceMatrix.needsUpdate = true;

    scan.visible = busyAmt > 0.02;
    if (scan.visible) scan.position.y = Math.sin(t * 1.7 * spin) * 1.9;

    if (!drag.active) { drag.x *= 0.99; drag.y *= 0.99; }
    const ty = pointer.x * 0.4 + drag.y + Math.sin(t * 0.25) * 0.12 * spin;
    const tx = 0.34 + pointer.y * 0.25 + drag.x + Math.cos(t * 0.21) * 0.07 * spin;   // slight downward tilt so flat rings read as 3D
    root.rotation.y += (ty - root.rotation.y) * ease(4);
    root.rotation.x += (tx - root.rotation.x) * ease(4);

    if (bloom) bloom.strength = 0.45 + lvl * 0.5 + busyAmt * 0.1;
    if (composer) composer.render(); else renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }

  return {
    kind: '3d',
    layout,
    setState(s) { if (COL[s]) state = s; },
    setLevel(v) { target = v; },
    start() { last = performance.now(); requestAnimationFrame(frame); },
  };
}
