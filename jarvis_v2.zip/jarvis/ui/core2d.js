// Flat 2D fallback renderer (used when WebGL is unavailable or HUD_QUALITY = "low").
const COL = {
  offline: [110, 135, 148], idle: [95, 227, 255], listening: [141, 255, 217],
  thinking: [255, 179, 71], tool: [255, 179, 71], speaking: [200, 246, 255],
};

export function createCore2D(canvas, { reduce = false } = {}) {
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('2D canvas unavailable');
  let state = 'offline', color = COL.offline.slice();
  let lvl = 0, target = 0, busyAmt = 0;
  let W = 0, H = 0, DPR = 1, cx = 0, cy = 0, R = 100, bg = null;

  function layout(l) {
    DPR = window.devicePixelRatio || 1;
    ({ W, H, cx, cy, R } = l);
    canvas.width = W * DPR; canvas.height = H * DPR;
    bg = document.createElement('canvas');
    bg.width = W * DPR; bg.height = H * DPR;
    const b = bg.getContext('2d');
    b.scale(DPR, DPR);
    const g = b.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H) * 0.72);
    g.addColorStop(0, '#07242f'); g.addColorStop(0.45, '#031019'); g.addColorStop(1, '#02070b');
    b.fillStyle = g; b.fillRect(0, 0, W, H);
    const m = Math.max(W, H);
    for (let x = 14; x < W; x += 28) {
      for (let y = 14; y < H; y += 28) {
        const a = 0.26 - Math.hypot(x - cx, y - cy) / m * 0.34;
        if (a > 0.015) { b.fillStyle = `rgba(95,227,255,${a})`; b.fillRect(x, y, 1.5, 1.5); }
      }
    }
  }

  function frame(t) {
    const spin = reduce ? 0.15 : 1;
    lvl += (target - lvl) * 0.22;
    const c = COL[state];
    for (let i = 0; i < 3; i++) color[i] += (c[i] - color[i]) * 0.07;
    const busy = state === 'thinking' || state === 'tool';
    busyAmt += ((busy ? 1 : 0) - busyAmt) * 0.08;
    const rgba = (a) => `rgba(${color[0] | 0},${color[1] | 0},${color[2] | 0},${a})`;

    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    if (bg) ctx.drawImage(bg, 0, 0, W, H);
    ctx.save();
    ctx.translate(cx, cy);
    ctx.lineCap = 'butt';

    let g = ctx.createRadialGradient(0, 0, R * 0.1, 0, 0, R * 1.55);
    g.addColorStop(0, rgba(0.2 + lvl * 0.3)); g.addColorStop(0.6, rgba(0.05 + lvl * 0.06)); g.addColorStop(1, rgba(0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R * 1.55, 0, 7); ctx.fill();

    ctx.save();
    ctx.rotate(t * 0.00005 * spin * (1 + busyAmt * 5));
    for (let i = 0; i < 180; i++) {
      const a = (i / 180) * Math.PI * 2, major = i % 15 === 0, mid = i % 5 === 0;
      const r0 = R * 1.24, r1 = r0 + R * (major ? 0.1 : mid ? 0.055 : 0.028);
      ctx.strokeStyle = rgba(major ? 0.9 : mid ? 0.55 : 0.3);
      ctx.lineWidth = major ? 1.8 : 1;
      ctx.beginPath(); ctx.moveTo(Math.cos(a) * r0, Math.sin(a) * r0); ctx.lineTo(Math.cos(a) * r1, Math.sin(a) * r1); ctx.stroke();
    }
    ctx.restore();

    ctx.save();
    ctx.rotate(-t * 0.00016 * spin * (1 + busyAmt * 3));
    ctx.lineWidth = 3.5; ctx.strokeStyle = rgba(0.85);
    for (const [s, l] of [[0, 0.9], [1.7, 0.45], [2.8, 1.25], [4.7, 0.65]]) {
      ctx.beginPath(); ctx.arc(0, 0, R * 1.12, s, s + l); ctx.stroke();
    }
    ctx.restore();

    ctx.save();
    ctx.rotate(t * 0.00009 * spin);
    ctx.setLineDash([1.5, 7]); ctx.lineWidth = 1.5; ctx.strokeStyle = rgba(0.6);
    ctx.beginPath(); ctx.arc(0, 0, R * 1.0, 0, 7); ctx.stroke();
    ctx.restore();

    const N = 112, r0 = R * 0.76;
    ctx.lineCap = 'round'; ctx.lineWidth = 2.4;
    for (let i = 0; i < N; i++) {
      const a = (i / N) * Math.PI * 2 - Math.PI / 2;
      const n = 0.5 + 0.5 * Math.sin(t * 0.0042 + i * 0.55) * Math.sin(t * 0.0027 + i * 1.7);
      const breathe = 0.035 + 0.022 * Math.sin(t * 0.0016 + i * 0.22);
      const h = R * (breathe + lvl * 0.2 * (0.25 + n));
      ctx.strokeStyle = rgba(0.45 + lvl * 0.5);
      ctx.beginPath(); ctx.moveTo(Math.cos(a) * r0, Math.sin(a) * r0);
      ctx.lineTo(Math.cos(a) * (r0 + h), Math.sin(a) * (r0 + h)); ctx.stroke();
    }
    ctx.lineCap = 'butt';

    ctx.lineWidth = 1; ctx.strokeStyle = rgba(0.35);
    ctx.beginPath(); ctx.arc(0, 0, R * 0.7, 0, 7); ctx.stroke();
    ctx.strokeStyle = rgba(0.5); ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.arc(0, 0, R * 0.46, 0, 7); ctx.stroke();

    ctx.save();
    ctx.rotate(t * 0.00012 * spin * (1 + busyAmt * 4));
    ctx.lineWidth = R * 0.06; ctx.strokeStyle = rgba(0.5 + lvl * 0.3);
    for (let i = 0; i < 12; i++) {
      const s = (i / 12) * Math.PI * 2;
      ctx.beginPath(); ctx.arc(0, 0, R * 0.58, s, s + 0.36); ctx.stroke();
    }
    ctx.restore();

    if (busyAmt > 0.02) {
      const ang = t * 0.0042 * spin;
      ctx.lineWidth = 2.2;
      for (let k = 0; k < 36; k++) {
        ctx.strokeStyle = rgba((1 - k / 36) * 0.65 * busyAmt);
        ctx.beginPath(); ctx.arc(0, 0, R * 0.9, ang - k * 0.032, ang - (k - 1) * 0.032); ctx.stroke();
      }
    }

    ctx.strokeStyle = rgba(0.7); ctx.lineWidth = 1.5;
    for (let i = 0; i < 4; i++) {
      const a = (i * Math.PI) / 2;
      ctx.beginPath(); ctx.moveTo(Math.cos(a) * R * 1.4, Math.sin(a) * R * 1.4);
      ctx.lineTo(Math.cos(a) * R * 1.5, Math.sin(a) * R * 1.5); ctx.stroke();
    }

    const pulse = 0.5 + 0.5 * Math.sin(t * 0.0021);
    const cr = R * 0.33 * (1 + lvl * 0.14 + pulse * 0.025);
    g = ctx.createRadialGradient(0, 0, 0, 0, 0, cr * 1.6);
    g.addColorStop(0, 'rgba(255,255,255,0.98)');
    g.addColorStop(0.28, rgba(0.95));
    g.addColorStop(0.62, rgba(0.35 + lvl * 0.3));
    g.addColorStop(1, rgba(0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, cr * 1.6, 0, 7); ctx.fill();
    ctx.strokeStyle = rgba(0.9); ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(0, 0, cr * 1.02, 0, 7); ctx.stroke();

    ctx.restore();
    requestAnimationFrame(frame);
  }

  return {
    kind: '2d',
    layout,
    setState(s) { if (COL[s]) state = s; },
    setLevel(v) { target = v; },
    start() { requestAnimationFrame(frame); },
  };
}
