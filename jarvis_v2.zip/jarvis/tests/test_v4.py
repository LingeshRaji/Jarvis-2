"""Offline tests for the v4 changes: honest app launching, instant router, guard, mail/calendar, jobs, voices.
Run: python tests/test_v4.py"""
import os
import stat
import sys
import tempfile
import time
import types
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.modules.setdefault("sounddevice", types.SimpleNamespace(stop=lambda: None))
sys.modules.setdefault("soundfile", types.SimpleNamespace())

import config  # noqa: E402

TMP = Path(tempfile.mkdtemp())
for n in ("HOME", "NOTES_DIR", "REPORTS_DIR", "APPLICATIONS_DIR"):
    setattr(config, n, TMP / n); getattr(config, n).mkdir()
config.ACCOUNTS_FILE = config.HOME / "accounts.json"
config.JOBS_DB = config.HOME / "jobs.db"
config.PROFILE_FILE = config.HOME / "profile.json"
config.SETTINGS_FILE = config.HOME / "settings.json"
config.VOICES_DIR = config.HOME / "voices"
config.STATE_FILE = config.HOME / "state.json"
os.environ["DISPLAY"] = ":99"                    # pretend there is a screen

BIN = TMP / "bin"; BIN.mkdir()
os.environ["PATH"] = f"{BIN}:{os.environ['PATH']}"


def script(name, body):
    p = BIN / name
    p.write_text("#!/bin/sh\n" + body + "\n")
    p.chmod(p.stat().st_mode | stat.S_IEXEC)


import apps  # noqa: E402
import assistant as A  # noqa: E402
import briefing  # noqa: E402
import jobs  # noqa: E402
import mailcal  # noqa: E402
import router  # noqa: E402
import tools  # noqa: E402
import voices  # noqa: E402
from results import is_error  # noqa: E402

passed = 0


def ok(cond, name):
    global passed
    assert cond, f"FAILED: {name}"
    passed += 1
    print(f"  ok  {name}")


def run(plan, lang="en"):
    return plan.say([tools.call(n, a) for n, a in plan.calls], lang)


# ------------------------------------------------------------------ launching apps honestly
print("launching apps")
script("fakebrowser", "sleep 30")                      # a GUI app that stays open
script("crashapp", "echo 'cannot open display' >&2; exit 1")
script("handoff", "exit 0")                            # a launcher that exits 0 but starts nothing
apps.ALIASES["fakebrowser"] = ["fakebrowser"]
apps.ALIASES["crashapp"] = ["crashapp"]
apps.ALIASES["handoff"] = ["handoff"]
r = tools.call("open_app", {"name": "fakebrowser"})
ok(r.startswith("Opened") and apps.process_running({"fakebrowser"}), f"success only when it is running: {r}")
r = tools.call("open_app", {"name": "crashapp"})
ok(is_error(r) and "cannot open display" in r, f"a crashing app is reported as failed: {r}")
r = tools.call("open_app", {"name": "handoff"})
ok(is_error(r), f"exit code 0 with no process is NOT success: {r}")
ok(is_error(tools.call("open_app", {"name": "zzqxnotanapp"})), "unknown app is an error")
os.environ.pop("DISPLAY"); os.environ.pop("WAYLAND_DISPLAY", None)
real_clean = apps.clean_env
apps.clean_env = lambda: {k: v for k, v in real_clean().items() if k not in ("DISPLAY", "WAYLAND_DISPLAY")}
ok("display" in tools.call("open_app", {"name": "fakebrowser"}).lower(), "no display gives a clear reason")
apps.clean_env = real_clean
os.environ["DISPLAY"] = ":99"
os.environ["VIRTUAL_ENV"] = "/x/venv"; os.environ["PATH"] = "/x/venv/bin:" + os.environ["PATH"]
e = apps.clean_env()
ok("VIRTUAL_ENV" not in e and "/x/venv/bin" not in e["PATH"], "child apps do not inherit the virtualenv")
os.environ.pop("VIRTUAL_ENV")
# a .desktop entry is found by fuzzy name
d = TMP / "share" / "applications"; d.mkdir(parents=True)
(d / "org.mozilla.firefox.desktop").write_text("[Desktop Entry]\nType=Application\nName=Firefox Web Browser\nExec=fakebrowser %u\n")
os.environ["XDG_DATA_DIRS"] = str(TMP / "share"); os.environ["XDG_DATA_HOME"] = str(TMP / "none")
apps._index = None
ok(apps.resolve("fire fox web") is not None or apps.resolve("firefox") is not None, "finds apps from .desktop entries")
# closing
confirmed = []
r = apps.close_app("fakebrowser", lambda q: confirmed.append(q) or True)
ok(r.startswith("Closed") and confirmed and not apps.process_running({"fakebrowser"}), f"close is confirmed and verified: {r}")
ok(is_error(apps.close_app("fakebrowser", lambda q: True)), "closing something that is not running is an error")

# ------------------------------------------------------------------ run_shell
print("shell")
tools.confirm = lambda p: True
t0 = time.time()
ok(tools._gui_redirect("fakebrowser") == "fakebrowser" and tools._gui_redirect("ls -la") is None, "GUI programs typed into the shell are redirected to open_app")
ok(tools.run_shell("echo hi") == "hi", "simple command output")
ok(is_error(tools.run_shell("false")), "non-zero exit code is an error")
tools.SHELL_TIMEOUT = 1
t0 = time.time()
r = tools.run_shell("sleep 30 & wait")
ok(is_error(r) and "timed out" in r and time.time() - t0 < 6, f"a hanging command is killed, not waited for ({time.time()-t0:.1f}s)")
ok(tools.run_shell("nohup fakebrowser &") .startswith(("Opened", "Started")), "backgrounded GUI launch does not block")

# ------------------------------------------------------------------ router (no model needed)
print("router")
os.environ["PATH"] = os.environ["PATH"]
for text, name in [("open firefox", "open_app"), ("please open the terminal", "open_app"), ("what time is it", "time"),
                   ("volume up", None), ("set volume to 40", None), ("mute", None), ("take a screenshot", None),
                   ("open youtube", "open_url"), ("open downloads", "open_path"), ("hello", "greeting"),
                   ("thank you", "thanks"), ("பயர்பாக்ஸ் திற", "open_app"),
                   ("read the latest email", "read_mail"), ("give me my briefing", "briefing"), ("check my mail", "check_mail"),
                   ("any mail from the recruiter", "search_mail"), ("what's my next meeting", "next_event"),
                   ("find SOC analyst jobs in Chennai", "job_search"), ("show my applications", "job_list"), ("மணி என்ன", "time")]:
    p = router.route(text, "ta" if any("஀" <= c <= "௿" for c in text) else "en")
    ok(p is not None and (name is None or p.name == name), f"routes {text!r} -> {p.name if p else None}")
for text in ["explain how TCP works", "open firefox and then search for nmap cheat sheet", "write a poem about rain"]:
    ok(router.route(text, "en") is None, f"leaves {text!r} to the language model")
# honest wording from a real tool result
script("firefox", "sleep 30")
apps._index = None
reply = run(router.route("open firefox", "en"))
ok(reply.startswith("Opened") or "Firefox" in reply, f"success reply: {reply}")
script("firefox", "exit 3")
(d / "org.mozilla.firefox.desktop").unlink(); apps._index = None           # no other way to start it
reply = run(router.route("open firefox", "en"))
ok(not reply.lower().startswith("opened") and "ERROR" not in reply, f"failure reply is honest and clean: {reply}")
reply_ta = run(router.route("open firefox", "en"), "ta")
ok("திறக்க முடியவில்லை" in reply_ta, f"Tamil failure reply: {reply_ta}")

# ------------------------------------------------------------------ honesty guard
print("honesty guard")
ok(A.looks_like_action("open firefox and play some music") and not A.looks_like_action("why is the sky blue"), "detects action requests")
ok(A.claims_success("Opening Firefox now, sir.") and A.claims_success("Done, I've opened it.") and not A.claims_success("The capital of France is Paris."), "detects success claims")


class LyingClient:
    """Says 'Opening Firefox' without calling any tool, twice; then (after the nudge) calls the tool properly."""
    def __init__(self, fix_after_nudge):
        self.fix = fix_after_nudge; self.n = 0

    def chat(self, **kw):
        self.n += 1
        nudged = any("did not call" in (m.get("content") or "") for m in kw["messages"] if m.get("role") == "user")
        if nudged and self.fix:
            if any(m.get("role") == "tool" for m in kw["messages"]):
                return iter([{"message": {"content": "Firefox is open, sir."}}])
            return iter([{"message": {"content": "", "tool_calls": [{"function": {"name": "open_app", "arguments": {"name": "fakebrowser"}}}]}}])
        return iter([{"message": {"content": "Sure, opening Firefox for you now."}}])


class Sp:
    def __init__(self): self.said = []
    def say(self, t): self.said.append(t)
    def wait(self, t=None): pass
    def stop(self): self.said.append("<stop>")


for fix in (False, True):
    ev = []
    a = A.Assistant(lambda t, **d: ev.append((t, d)), voice_enabled=False)
    a.client = LyingClient(fix); a.speaker = Sp()
    a._run_turn("kindly get the web thing up on my screen and play something", "en")
    said = " ".join(a.speaker.said)
    if fix:
        ok(any(t == "tool" for t, _ in ev) and "Firefox is open" in said, "after the nudge the model really calls the tool")
    else:
        ok("opening firefox" not in said.lower() and a.history[-1]["content"], f"a false claim is never spoken: {a.speaker.said}")

# ------------------------------------------------------------------ tool subsetting
print("tool subsetting")
import json  # noqa: E402
full = len(json.dumps(tools.SCHEMAS))
small = len(json.dumps(tools.select_schemas("hello there")))
names = {s["function"]["name"] for s in tools.select_schemas("any new mail from the recruiter")}
ok(small < full * 0.4, f"prompt tools shrink from {full} to {small} bytes for a plain chat")
ok({"check_mail"} <= names or any("mail" in n for n in names), f"mail tools selected for a mail request: {sorted(n for n in names if 'mail' in n)}")
ok(not any(n.startswith("pentest") for n in names), "pentest tools are not sent for a mail request")

# ------------------------------------------------------------------ calendar
print("calendar")
ics = TMP / "cal.ics"
now = datetime.now().astimezone()
st = (now + timedelta(hours=2)).replace(minute=0, second=0, microsecond=0)
fmt = lambda d: d.strftime("%Y%m%dT%H%M%S")
ics.write_text("BEGIN:VCALENDAR\nVERSION:2.0\nBEGIN:VEVENT\nUID:1\nDTSTART;TZID=" + now.tzname() + ":" + fmt(st) + "\nSUMMARY:CEH revision\nEND:VEVENT\n"
               "BEGIN:VEVENT\nUID:2\nDTSTART;VALUE=DATE:" + now.strftime("%Y%m%d") + "\nSUMMARY:Pay rent\nEND:VEVENT\nEND:VCALENDAR\n")
mailcal.save_accounts({"calendars": [{"name": "Personal", "url": str(ics)}]})
ok(os.stat(config.ACCOUNTS_FILE).st_mode & 0o777 == 0o600, "accounts file is private (600)")
ok(mailcal.calendar_configured() and not mailcal.mail_configured(), "detects what is configured")
out = tools.call("calendar_events", {"day": "today"})
ok("Pay rent" in out, f"all-day event listed: {out}")
ok(is_error(tools.call("check_mail", {})), "mail without setup explains how to connect")
p = router.route("what's on my calendar today", "en")
ok(p is not None and p.name in ("calendar", "events"), f"calendar request is routed instantly ({p.name if p else None})")

# ------------------------------------------------------------------ jobs
print("jobs")
r = jobs.track("Acme", "SOC Analyst", "https://acme.example/jobs/1", "saved")
ok(not is_error(r) and "Acme" in r, f"track: {r}")
ok("Acme" in jobs.list_applications(), "tracked application is listed")
r = jobs.update("Acme", "applied", "sent CV")
ok("applied" in r.lower(), f"status update: {r}")
ok(is_error(jobs.update("Nobody", "applied")), "unknown application is an error")
r = tools.call("job_email_application", {"to": "hr@acme.example", "company": "Acme", "role": "SOC Analyst"})
ok(is_error(r), f"no application email without a profile / mail account: {r}")
ok(not (config.APPLICATIONS_DIR.glob("*") and any(p.suffix == ".sent" for p in config.APPLICATIONS_DIR.glob("*"))), "nothing was sent")

# ------------------------------------------------------------------ voices
print("voices")
en = [v for v in voices.CATALOG if v.lang == "en"]; ta = [v for v in voices.CATALOG if v.lang == "ta"]
ok(len(en) >= 5 and len(ta) >= 3, f"{len(en)} English and {len(ta)} Tamil voices to choose from")
ok(any(not v.online for v in ta) and any(not v.online for v in en), "each language has an offline voice")
voices.choose("en", en[1].id)
ok(voices.current("en").id == en[1].id and voices.load_settings()["voice_en"] == en[1].id, "choice is saved and reloaded")
ok(voices.current("ta").id == config.DEFAULT_VOICE_TA, "default Tamil voice before any choice")
try:
    voices.choose("en", "nope:nothing"); ok(False, "rejects unknown voice")
except Exception:
    ok(True, "rejects unknown voice")

print(f"\nAll {passed} v4 checks passed.")
