"""Voice I/O for Jarvis: wake word, two-stage speech-to-text (fast English model, accurate Tamil model), and a
streaming text-to-speech engine with selectable voices (see voices.py) that reports audio levels to the HUD."""
import asyncio
import inspect
import io
import os
import queue
import re
import subprocess
import sys
import tempfile
import threading
import time
import wave
from collections import OrderedDict

import numpy as np
import sounddevice as sd
import soundfile as sf

import config
import voices

# ----------------------------------------------------------------------------------------------
# Text helpers
# ----------------------------------------------------------------------------------------------
_EMOJI = re.compile("[\U00010000-\U0010ffff☀-➿️]")
_URL = re.compile(r"https?://\S+")


def is_tamil(ch: str) -> bool:
    return "஀" <= ch <= "௿"


def has_tamil(text: str) -> bool:
    return any(is_tamil(c) for c in text)


def clean_for_speech(text: str) -> str:
    text = re.sub(r"```.*?```", " ", text, flags=re.S)
    text = _URL.sub(" link ", text)
    text = _EMOJI.sub("", text)
    text = re.sub(r"[`*_#>|~]", "", text)
    text = re.sub(r"^\s*[-•]\s+", "", text, flags=re.M)
    return re.sub(r"\s+", " ", text).strip()


def script_runs(text: str) -> list[tuple[str, str]]:
    """Split text into consecutive ('ta'|'en', chunk) runs so each goes to the right voice."""
    runs, cur, cur_lang = [], "", None
    for ch in text:
        lang = "ta" if is_tamil(ch) else ("en" if ch.isalpha() else None)
        if lang and cur_lang and lang != cur_lang:
            if cur.strip():
                runs.append((cur_lang, cur))
            cur = ""
        if lang:
            cur_lang = lang
        cur += ch
    if cur.strip():
        runs.append((cur_lang or "en", cur))
    return runs


# ----------------------------------------------------------------------------------------------
# Speech in
# ----------------------------------------------------------------------------------------------
_whispers: dict = {}
_whisper_lock = threading.Lock()
_oww = None
_oww_failed = False


def _get_whisper(kind: str = "en"):
    """kind 'en' = small multilingual model (fast, also detects the language); 'ta' = large Tamil model (lazy)."""
    with _whisper_lock:
        if kind not in _whispers:
            from faster_whisper import WhisperModel
            name = config.WHISPER_MODEL_TA if kind == "ta" else config.WHISPER_MODEL_EN
            _whispers[kind] = WhisperModel(name, device=config.WHISPER_DEVICE, compute_type=config.WHISPER_COMPUTE,
                                           cpu_threads=config.WHISPER_THREADS or min(8, os.cpu_count() or 4))
        return _whispers[kind]


def _get_oww():
    global _oww, _oww_failed
    if _oww is None and not _oww_failed:
        try:
            import openwakeword
            from openwakeword.model import Model
            try:
                _oww = Model(wakeword_models=[config.WAKE_WORD], inference_framework="onnx")
            except Exception:
                openwakeword.utils.download_models([config.WAKE_WORD])
                _oww = Model(wakeword_models=[config.WAKE_WORD], inference_framework="onnx")
        except Exception as e:
            print(f"[voice] wake word unavailable ({e}); use the core / Space key instead.")
            _oww_failed = True
    return _oww


def wake_word_available() -> bool:
    return _get_oww() is not None


def wait_for_trigger(trigger: threading.Event, level_cb=None, stop: threading.Event | None = None) -> str | None:
    """Block until the wake word is heard ('wake'), `trigger` is set ('manual'), or `stop` is set (None)."""
    oww = _get_oww()
    if oww:
        oww.reset()
    with sd.InputStream(samplerate=config.SAMPLE_RATE, channels=1, dtype="int16", blocksize=1280) as stream:
        while True:
            if stop is not None and stop.is_set():
                return None
            frame, _ = stream.read(1280)
            mono = frame[:, 0]
            if level_cb:
                level_cb(min(1.0, float(np.sqrt(np.mean((mono / 32768.0) ** 2))) * 8))
            if trigger.is_set():
                trigger.clear()
                return "manual"
            if oww is not None:
                scores = oww.predict(mono)
                if scores and max(scores.values()) > 0.5:
                    return "wake"


def record_until_silence(level_cb=None, first_word_timeout: float = 7.0) -> np.ndarray:
    """Record one utterance; stops after a pause. Returns float32 mono audio at 16 kHz."""
    chunks, silent_for, started = [], 0.0, False
    t0 = time.time()
    block = int(config.SAMPLE_RATE * 0.1)
    with sd.InputStream(samplerate=config.SAMPLE_RATE, channels=1, dtype="float32", blocksize=block) as stream:
        while time.time() - t0 < config.MAX_RECORD_SECONDS:
            data, _ = stream.read(block)
            mono = data[:, 0]
            rms = float(np.sqrt(np.mean(mono ** 2)))
            if level_cb:
                level_cb(min(1.0, rms * 8))
            chunks.append(mono)
            if rms > config.SILENCE_RMS:
                started, silent_for = True, 0.0
            elif started:
                silent_for += 0.1
                if silent_for >= config.SILENCE_SECONDS:
                    break
            elif time.time() - t0 > first_word_timeout:
                break
    audio = np.concatenate(chunks) if chunks else np.zeros(1, dtype="float32")
    return audio if started else np.zeros(1, dtype="float32")


_COMMON = dict(vad_filter=True, beam_size=1, temperature=0.0, condition_on_previous_text=False,
               without_timestamps=True)


def _run(model, audio, language, prompt=None):
    segs, info = model.transcribe(audio, language=language, initial_prompt=prompt, **_COMMON)
    return " ".join(s.text.strip() for s in segs).strip(), info


def transcribe(audio: np.ndarray, mode: str | None = None) -> tuple[str, str]:
    """Return (text, language). Language is restricted to English/Tamil.

    English (and language detection) use the small model in a single pass. Only Tamil audio is re-run on the large
    Tamil model, so English commands stay fast.
    """
    if len(audio) < config.SAMPLE_RATE * 0.4:
        return "", "en"
    mode = mode or config.LANGUAGE_MODE
    if mode == "ta":
        return _run(_get_whisper("ta"), audio, "ta")[0], "ta"
    small = _get_whisper("en")
    if mode == "en":
        return _run(small, audio, "en", config.STT_PROMPT)[0], "en"
    # auto: one pass on the small model detects the language and (if English) already transcribes
    try:
        text, info = _run(small, audio, None, config.STT_PROMPT)
        probs = dict(getattr(info, "all_language_probs", None) or [])
        lang = "ta" if probs.get("ta", 0.0) > probs.get("en", 0.0) else "en"
        if not probs:
            lang = info.language if info.language in ("ta", "en") else "en"
    except Exception:
        text, lang, info = "", "en", None
    if lang == "ta":
        return _run(_get_whisper("ta"), audio, "ta")[0], "ta"
    if info is not None and info.language != "en":
        text = _run(small, audio, "en", config.STT_PROMPT)[0]     # detector heard noise as another language
    return text, "en"


def listen(level_cb=None, mode: str | None = None) -> tuple[str, str]:
    return transcribe(record_until_silence(level_cb), mode)


# ----------------------------------------------------------------------------------------------
# Speech out
# ----------------------------------------------------------------------------------------------
_mms = None
_mms_lock = threading.Lock()
_piper_voices: dict = {}
_piper_lock = threading.Lock()
_cache: OrderedDict = OrderedDict()
_CACHE_MAX = 96


def _piper_voice(v: voices.Voice):
    with _piper_lock:
        if v.id not in _piper_voices:
            voices.ensure(v)
            from piper import PiperVoice
            model, cfg = voices.piper_paths(v)
            _piper_voices[v.id] = PiperVoice.load(str(model), config_path=str(cfg))
        return _piper_voices[v.id]


def _synth_piper_cli(v: voices.Voice, text: str):
    model, _ = voices.piper_paths(v)
    with tempfile.NamedTemporaryFile(suffix=".wav") as f:
        subprocess.run([sys.executable, "-m", "piper", "-m", str(model), "-f", f.name],
                       input=text.encode(), capture_output=True, check=True)
        return sf.read(f.name, dtype="float32")


def _synth_piper(v: voices.Voice, text: str):
    """In-process Piper (no process start-up per sentence). Handles both the old and the new piper-tts API."""
    try:
        voice = _piper_voice(v)
        synth = voice.synthesize
        if "wav_file" in inspect.signature(synth).parameters:           # piper-tts 1.2 / 1.3
            buf = io.BytesIO()
            with wave.open(buf, "wb") as w:
                synth(text, w)
            buf.seek(0)
            return sf.read(buf, dtype="float32")
        chunks = list(synth(text))                                       # piper-tts 1.8+: AudioChunk objects
        if not chunks:
            return None
        return np.concatenate([c.audio_float_array for c in chunks]).astype("float32"), int(chunks[0].sample_rate)
    except Exception as e:
        print(f"[tts] in-process Piper failed ({e}); using the piper command instead")
        return _synth_piper_cli(v, text)


def _synth_mms(text: str):
    global _mms
    import torch
    from transformers import AutoTokenizer, VitsModel
    with _mms_lock:
        if _mms is None:
            _mms = (AutoTokenizer.from_pretrained("facebook/mms-tts-tam"),
                    VitsModel.from_pretrained("facebook/mms-tts-tam").eval())
    tok, model = _mms
    inputs = tok(text, return_tensors="pt")
    if inputs["input_ids"].shape[-1] == 0:
        return None
    with torch.no_grad():
        wav = model(**inputs).waveform[0].cpu().numpy().astype("float32")
    return wav, int(model.config.sampling_rate)


def _decode_audio(path: str):
    try:
        return sf.read(path, dtype="float32")
    except Exception:
        wav = path + ".wav"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", path, wav], check=True)
        return sf.read(wav, dtype="float32")


def _synth_edge(v: voices.Voice, text: str):
    import edge_tts

    async def run(path):
        await edge_tts.Communicate(text, v.name).save(path)

    with tempfile.NamedTemporaryFile(suffix=".mp3") as f:
        asyncio.run(asyncio.wait_for(run(f.name), 12))
        return _decode_audio(f.name)


def _synth_with(v: voices.Voice, text: str):
    if v.engine == "piper":
        return _synth_piper(v, text)
    if v.engine == "edge":
        return _synth_edge(v, text)
    return _synth_mms(text)


def synthesize(text: str, lang: str, voice_id: str | None = None):
    """Return (float32 audio, sample_rate) or None. Uses the chosen voice, falls back to the offline default."""
    v = voices.BY_ID.get(voice_id) if voice_id else voices.current(lang)
    key = (v.id, text)
    if len(text) <= 90 and key in _cache:
        _cache.move_to_end(key)
        return _cache[key]
    order = [v] + ([voices.BY_ID[voices.OFFLINE_FALLBACK[lang]]] if v.id != voices.OFFLINE_FALLBACK[lang] else [])
    for cand in order:
        try:
            audio = _synth_with(cand, text)
            if audio is not None and len(text) <= 90 and cand is v:
                _cache[key] = audio
                while len(_cache) > _CACHE_MAX:
                    _cache.popitem(last=False)
            return audio
        except Exception as e:
            print(f"[tts] {cand.id} failed ({str(e)[:120]})" + ("; using the offline voice" if cand is v and len(order) > 1 else ""))
    return None


def prewarm(progress=None) -> None:
    """Load every model Jarvis will need now, so the first real request is not slow. Safe to run in a thread."""
    def step(label, fn):
        try:
            fn()
        except Exception as e:
            print(f"[prewarm] {label}: {str(e)[:120]}")
        else:
            if progress:
                progress(label)
    step("speech recognition", lambda: _get_whisper("en").transcribe(np.zeros(8000, dtype="float32"), language="en"))
    for lang, phrase in (("en", "Ready."), ("ta", "தயார்.")):
        v = voices.current(lang)
        if v.engine != "edge":
            step(f"{lang} voice", lambda: synthesize(phrase, lang))
    if config.PREWARM_TAMIL_STT and config.LANGUAGE_MODE != "en":
        step("Tamil recognition", lambda: _get_whisper("ta"))


class Speaker:
    """Queue-based speaker: say() returns immediately, audio is synthesised and played in the background.
    level_cb(0..1) is called ~20x/second during playback so the HUD can animate. on_play() fires when the first
    sound of an utterance starts (used for the latency read-out)."""

    def __init__(self, level_cb=None, on_play=None):
        self.level_cb = level_cb
        self.on_play = on_play
        self._synth_q: queue.Queue = queue.Queue()
        self._play_q: queue.Queue = queue.Queue()
        self._cv = threading.Condition()
        self._pending = 0
        self._gen = 0
        threading.Thread(target=self._synth_loop, daemon=True).start()
        threading.Thread(target=self._play_loop, daemon=True).start()

    # -- public ---------------------------------------------------------------------------
    def say(self, text: str, voice_override: dict | None = None) -> None:
        """voice_override = {"en": voice_id, "ta": voice_id} is used by the voice preview."""
        text = clean_for_speech(text)
        if not text:
            return
        with self._cv:
            self._pending += 1
        self._synth_q.put((self._gen, text, voice_override or {}))

    def wait(self, timeout: float | None = None) -> None:
        with self._cv:
            self._cv.wait_for(lambda: self._pending == 0, timeout)

    def stop(self) -> None:
        with self._cv:
            self._gen += 1
        try:
            sd.stop()
        except Exception:
            pass

    @property
    def busy(self) -> bool:
        return self._pending > 0

    # -- internals ------------------------------------------------------------------------
    def _finish(self) -> None:
        with self._cv:
            self._pending = max(0, self._pending - 1)
            if self._pending == 0:
                self._cv.notify_all()

    def _synth_loop(self) -> None:
        while True:
            gen, text, override = self._synth_q.get()
            if gen != self._gen:
                self._finish()
                continue
            parts = []
            for lang, chunk in script_runs(text):
                if gen != self._gen:
                    break
                if not any(c.isalnum() for c in chunk):
                    continue
                audio = synthesize(chunk.strip(), lang, override.get(lang))
                if audio is not None:
                    parts.append(audio)
            if parts and gen == self._gen:
                self._play_q.put((gen, parts))
            else:
                self._finish()

    def _play_loop(self) -> None:
        while True:
            gen, parts = self._play_q.get()
            first = True
            try:
                for data, sr in parts:
                    if gen != self._gen:
                        break
                    if data.ndim > 1:
                        data = data.mean(axis=1)
                    with sd.OutputStream(samplerate=sr, channels=1, dtype="float32") as out:
                        step = max(512, sr // 20)
                        for i in range(0, len(data), step):
                            if gen != self._gen:
                                break
                            if first and self.on_play:
                                first = False
                                try:
                                    self.on_play()
                                except Exception:
                                    pass
                            seg = data[i:i + step]
                            out.write(seg.reshape(-1, 1))
                            if self.level_cb:
                                self.level_cb(min(1.0, float(np.sqrt(np.mean(seg ** 2))) * 5))
            except Exception as e:
                print(f"[audio] playback error: {e}")
            finally:
                if self.level_cb:
                    self.level_cb(0.0)
                self._finish()
