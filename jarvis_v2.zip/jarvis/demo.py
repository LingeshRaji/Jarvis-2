"""Demo assistant: same interface as Assistant but needs no Ollama, microphone or speakers.
Run `python jarvis.py --demo` to preview the HUD."""
import math
import random
import threading
import time

import config
import voices


class DemoAssistant:
    voice_enabled = True

    def __init__(self, emit):
        self.emit = emit
        self.mode = "auto"
        self.state = "idle"
        self.tts_enabled = True
        self.mic_enabled = True
        self._confirms: dict[str, threading.Event] = {}
        self._busy = threading.Lock()

    def start(self):
        self.emit("status", text="Demo mode: no models loaded", ok=True)
        threading.Thread(target=lambda: (time.sleep(1), self._reply("Good evening, sir. All systems online. This is demo mode.")), daemon=True).start()

    def shutdown(self):
        pass

    def set_state(self, s):
        self.state = s
        self.emit("state", state=s)

    def set_mode(self, m):
        self.mode = m
        self.emit("mode", mode=m)

    def stop(self):
        pass

    def _levels(self, seconds, src):
        t0 = time.time()
        while time.time() - t0 < seconds:
            t = time.time() - t0
            v = max(0.0, min(1.0, 0.35 + 0.35 * math.sin(t * 7) + random.random() * 0.3))
            self.emit("level", value=v, src=src)
            time.sleep(0.06)
        self.emit("level", value=0.0, src=src)

    def _reply(self, text):
        self.set_state("speaking")
        threading.Thread(target=self._levels, args=(len(text) * 0.045, "voice"), daemon=True).start()
        for w in text.split(" "):
            self.emit("token", text=w + " ")
            time.sleep(0.04)
        self.emit("reply_end", text=text)
        time.sleep(max(0, len(text) * 0.045 - len(text.split()) * 0.04))
        self.set_state("idle")

    def request_listen(self):
        def run():
            self.set_state("listening")
            self._levels(2.0, "mic")
            self.set_state("thinking")
            time.sleep(0.8)
            self.emit("user", text="What's the status of my system?", lang="en")
            self._turn("system")
        threading.Thread(target=run, daemon=True).start()

    def submit_text(self, text, lang=None, meta=None):
        lang = lang or ("ta" if any("஀" <= c <= "௿" for c in text) else "en")
        self.emit("user", text=text, lang=lang)
        threading.Thread(target=self._turn, args=(text, lang), daemon=True).start()

    def _turn(self, text, lang="en"):
        self.set_state("thinking")
        time.sleep(0.7)
        if "scan" in text.lower():
            self.set_state("tool")
            self.emit("tool", name="pentest_scan", args={"tool": "nmap_quick", "target": "192.168.56.101"})
            cid = "demo"
            ev = self._confirms[cid] = threading.Event()
            self.emit("confirm", id=cid, prompt="Confirm you are authorised to test 192.168.56.101?")
            ev.wait(30)
            self.emit("tool_result", name="pentest_scan", result="Started scan s1 (nmap_quick).")
            self._reply("Scan started, sir. I'll tell you when it finishes.")
            return
        if lang == "ta" or any("஀" <= c <= "௿" for c in text):
            self._reply("வணக்கம் ஐயா. உங்கள் கணினி சீராக இயங்குகிறது. செயலி பத்து சதவீதம் மட்டுமே.")
            return
        if not any(w in text.lower() for w in ("status", "system", "cpu", "ram", "memory")) and text != "What's the status of my system?":
            self._reply("This is demo mode, sir: I only have canned replies here. Run Jarvis without the demo flag for real answers.")
            return
        self.set_state("tool")
        self.emit("tool", name="system_status", args={})
        time.sleep(0.5)
        self.emit("tool_result", name="system_status", result="CPU 12%, RAM 41%")
        self._reply("Everything is running smoothly, sir. CPU is at twelve percent and memory at forty-one.")

    # voice picker works in the demo too (no audio, no downloads)
    def get_voices(self):
        return voices.listing()

    def set_voice(self, lang, vid):
        try:
            voices.choose(lang, vid)
        except ValueError as e:
            self.emit("status", text=str(e), ok=False)
            return
        self.emit("voice_changed", lang=lang, id=vid)
        self.emit("status", text=f"Voice: {voices.BY_ID[vid].label} (demo: no audio)", ok=True)

    def preview_voice(self, lang, vid):
        self.emit("notice", text="Demo mode has no audio. Run without --demo to hear the voice.")

    def resolve_confirm(self, cid, ok):
        ev = self._confirms.get(cid)
        if ev:
            ev.set()
            self.emit("confirm_done", id=cid, ok=ok)
