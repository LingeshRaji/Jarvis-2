"""One convention for tool results: failures start with "ERROR: ".

The router and the language model both rely on it, so Jarvis only ever reports success when a tool really succeeded.
"""

ERR = "ERROR: "


def fail(message: str) -> str:
    return ERR + message


def is_error(result: str) -> bool:
    return str(result).startswith(ERR)


def reason(result: str) -> str:
    """The human-readable part of a result, without the ERROR marker."""
    result = str(result)
    return result[len(ERR):] if result.startswith(ERR) else result
