"""Mail and calendar for Jarvis.

Mail     IMAP, read-only (messages are fetched with PEEK, so they are not marked as read). Works with Gmail through an
         "app password". Sending uses SMTP and always asks for confirmation first.
Calendar Any calendar that can give you a private .ics link (Google Calendar: Settings > your calendar >
         "Secret address in iCal format"), or a local .ics file. Recurring events are expanded correctly.
Nothing here ever leaves your machine except the connection to your own mail server / calendar link.
Credentials are kept in ~/.jarvis/accounts.json (permissions 600); run `python jarvis.py --setup-accounts`.
"""
import email
import email.policy
import hashlib
import imaplib
import json
import mimetypes
import os
import re
import smtplib
import ssl
import time
import urllib.request
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from email.header import decode_header, make_header
from email.message import EmailMessage
from email.utils import parseaddr
from pathlib import Path

import config
from results import fail
from router import ta_num, ta_period

SETUP_HINT = "Run 'python jarvis.py --setup-accounts' once to connect it."


# ----------------------------------------------------------------------------------------- accounts
def load_accounts() -> dict:
    try:
        return json.loads(config.ACCOUNTS_FILE.read_text())
    except (OSError, ValueError):
        return {}


def save_accounts(data: dict) -> None:
    tmp = config.ACCOUNTS_FILE.with_suffix(".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, config.ACCOUNTS_FILE)
    os.chmod(config.ACCOUNTS_FILE, 0o600)
    _mail_cache.clear()


def mail_configured() -> bool:
    m = load_accounts().get("email") or {}
    return bool(m.get("address") and m.get("password"))


def calendar_configured() -> bool:
    return bool(load_accounts().get("calendars"))


# ----------------------------------------------------------------------------------------- mail
@dataclass
class Mail:
    sender: str
    subject: str
    date: str
    uid: str = ""


def _hdr(value) -> str:
    try:
        return str(make_header(decode_header(value or ""))).strip()
    except Exception:
        return str(value or "")


def _who(raw: str) -> str:
    name, addr = parseaddr(_hdr(raw))
    return (name or addr.split("@")[0] or "someone").strip().strip('"')


def _imap() -> imaplib.IMAP4_SSL:
    cfg = load_accounts().get("email") or {}
    if not cfg.get("address") or not cfg.get("password"):
        raise RuntimeError("Mail is not set up. " + SETUP_HINT)
    host = cfg.get("imap_host", "imap.gmail.com")
    M = imaplib.IMAP4_SSL(host, timeout=15)
    try:
        M.login(cfg["address"], cfg["password"])
    except imaplib.IMAP4.error as e:
        raise RuntimeError("The mail server rejected the login. For Gmail you need an app password, not your normal "
                           f"password ({str(e)[:60]}).") from e
    return M


def _header_fetch(M, ids, limit):
    out = []
    for i in list(reversed(ids))[:limit]:
        typ, data = M.fetch(i, "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
        if typ != "OK" or not data or not isinstance(data[0], tuple):
            continue
        msg = email.message_from_bytes(data[0][1])
        out.append(Mail(_who(msg.get("From")), _hdr(msg.get("Subject")) or "(no subject)", msg.get("Date", ""),
                        i.decode() if isinstance(i, bytes) else str(i)))
    return out


_mail_cache: dict = {}


def unread(limit: int = 5) -> tuple[int, list[Mail]]:
    """(total unread in the inbox, newest `limit` unread messages). Cached for 45 s so repeats are instant."""
    hit = _mail_cache.get(limit)
    if hit and time.time() - hit[0] < 45:
        return hit[1]
    M = _imap()
    try:
        M.select("INBOX", readonly=True)
        typ, data = M.search(None, "UNSEEN")
        ids = data[0].split() if typ == "OK" and data and data[0] else []
        result = (len(ids), _header_fetch(M, ids, limit))
    finally:
        try:
            M.logout()
        except Exception:
            pass
    _mail_cache[limit] = (time.time(), result)
    return result


def search(query: str, limit: int = 5) -> list[Mail]:
    """Search the inbox. For Gmail the query may use Gmail syntax (from:amazon, newer_than:2d, is:unread)."""
    M = _imap()
    try:
        M.select("INBOX", readonly=True)
        gmail = "gmail" in (load_accounts().get("email") or {}).get("imap_host", "imap.gmail.com")
        q = query.replace('"', "")
        if gmail and q.isascii():
            typ, data = M.search(None, "X-GM-RAW", f'"{q}"')
        elif q.isascii():
            typ, data = M.search(None, "OR", "FROM", f'"{q}"', "SUBJECT", f'"{q}"')
        else:
            typ, data = "OK", [b""]
        ids = data[0].split() if typ == "OK" and data and data[0] else []
        return _header_fetch(M, ids, limit)
    finally:
        try:
            M.logout()
        except Exception:
            pass


def _body_text(msg) -> str:
    part = msg.get_body(preferencelist=("plain", "html"))
    if part is None:
        return ""
    text = part.get_content()
    if part.get_content_type() == "text/html":
        text = re.sub(r"(?is)<(script|style).*?</\1>", " ", text)
        text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def read(query: str = "", max_chars: int = 1200) -> str:
    """Body of the newest message matching `query` (empty = newest unread). Does not mark it as read."""
    M = _imap()
    try:
        M.select("INBOX", readonly=True)
        if query.strip():
            q = query.replace('"', "")
            typ, data = (M.search(None, "X-GM-RAW", f'"{q}"') if q.isascii() and
                         "gmail" in (load_accounts().get("email") or {}).get("imap_host", "imap.gmail.com")
                         else M.search(None, "OR", "FROM", f'"{q}"', "SUBJECT", f'"{q}"'))
        else:
            typ, data = M.search(None, "UNSEEN")
        ids = data[0].split() if typ == "OK" and data and data[0] else []
        if not ids:
            return fail("I couldn't find a matching email.")
        typ, data = M.fetch(ids[-1], "(BODY.PEEK[])")
        msg = email.message_from_bytes(data[0][1], policy=email.policy.default)
        body = _body_text(msg)[:max_chars] or "(no readable text)"
        return f"From {_who(msg.get('From'))}. Subject: {_hdr(msg.get('Subject'))}. {body}"
    finally:
        try:
            M.logout()
        except Exception:
            pass


def send(to: str, subject: str, body: str, attachments: list[str] | None = None, confirm=None) -> str:
    cfg = load_accounts().get("email") or {}
    if not cfg.get("address") or not cfg.get("password"):
        return fail("Mail is not set up. " + SETUP_HINT)
    if not re.fullmatch(r"[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+", to.strip()):
        return fail(f"'{to}' doesn't look like a single email address.")
    files = []
    for a in attachments or []:
        p = Path(a).expanduser()
        if not p.is_file():
            return fail(f"Attachment not found: {a}")
        files.append(p)
    desc = f"Send an email to {to.strip()} with the subject '{subject}'" + (f" and {len(files)} attachment(s)" if files else "") + "?"
    if confirm is None or not confirm(desc):
        return fail("Cancelled, nothing was sent.")
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = cfg["address"], to.strip(), subject
    msg.set_content(body)
    for p in files:
        ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        msg.add_attachment(p.read_bytes(), maintype=ctype.split("/")[0], subtype=ctype.split("/")[1], filename=p.name)
    try:
        with smtplib.SMTP_SSL(cfg.get("smtp_host", "smtp.gmail.com"), 465, timeout=20,
                              context=ssl.create_default_context()) as s:
            s.login(cfg["address"], cfg["password"])
            s.send_message(msg)
    except Exception as e:
        return fail(f"Sending failed: {str(e)[:120]}")
    return f"Email sent to {to.strip()}."


def _short(s: str, n: int = 70) -> str:
    s = re.sub(r"\s+", " ", s).strip()
    return s if len(s) <= n else s[:n].rsplit(" ", 1)[0] + "…"


def unread_summary(limit: int = 3, lang: str = "en") -> str:
    try:
        total, mails = unread(max(limit, 3))
    except Exception as e:
        return fail(str(e)[:160])
    mails = mails[:limit]
    if total == 0:
        return "உங்களுக்கு புதிய மின்னஞ்சல்கள் இல்லை ஐயா." if lang == "ta" else "You have no unread emails, sir."
    if lang == "ta":
        head = f"உங்களுக்கு {ta_num(total) if total <= 100 else total} படிக்காத மின்னஞ்சல்கள் உள்ளன."
        return head + " " + " ".join(f"{m.sender} இடமிருந்து: {_short(m.subject)}." for m in mails)
    head = f"You have {total} unread email{'s' if total != 1 else ''}."
    items = " ".join(f"From {m.sender}: {_short(m.subject)}." for m in mails)
    return f"{head} {items}".strip()


def search_summary(query: str, limit: int = 3) -> str:
    try:
        mails = search(query, limit)
    except Exception as e:
        return fail(str(e)[:160])
    if not mails:
        return f"No emails found for {query}."
    return f"Found {len(mails)}: " + " ".join(f"From {m.sender}: {_short(m.subject)}." for m in mails)


# ----------------------------------------------------------------------------------------- calendar
def _cache_path(url: str) -> Path:
    d = config.HOME / "cal_cache"
    d.mkdir(exist_ok=True)
    return d / (hashlib.sha1(url.encode()).hexdigest()[:16] + ".ics")


def _load_ics(url: str, max_age: int = 600) -> bytes:
    """Calendar data from a link or file. Recent copy is reused; when offline the last copy is used."""
    if not re.match(r"^https?://", url):
        return Path(url).expanduser().read_bytes()
    cache = _cache_path(url)
    if cache.exists() and time.time() - cache.stat().st_mtime < max_age:
        return cache.read_bytes()
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Jarvis"}), timeout=10) as r:
            data = r.read()
        cache.write_bytes(data)
        return data
    except Exception:
        if cache.exists():
            return cache.read_bytes()                   # offline: the last copy is better than nothing
        raise


@dataclass
class Event:
    title: str
    start: datetime
    end: datetime
    all_day: bool
    location: str = ""
    calendar: str = ""


def _local(dt) -> tuple[datetime, bool]:
    tz = datetime.now().astimezone().tzinfo
    if isinstance(dt, datetime):
        return (dt.replace(tzinfo=tz) if dt.tzinfo is None else dt.astimezone(tz)), False
    return datetime.combine(dt, datetime.min.time()).replace(tzinfo=tz), True


def events_between(start: datetime, end: datetime) -> list[Event]:
    import icalendar
    import recurring_ical_events
    out: list[Event] = []
    for c in load_accounts().get("calendars", []):
        cal = icalendar.Calendar.from_ical(_load_ics(c["url"]))
        for comp in recurring_ical_events.of(cal).between(start, end):
            if str(comp.get("STATUS", "")).upper() == "CANCELLED" or "DTSTART" not in comp:
                continue
            s, all_day = _local(comp["DTSTART"].dt)
            e = _local(comp["DTEND"].dt)[0] if "DTEND" in comp else s
            out.append(Event(str(comp.get("SUMMARY", "(no title)")).strip(), s, e, all_day,
                             str(comp.get("LOCATION", "")).strip(), c.get("name", "")))
    out.sort(key=lambda ev: (not ev.all_day, ev.start))
    # an event that ended exactly at midnight belongs to the previous day
    return [ev for ev in out if ev.end > start or ev.start >= start]


_WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
_TA_WEEKDAYS = {"திங்கள்": 0, "செவ்வாய்": 1, "புதன்": 2, "வியாழன்": 3, "வெள்ளி": 4, "சனி": 5, "ஞாயிறு": 6}


def parse_day(text: str) -> tuple[datetime, datetime, str]:
    """('today' | 'tomorrow' | 'week' | weekday name | YYYY-MM-DD) -> (start, end, label)."""
    t = (text or "today").strip().lower()
    now = datetime.now().astimezone()
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if t in ("today", "", "இன்று"):
        return midnight, midnight + timedelta(days=1), "today"
    if t in ("tomorrow", "நாளை"):
        return midnight + timedelta(days=1), midnight + timedelta(days=2), "tomorrow"
    if t in ("week", "this week", "next 7 days", "the week", "இந்த வாரம்"):
        return midnight, midnight + timedelta(days=7), "week"
    wd = _WEEKDAYS.index(t) if t in _WEEKDAYS else _TA_WEEKDAYS.get(t.replace("கிழமை", "").strip())
    if wd is not None:
        d = midnight + timedelta(days=(wd - midnight.weekday()) % 7 or 7)
        return d, d + timedelta(days=1), "on " + d.strftime("%A")
    try:
        d = datetime.strptime(t, "%Y-%m-%d").astimezone()
        return d, d + timedelta(days=1), "on " + d.strftime("%A %-d %B")
    except ValueError:
        return midnight, midnight + timedelta(days=1), "today"


def say_time(dt: datetime, lang: str = "en") -> str:
    if lang == "ta":
        h = dt.hour % 12 or 12
        return f"{ta_period(dt.hour)} {ta_num(h)} மணி" + (f" {ta_num(dt.minute)} நிமிடம்" if dt.minute else "")
    return dt.strftime("%-I:%M %p").replace(":00", "")


def events_summary(day: str = "today", lang: str = "en") -> str:
    if not calendar_configured():
        return fail("Your calendar is not connected. " + SETUP_HINT)
    start, end, label = parse_day(day)
    try:
        evs = events_between(start, end)
    except Exception as e:
        return fail(f"I couldn't read the calendar: {str(e)[:120]}")
    multi = (end - start).days > 1
    en_label = {"week": "over the next seven days"}.get(label, label)
    ta_label = {"today": "இன்று", "tomorrow": "நாளை", "week": "அடுத்த ஏழு நாட்களில்"}.get(label, label)
    if not evs:
        if lang == "ta":
            return f"{ta_label} எந்த நிகழ்வும் இல்லை ஐயா."
        return "Your calendar is clear today, sir." if label == "today" else f"Nothing on your calendar {en_label}, sir."
    n = len(evs)
    parts = []
    for ev in evs[:8]:
        when = ("நாள் முழுவதும்" if lang == "ta" else "all day") if ev.all_day else say_time(ev.start, lang)
        if multi:
            when = f"{ev.start.strftime('%A')} {when}"
        parts.append(f"{when}: {_short(ev.title, 60)}")
    if lang == "ta":
        return f"{ta_label} {ta_num(n) if n <= 100 else n} நிகழ்வுகள் உள்ளன. " + ". ".join(parts) + "."
    more = f" and {n - 8} more" if n > 8 else ""
    return f"You have {n} event{'s' if n != 1 else ''} {en_label}. " + ". ".join(parts) + more + "."


def next_event_summary(lang: str = "en") -> str:
    if not calendar_configured():
        return fail("Your calendar is not connected. " + SETUP_HINT)
    now = datetime.now().astimezone()
    try:
        evs = [e for e in events_between(now, now + timedelta(days=7)) if not e.all_day and e.start >= now]
    except Exception as e:
        return fail(f"I couldn't read the calendar: {str(e)[:120]}")
    if not evs:
        return "அடுத்த ஏழு நாட்களில் எதுவும் இல்லை ஐயா." if lang == "ta" else "Nothing coming up in the next seven days, sir."
    ev = evs[0]
    mins = int((ev.start - now).total_seconds() // 60)
    if lang == "ta":
        return f"அடுத்தது {_short(ev.title, 60)}, {say_time(ev.start, 'ta')}."
    delta = f"in {mins} minutes" if mins < 90 else ("today at " + say_time(ev.start) if ev.start.date() == now.date()
                                                     else f"{ev.start.strftime('%A')} at {say_time(ev.start)}")
    return f"Your next event is {_short(ev.title, 60)}, {delta}."


# ----------------------------------------------------------------------------------------- setup wizard
def setup_accounts() -> None:
    """Interactive one-time setup. Secrets are typed here (hidden), never spoken or sent to the language model."""
    import getpass
    data = load_accounts()
    print("\n== Mail (Gmail) ==")
    print("Gmail needs an app password: Google Account > Security > 2-Step Verification > App passwords.")
    print("(Leave the address empty to skip mail.)")
    addr = input(f"Email address [{(data.get('email') or {}).get('address', '')}]: ").strip() or (data.get("email") or {}).get("address", "")
    if addr:
        pw = getpass.getpass("App password (hidden; blank keeps the saved one): ").replace(" ", "")
        cfg = {"address": addr, "password": pw or (data.get("email") or {}).get("password", ""),
               "imap_host": "imap.gmail.com", "smtp_host": "smtp.gmail.com"}
        if not addr.endswith(("@gmail.com", "@googlemail.com")):
            cfg["imap_host"] = input("IMAP server (e.g. imap.outlook.com): ").strip() or cfg["imap_host"]
            cfg["smtp_host"] = input("SMTP server (e.g. smtp.office365.com): ").strip() or cfg["smtp_host"]
        data["email"] = cfg
        save_accounts(data)
        try:
            total, _ = unread(1)
            print(f"   Connected. {total} unread messages.")
        except Exception as e:
            print(f"   Could not log in: {e}")
    print("\n== Calendar ==")
    print("Google Calendar: Settings > click your calendar > 'Secret address in iCal format' > copy the link.")
    print("You can also give the path to an .ics file. Leave empty to finish.")
    cals = data.get("calendars", [])
    while True:
        url = input("Calendar link or .ics path: ").strip()
        if not url:
            break
        name = input("  Name for it [Calendar]: ").strip() or "Calendar"
        cals.append({"name": name, "url": url})
        data["calendars"] = cals
        save_accounts(data)
        try:
            n = len(events_between(datetime.now().astimezone(), datetime.now().astimezone() + timedelta(days=7)))
            print(f"   OK. {n} events in the next 7 days.")
        except Exception as e:
            print(f"   Saved, but I couldn't read it yet: {e}")
    print(f"\nSaved to {config.ACCOUNTS_FILE} (readable only by you).")
