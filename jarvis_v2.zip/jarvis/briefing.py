"""The daily briefing: date, weather (optional), calendar, unread mail and job follow-ups in one short spoken summary.
Each part is optional: anything that is not set up is skipped instead of being reported as an error."""
import json
import threading
from datetime import datetime

import config
import jobs
import mailcal
from results import is_error
from router import ta_num, _TA_DAYS, _TA_MONTHS


def _part(fn, *a):
    out: list = []
    t = threading.Thread(target=lambda: out.append(fn(*a)), daemon=True)
    t.start()
    t.join(12)
    return out[0] if out else ""


def build(lang: str = "en") -> str:
    now = datetime.now()
    h = now.hour
    parts = []
    if lang == "ta":
        greet = "காலை வணக்கம்" if h < 12 else "மதிய வணக்கம்" if h < 17 else "மாலை வணக்கம்"
        parts.append(f"{greet} ஐயா. இன்று {_TA_DAYS[now.weekday()]}, {_TA_MONTHS[now.month - 1]} {ta_num(now.day)}.")
    else:
        part = "morning" if h < 12 else "afternoon" if h < 17 else "evening"
        parts.append(f"Good {part}, sir. It's {now.strftime('%A, %-d %B')}.")

    if config.WEATHER_CITY:
        import tools
        w = _part(tools.get_weather, config.WEATHER_CITY)
        if w and not is_error(w):
            parts.append(w.replace("°C", " degrees").replace("+", "") + ".")
    if mailcal.calendar_configured():
        c = _part(mailcal.events_summary, "today", lang)
        if c and not is_error(c):
            parts.append(c)
    if mailcal.mail_configured():
        m = _part(mailcal.unread_summary, 3, lang)
        if m and not is_error(m):
            parts.append(m)
    due = jobs.due_followups() if config.JOBS_DB.exists() else []
    if due and lang != "ta":
        parts.append(f"{len(due)} job application follow-up{'s' if len(due) != 1 else ''} due: "
                     + ", ".join(f"{r['role']} at {r['company']}" for r in due[:3]) + ".")
    elif due:
        parts.append(f"{ta_num(len(due))} வேலை விண்ணப்ப பின்தொடர்தல்கள் உள்ளன.")
    return " ".join(parts)


# once-a-day marker for the automatic start-up briefing
def due_today() -> bool:
    try:
        return json.loads(config.STATE_FILE.read_text()).get("briefing") != datetime.now().date().isoformat()
    except (OSError, ValueError):
        return True


def mark_done() -> None:
    try:
        state = json.loads(config.STATE_FILE.read_text())
    except (OSError, ValueError):
        state = {}
    state["briefing"] = datetime.now().date().isoformat()
    config.STATE_FILE.write_text(json.dumps(state))


def configured() -> bool:
    return mailcal.mail_configured() or mailcal.calendar_configured()
