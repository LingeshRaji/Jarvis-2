#!/usr/bin/env python3
"""J.A.R.V.I.S. launcher.

  python jarvis.py            # desktop app: HUD window + voice (Tamil / English)
  python jarvis.py --cli      # terminal text mode
  python jarvis.py --demo     # preview the HUD without models, mic or speakers
  python jarvis.py --no-voice # HUD + typing only (no microphone / speakers)
  python jarvis.py --voices   # list / choose English and Tamil voices from the terminal
  python jarvis.py --setup-accounts   # connect Gmail and your calendar (secrets stay on this computer)
  python jarvis.py --setup-jobs       # your details for cover letters and job applications
"""
import argparse
import shutil
import socket
import subprocess
import threading
import time
import webbrowser

import config

BROWSERS = ["chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "brave-browser", "brave",
            "microsoft-edge"]


def port_open(host: str, port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex((host, port)) == 0


def open_window(url: str) -> None:
    """Show the HUD in its own window. Returns when the window is closed."""
    try:
        import webview  # optional: pip install pywebview (needs GTK or Qt WebEngine)
        webview.create_window("J.A.R.V.I.S.", url, width=1360, height=840, background_color="#02070b")
        webview.start()
        return
    except Exception:
        pass
    for b in BROWSERS:
        exe = shutil.which(b)
        if exe:
            profile = config.HOME / "browser-profile"
            subprocess.run([exe, f"--app={url}", f"--user-data-dir={profile}", "--window-size=1360,840",
                            "--no-first-run", "--disable-features=Translate", "--class=Jarvis"])
            return
    print(f"No app-capable browser found; opening {url} in your default browser. Press Ctrl+C to quit.")
    webbrowser.open(url)
    while True:
        time.sleep(3600)


def run_gui(args) -> None:
    import uvicorn
    import server

    url = f"http://{config.UI_HOST}:{config.UI_PORT}"
    srv = None
    if port_open(config.UI_HOST, config.UI_PORT):
        print("Jarvis is already running; opening a new window.")
    else:
        app = server.create_app(demo=args.demo, voice=not args.no_voice and not args.demo)
        srv = uvicorn.Server(uvicorn.Config(app, host=config.UI_HOST, port=config.UI_PORT, log_level="warning"))
        threading.Thread(target=srv.run, daemon=True).start()
        while not srv.started:
            time.sleep(0.1)
    try:
        if args.no_window:
            print(f"HUD at {url}  (Ctrl+C to quit)")
            while True:
                time.sleep(3600)
        open_window(url)
    except KeyboardInterrupt:
        pass
    finally:
        if srv:
            srv.should_exit = True
            time.sleep(0.5)


def run_cli() -> None:
    import assistant as A
    import tools

    def emit(t, **d):
        if t == "token":
            print(d["text"], end="", flush=True)
        elif t == "reply_end":
            print()
        elif t == "tool":
            print(f"\n  [tool] {d['name']}({d['args']})")
        elif t in ("status", "notice"):
            print(f"  [{t}] {d['text']}")

    a = A.Assistant(emit, voice_enabled=False)
    tools.confirm = lambda p: input(f"{p} [y/N] ").strip().lower() == "y"
    a.start()
    print("JARVIS terminal mode. Type 'exit' to quit.")
    while True:
        try:
            text = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if text.lower() in {"exit", "quit"}:
            break
        if text:
            a.submit_text(text)
            time.sleep(0.2)
            a.idle.wait()


def choose_voices() -> None:
    import voices
    for lang, title in (("en", "English"), ("ta", "Tamil")):
        cur = voices.current(lang).id
        opts = [v for v in voices.CATALOG if v.lang == lang]
        print(f"\n{title} voices (current: {cur})")
        for i, v in enumerate(opts, 1):
            mark = "*" if v.id == cur else " "
            print(f" {mark}{i:2}. {v.label:46} {'online ' if v.online else 'offline'}  {v.note}")
        pick = input(f"Number for {title} (Enter keeps current): ").strip()
        if pick.isdigit() and 1 <= int(pick) <= len(opts):
            v = opts[int(pick) - 1]
            try:
                voices.ensure(v, progress=print)
                voices.choose(lang, v.id)
                print(f"  {title} voice set to {v.label}")
            except Exception as e:
                print(f"  Could not set it ({e}). Are you online?")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cli", action="store_true")
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--no-voice", action="store_true")
    ap.add_argument("--no-window", action="store_true", help="serve the HUD without opening a window")
    ap.add_argument("--doctor", action="store_true", help="check the setup and measure speed")
    ap.add_argument("--voices", action="store_true", help="choose the English and Tamil voices")
    ap.add_argument("--setup-accounts", action="store_true", help="connect Gmail and calendar")
    ap.add_argument("--setup-jobs", action="store_true", help="enter your details for job applications")
    args = ap.parse_args()
    if args.doctor:
        import doctor
        return doctor.run()
    if args.voices:
        return choose_voices()
    if args.setup_accounts:
        import mailcal
        return mailcal.setup_accounts()
    if args.setup_jobs:
        import jobs
        return jobs.setup_profile()
    run_cli() if args.cli else run_gui(args)


if __name__ == "__main__":
    main()
