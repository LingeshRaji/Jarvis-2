"""Voice catalogue and the saved choice of voice for English and Tamil.

Engines:
  piper  fully offline, fast, English only (there is no Tamil Piper voice). Downloaded once (~60 MB each).
  mms    fully offline Tamil (Meta MMS-TTS). One voice, a little robotic.
  edge   Microsoft's neural voices through edge-tts. Much more natural, but needs internet for every sentence.
Voice ids look like "engine:name", e.g. "piper:en_GB-alan-medium" or "edge:ta-IN-PallaviNeural".
"""
import json
import os
import urllib.request
from dataclasses import dataclass, asdict

import config


@dataclass(frozen=True)
class Voice:
    id: str
    lang: str            # "en" | "ta"
    label: str
    note: str
    online: bool = False

    @property
    def engine(self) -> str:
        return self.id.split(":", 1)[0]

    @property
    def name(self) -> str:
        return self.id.split(":", 1)[1]


def _p(name, label, note):
    return Voice(f"piper:{name}", "en", label, note)


def _e(name, lang, label, note):
    return Voice(f"edge:{name}", lang, label, note, online=True)


CATALOG: list[Voice] = [
    # ---- English, offline (Piper)
    _p("en_GB-alan-medium", "Alan (British male)", "calm and dry; the closest to Jarvis. Default"),
    _p("en_GB-northern_english_male-medium", "Northern (British male)", "warmer, northern English accent"),
    _p("en_US-ryan-high", "Ryan (American male, high quality)", "clear and natural, a bit larger and slower"),
    _p("en_US-lessac-high", "Lessac (American, high quality)", "smooth neutral American"),
    _p("en_US-joe-medium", "Joe (American male)", "deeper, relaxed"),
    _p("en_US-hfc_male-medium", "HFC (American male)", "clean, neutral"),
    _p("en_GB-cori-high", "Cori (British female, high quality)", "clear British female"),
    _p("en_GB-jenny_dioco-medium", "Jenny (British female)", "friendly British female"),
    _p("en_GB-alba-medium", "Alba (Scottish female)", "Scottish accent"),
    _p("en_US-amy-medium", "Amy (American female)", "bright American female"),
    # ---- English, online (Edge)
    _e("en-GB-RyanNeural", "en", "Ryan (British male, neural)", "the most natural British male; needs internet"),
    _e("en-GB-ThomasNeural", "en", "Thomas (British male, neural)", "needs internet"),
    _e("en-GB-SoniaNeural", "en", "Sonia (British female, neural)", "needs internet"),
    _e("en-US-AndrewNeural", "en", "Andrew (American male, neural)", "needs internet"),
    _e("en-US-GuyNeural", "en", "Guy (American male, neural)", "needs internet"),
    _e("en-US-AriaNeural", "en", "Aria (American female, neural)", "needs internet"),
    _e("en-IN-PrabhatNeural", "en", "Prabhat (Indian English male, neural)", "needs internet"),
    _e("en-IN-NeerjaNeural", "en", "Neerja (Indian English female, neural)", "needs internet"),
    # ---- Tamil
    Voice("mms:tam", "ta", "MMS Tamil (offline)", "works without internet; one voice, slightly robotic"),
    _e("ta-IN-ValluvarNeural", "ta", "Valluvar (Tamil Nadu male, neural)", "natural; needs internet"),
    _e("ta-IN-PallaviNeural", "ta", "Pallavi (Tamil Nadu female, neural)", "natural; needs internet"),
    _e("ta-LK-KumarNeural", "ta", "Kumar (Sri Lankan Tamil male, neural)", "needs internet"),
    _e("ta-LK-SaranyaNeural", "ta", "Saranya (Sri Lankan Tamil female, neural)", "needs internet"),
    _e("ta-SG-AnbuNeural", "ta", "Anbu (Singapore Tamil male, neural)", "needs internet"),
    _e("ta-SG-VenbaNeural", "ta", "Venba (Singapore Tamil female, neural)", "needs internet"),
    _e("ta-MY-SuryaNeural", "ta", "Surya (Malaysian Tamil male, neural)", "needs internet"),
    _e("ta-MY-KaniNeural", "ta", "Kani (Malaysian Tamil female, neural)", "needs internet"),
]
BY_ID = {v.id: v for v in CATALOG}
OFFLINE_FALLBACK = {"en": "piper:en_GB-alan-medium", "ta": "mms:tam"}


# --------------------------------------------------------------------------------------- settings
def load_settings() -> dict:
    try:
        return json.loads(config.SETTINGS_FILE.read_text())
    except (OSError, ValueError):
        return {}


def save_settings(**changes) -> None:
    data = load_settings()
    data.update(changes)
    tmp = config.SETTINGS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    os.replace(tmp, config.SETTINGS_FILE)


def current(lang: str) -> Voice:
    """The voice chosen for this language (falls back to the config default if the saved id is unknown)."""
    default = config.DEFAULT_VOICE_TA if lang == "ta" else config.DEFAULT_VOICE_EN
    vid = load_settings().get(f"voice_{lang}", default)
    v = BY_ID.get(vid) or BY_ID.get(default) or BY_ID[OFFLINE_FALLBACK[lang]]
    return v if v.lang == lang else BY_ID[OFFLINE_FALLBACK[lang]]


def choose(lang: str, vid: str) -> Voice:
    v = BY_ID.get(vid)
    if not v or v.lang != lang:
        raise ValueError(f"'{vid}' is not a known {lang} voice")
    save_settings(**{f"voice_{lang}": vid})
    return v


# --------------------------------------------------------------------------------------- files
def piper_paths(v: Voice):
    return config.VOICES_DIR / f"{v.name}.onnx", config.VOICES_DIR / f"{v.name}.onnx.json"


def installed(v: Voice) -> bool:
    if v.engine == "piper":
        m, c = piper_paths(v)
        return m.exists() and c.exists()
    return True


def _piper_urls(v: Voice):
    locale, name, quality = v.name.split("-")
    base = f"https://huggingface.co/rhasspy/piper-voices/resolve/main/{locale.split('_')[0]}/{locale}/{name}/{quality}/{v.name}"
    return base + ".onnx", base + ".onnx.json"


def ensure(v: Voice, progress=None) -> None:
    """Download a Piper voice if it is missing. Raises on failure. progress(text) is optional."""
    if installed(v):
        return
    config.VOICES_DIR.mkdir(parents=True, exist_ok=True)
    for url, dest in zip(_piper_urls(v), piper_paths(v)):
        if dest.exists():
            continue
        if progress:
            progress(f"Downloading {dest.name}…")
        tmp = dest.with_suffix(dest.suffix + ".part")
        with urllib.request.urlopen(url, timeout=30) as r, open(tmp, "wb") as f:
            while chunk := r.read(1 << 20):
                f.write(chunk)
        os.replace(tmp, dest)


def listing() -> dict:
    """Catalogue for the HUD: voices grouped by language with an 'installed' flag, plus the current choice."""
    out = {"current": {}, "voices": {"en": [], "ta": []}}
    for lang in ("en", "ta"):
        out["current"][lang] = current(lang).id
    for v in CATALOG:
        out["voices"][v.lang].append({**asdict(v), "engine": v.engine, "installed": installed(v)})
    return out
