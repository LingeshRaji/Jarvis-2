"""Web server that connects the Assistant to the HUD over a WebSocket (everything stays on 127.0.0.1)."""
import asyncio
import json
import shutil
import subprocess
from pathlib import Path

import psutil
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

import config

UI_DIR = Path(__file__).parent / "ui"
REPLAY_TYPES = {"user", "reply_end", "tool", "notice", "status"}


class Hub:
    def __init__(self):
        self.clients: set[WebSocket] = set()
        self.loop: asyncio.AbstractEventLoop | None = None
        self.recent: list[dict] = []

    def emit(self, type_: str, **data) -> None:
        """Thread-safe: called from assistant threads."""
        msg = {"type": type_, **data}
        if type_ in REPLAY_TYPES:
            self.recent = (self.recent + [msg])[-40:]
        if self.loop and self.clients:
            self.loop.call_soon_threadsafe(self._broadcast, msg)

    def _broadcast(self, msg: dict) -> None:
        for ws in list(self.clients):
            asyncio.ensure_future(self._send(ws, msg))

    async def _send(self, ws: WebSocket, msg: dict) -> None:
        try:
            await ws.send_text(json.dumps(msg, ensure_ascii=False))
        except Exception:
            self.clients.discard(ws)


def _gpu() -> dict:
    if not shutil.which("nvidia-smi"):
        return {}
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu",
             "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=3).stdout.strip()
        u, mu, mt, t = [float(x) for x in out.splitlines()[0].split(",")]
        return {"gpu": u, "vram_used": mu, "vram_total": mt, "gpu_temp": t}
    except Exception:
        return {}


def _stats() -> dict:
    vm = psutil.virtual_memory()
    s = {"cpu": psutil.cpu_percent(), "ram": vm.percent, "ram_used": round(vm.used / 2**30, 1),
         "ram_total": round(vm.total / 2**30, 1), "disk": psutil.disk_usage("/").percent}
    bat = psutil.sensors_battery()
    if bat:
        s["battery"] = round(bat.percent)
    s.update(_gpu())
    return s


def create_app(demo: bool = False, voice: bool = True) -> FastAPI:
    hub = Hub()
    app = FastAPI()
    holder: dict = {}

    @app.on_event("startup")
    async def _startup():
        hub.loop = asyncio.get_running_loop()
        if demo:
            from demo import DemoAssistant
            holder["a"] = DemoAssistant(hub.emit)
        else:
            from assistant import Assistant
            holder["a"] = Assistant(hub.emit, voice_enabled=voice)
        holder["a"].start()
        asyncio.create_task(_stats_loop())

    @app.on_event("shutdown")
    async def _shutdown():
        holder["a"].shutdown()

    async def _stats_loop():
        while True:
            hub.emit("stats", **await asyncio.to_thread(_stats))
            await asyncio.sleep(2)

    @app.websocket("/ws")
    async def ws(websocket: WebSocket):
        await websocket.accept()
        a = holder["a"]
        hub.clients.add(websocket)
        await websocket.send_text(json.dumps({
            "type": "hello", "name": config.USER_NAME, "model": config.LLM_MODEL, "mode": a.mode,
            "state": a.state, "voice": a.voice_enabled, "languages": config.LANGUAGES,
            "quality": config.HUD_QUALITY,
            "recent": hub.recent}, ensure_ascii=False))
        try:
            while True:
                m = json.loads(await websocket.receive_text())
                t = m.get("type")
                if t == "text":
                    a.submit_text(m.get("text", ""))
                elif t == "listen":
                    a.request_listen()
                elif t == "stop":
                    a.stop()
                elif t == "mode":
                    a.set_mode(m.get("mode", "auto"))
                elif t == "confirm_reply":
                    a.resolve_confirm(m.get("id", ""), bool(m.get("ok")))
                elif t == "voices":
                    await websocket.send_text(json.dumps({"type": "voices", **a.get_voices()}, ensure_ascii=False))
                elif t == "set_voice":
                    a.set_voice(m.get("lang", ""), m.get("id", ""))
                elif t == "preview_voice":
                    a.preview_voice(m.get("lang", ""), m.get("id", ""))
                elif t == "tts":
                    a.tts_enabled = bool(m.get("value"))
                elif t == "mic":
                    a.mic_enabled = bool(m.get("value"))
        except WebSocketDisconnect:
            pass
        finally:
            hub.clients.discard(websocket)

    @app.get("/")
    async def index():
        return FileResponse(UI_DIR / "index.html")

    app.mount("/reports", StaticFiles(directory=config.REPORTS_DIR), name="reports")
    app.mount("/", StaticFiles(directory=UI_DIR), name="ui")
    return app
