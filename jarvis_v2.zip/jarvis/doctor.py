"""`python jarvis.py --doctor`: checks the setup and measures how fast each stage is on this machine."""
import shutil
import time

import config


def _line(ok, name, detail=""):
    print(f"  {'OK  ' if ok else 'FAIL' if ok is False else 'info'}  {name}" + (f"  - {detail}" if detail else ""))
    return ok


def run() -> None:
    import apps
    import mailcal
    import jobs
    import voices
    print("\nJarvis doctor\n")

    print("Desktop")
    env = apps.clean_env()
    _line(bool(env.get("DISPLAY") or env.get("WAYLAND_DISPLAY")), "graphical session",
          env.get("WAYLAND_DISPLAY") or env.get("DISPLAY") or "no DISPLAY / WAYLAND_DISPLAY: Jarvis cannot open apps")
    for exe, why in (("xdg-open", "open links and folders"), ("gtk-launch", "start apps from the menu (or gio)"),
                     ("playerctl", "music keys"), ("brightnessctl", "screen brightness"),
                     ("wpctl", "volume (or pactl / amixer)")):
        _line(True if shutil.which(exe, path=env["PATH"]) else None, exe, why)
    b = apps.resolve("browser")
    _line(bool(b), "a web browser is found", b["label"] if b else "install firefox or chromium")
    ff = apps.resolve("firefox")
    _line(True if ff else None, "firefox is found", " ".join(ff["cmd"]) if ff else "not installed (Jarvis will say so, not pretend)")

    print("\nLanguage model")
    import ollama
    try:
        cl = ollama.Client(host=config.OLLAMA_HOST)
        have = {m.get("model") or m.get("name") for m in (cl.list().get("models") or [])}
        _line(True, "Ollama is running")
        for m in (config.LLM_MODEL, config.VISION_MODEL, config.EMBED_MODEL):
            ok = any(h and (h == m or h.split(":")[0] == m.split(":")[0] and ":" not in m) for h in have) or m in have
            _line(ok, f"model {m}", "" if ok else f"run: ollama pull {m}")
        if config.LLM_MODEL in have:
            for label in ("first call (loads the model)", "second call (what you normally feel)"):
                t = time.time()
                first = None
                for _ in cl.chat(model=config.LLM_MODEL, messages=[{"role": "user", "content": "Say hello in four words."}],
                                 stream=True, options={"num_predict": 12}, keep_alive=config.KEEP_ALIVE, think=False):
                    first = first or time.time() - t
                _line(None, label, f"first word {first:.1f}s, total {time.time() - t:.1f}s")
    except Exception as e:
        _line(False, "Ollama", f"{e}. Start it with: ollama serve")

    print("\nSpeech")
    try:
        import sounddevice as sd
        _line(True, "microphone", str(sd.query_devices(kind="input")["name"]))
        _line(True, "speakers", str(sd.query_devices(kind="output")["name"]))
    except Exception as e:
        _line(False, "audio devices", str(e)[:100])
    try:
        import numpy as np
        import voice
        t = time.time(); voice._get_whisper("en"); _line(None, "English speech model loaded", f"{time.time() - t:.1f}s")
        t = time.time(); voice.transcribe(np.zeros(16000 * 2, dtype=np.float32), "en")
        _line(None, "transcribing 2 s of audio", f"{time.time() - t:.2f}s")
    except Exception as e:
        _line(False, "speech recognition", str(e)[:120])
    for lang in ("en", "ta"):
        v = voices.current(lang)
        have = voices.installed(v)
        _line(True if (have or v.online) else None, f"{lang} voice: {v.label}", "ready" if have else "downloads when first used")
        if have or v.online:
            try:
                import voice
                t = time.time()
                voice.synthesize("Systems are online." if lang == "en" else "வணக்கம் ஐயா.", lang)
                _line(None, f"speaking a short {lang} sentence", f"{time.time() - t:.2f}s")
            except Exception as e:
                _line(False, f"{lang} speech output", str(e)[:120])

    print("\nMail, calendar, jobs")
    _line(True if mailcal.mail_configured() else None, "mail connected", "" if mailcal.mail_configured() else mailcal.SETUP_HINT)
    _line(True if mailcal.calendar_configured() else None, "calendar connected", "" if mailcal.calendar_configured() else mailcal.SETUP_HINT)
    _line(True if jobs.profile_ready() else None, "job profile filled in", "" if jobs.profile_ready() else jobs.SETUP_HINT)
    print()
