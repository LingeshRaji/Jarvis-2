"""Central configuration for Jarvis. Edit this file to tune behaviour."""
from pathlib import Path

HOME = Path.home() / ".jarvis"
HOME.mkdir(exist_ok=True)

# --- LLM (served locally by Ollama) -----------------------------------------
# qwen3:4b fits fully in 6 GB of VRAM, so it answers 2-3x faster than qwen3:8b (which spills into RAM).
# Everyday commands never reach the model at all (see router.py). If you mostly chat in Tamil and care more about
# answer quality than speed, switch to "qwen3:8b".
LLM_MODEL = "qwen3:4b"
VISION_MODEL = "qwen2.5vl:3b"          # screen reading / image questions (also good at OCR)
EMBED_MODEL = "nomic-embed-text"
OLLAMA_HOST = "http://127.0.0.1:11434"
LLM_OPTIONS = {"temperature": 0.4, "num_ctx": 4096, "num_predict": 400}
KEEP_ALIVE = "2h"                      # keep the model loaded between turns (a cold start costs several seconds)

# --- Persona -----------------------------------------------------------------
USER_NAME = "Lingesh"
SYSTEM_PROMPT = f"""You are J.A.R.V.I.S., a calm, dry-witted, extremely capable AI assistant running
entirely offline on {USER_NAME}'s Linux computer. Address him as "sir" (in Tamil: "ஐயா") occasionally.

LANGUAGE: Reply in the same language the user spoke. If they speak Tamil, answer in natural Tamil
script (தமிழ்). If English, answer in English. Do not mix scripts unless quoting commands or tool names.
In Tamil, write numbers as Tamil words so they can be spoken.

STYLE: You are speaking aloud. Keep answers to 1-3 short sentences unless asked for detail.
No markdown, no bullet points, no emojis, no URLs read out letter by letter.

TOOLS: Use tools to act on the computer, check mail and calendar, track job applications, look at the screen,
search notes, run authorised scans and write pentest reports.
RULE: when the user asks you to DO something, call the tool first and answer only after it returns. Never say you
opened, sent, saved, set or changed anything unless a tool result says so. If a tool result starts with "ERROR:",
tell the user it failed and give the reason in one short sentence. Never invent tool results.
SECURITY: You assist with authorised testing, CTFs and the user's own lab only."""

# --- Language ----------------------------------------------------------------
LANGUAGES = {"en": "English", "ta": "தமிழ்"}
LANGUAGE_MODE = "auto"                 # "auto" (detect per utterance), "en" or "ta"

# --- Speech in ----------------------------------------------------------------
WAKE_WORD = "hey_jarvis"               # English wake word. Tamil users can click the core or press Space.
# Two-stage listening: the small model transcribes English quickly and also detects the language. Only when you
# speak Tamil is the larger (slower, more accurate) Tamil model used.
WHISPER_MODEL_EN = "small"
WHISPER_MODEL_TA = "large-v3-turbo"
PREWARM_TAMIL_STT = True               # load the Tamil model in the background at start-up (uses ~1.5 GB RAM)
WHISPER_DEVICE = "cpu"                 # keep the GPU free for the LLM
WHISPER_COMPUTE = "int8"
WHISPER_THREADS = 0                    # 0 = automatic
STT_PROMPT = "Jarvis, Firefox, Chrome, Spotify, Nmap, Burp Suite, Wireshark, Terminal, YouTube, Gmail, calendar."
SAMPLE_RATE = 16000
SILENCE_SECONDS = 0.8
SILENCE_RMS = 0.012
MAX_RECORD_SECONDS = 25

# --- Speech out ---------------------------------------------------------------
# Voices are chosen in the HUD (gear icon > Voice) or with `python jarvis.py --voices`; the choice is saved in
# ~/.jarvis/settings.json. These are only the first-run defaults. The full catalogue is in voices.py.
DEFAULT_VOICE_EN = "piper:en_GB-alan-medium"
DEFAULT_VOICE_TA = "mms:tam"
VOICES_DIR = HOME / "voices"
SETTINGS_FILE = HOME / "settings.json"

# --- Mail, calendar, jobs ----------------------------------------------------------
# Secrets live in ~/.jarvis/accounts.json (created with `python jarvis.py --setup-accounts`, permissions 600).
ACCOUNTS_FILE = HOME / "accounts.json"
JOBS_DB = HOME / "jobs.db"
PROFILE_FILE = HOME / "profile.json"   # your details for cover letters (`python jarvis.py --setup-jobs`)
APPLICATIONS_DIR = Path.home() / "jarvis_applications"
APPLICATIONS_DIR.mkdir(exist_ok=True)
WEATHER_CITY = ""                      # e.g. "Chennai": adds the weather to the daily briefing (needs internet)
BRIEFING_ON_START = True               # speak the daily briefing the first time Jarvis starts each day
STATE_FILE = HOME / "state.json"

# --- Interface ------------------------------------------------------------------
UI_HOST = "127.0.0.1"
UI_PORT = 8765
# 3D holographic core. "high" = 3D with glow, "medium" = 3D without glow, "low" = flat 2D (lightest).
# The 3D scene asks the browser to use your integrated GPU when there is one, so the NVIDIA card keeps its
# VRAM for the language model.
HUD_QUALITY = "high"

# --- Safety ------------------------------------------------------------------
SAFE_COMMANDS = {"ls", "pwd", "whoami", "date", "uptime", "df", "free", "uname",
                 "ip", "ifconfig", "ping", "cat", "head", "tail", "echo", "which"}
# Scans only run against these (plus any scope you confirm for an engagement).
AUTHORISED_TARGETS = ["127.0.0.1", "localhost", "192.168.56.0/24"]
BLOCKED_PATTERNS = ["rm -rf /", "mkfs", ":(){", "dd if=", "> /dev/sd", "chmod -R 777 /"]

# --- Paths -------------------------------------------------------------------
MEMORY_DB = HOME / "memory.db"
NOTES_DIR = Path.home() / "jarvis_notes"
NOTES_DIR.mkdir(exist_ok=True)
REPORTS_DIR = Path.home() / "jarvis_reports"
REPORTS_DIR.mkdir(exist_ok=True)
